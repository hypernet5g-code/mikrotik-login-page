/* HyperNet external configuration file.
 * Edit this file from the administrator panel output. Keep images/scripts/styles external.
 */
window.HN_CONFIG = {"themeName":"ocean","brandName":"هايبر نت","brandFont":"fixed-kufi","tagline":"عالم من المتعة والترفيه","cardLabel":"","placeholder":"","submitLabel":"","adTitle":"","adSubtitle":"","adCaption":"","servicesTitle":"","servicesSubtitle":"","infoTiles":{"packages":{"title":"الباقات والدفع الإلكتروني","subtitle":"الباقات والأسعار والدفع"},"internet":{"title":"الإنترنت فائق السرعة","subtitle":"تقنية الألياف الضوئية"},"entertainment":{"title":"الترفيه","subtitle":"شاهد مجانًا"},"rules":{"title":"المعلومات","subtitle":"خدمات وإرشادات الشبكة"}},"footerLeft":"","customColors":{"enabled":false,"lockClient":false,"start":"#05030d","end":"#120b2c","ink":"#06b6d4","soft":"#f4ecff","brand":"#06b6d4"},"clientFilter":{"configured":true,"index":2,"locked":true},"ads":["assets/ads/1.jpg","assets/ads/2.jpg","assets/ads/3.jpg","assets/ads/4.jpg","assets/ads/5.jpg","assets/ads/6.jpg"],"adMeta":[{"width":420,"height":261,"name":"1000646934.jpg"},{"width":420,"height":261,"name":"1000646936.jpg"},{"width":420,"height":261,"name":"1000646938.jpg"},{"width":420,"height":261,"name":"1000646935.jpg"},{"width":420,"height":261,"name":"1000646939.jpg"},{"width":420,"height":261,"name":"1000646937.jpg"}],"adSettings":{"motion":"legacy","speed":4,"width":145,"height":185,"stageHeight":211,"gap":0,"depth":156,"scale":1.1,"sizePreset":"large-1","imageQuality":"balanced","imageGapVersion":1},"blocks":[],"originalLogoVisible":true,"logos":[{"id":"logo-1790111119964-nastum","src":"assets/logo/hypernet-logo.gif","x":60.767594507377,"y":2,"size":38,"rotation":0,"name":"1000621447"}],"scene":{"brandText":{"label":"هايبر Net","x":52.91279951731366,"y":5.715670990801087,"scale":1.04,"rotation":0,"visible":true},"tagline":{"label":"عالم من المتعة والترفيه","x":53.63986921728776,"y":10.29939551473665,"scale":1,"rotation":0,"visible":true}},"backgroundEffect":{"mode":"none","intensity":0,"speed":0,"size":0,"opacity":0,"randomSize":false},"performance":{"backgroundMotion":false,"shadows":false},"status":"","freeLayout":{"adArea":{"x":1.2250484271222,"y":-149.15156642204965},"topbar":{"x":-10.128183684952827,"y":7.416706420553587},"loginCard":{"x":0.2903496111281193,"y":-155.96594397969335},"services":{"x":-3.366145580372912,"y":-176.65125430898462},"footer":{"x":0.8960591580005403,"y":-175.33367075818649}},"__hnRevision":1790819293329,"__hnAuthority":true};
window.HN_SECURITY = {"managerHash":"f5b61f8322028542fe967025a165ee77eadc4b59c1c671aed418ac55d52576bd"};
(function () {
  try {
    var cfg = window.HN_CONFIG || {};
    var root = document.documentElement;
    if (!root) return;
    root.setAttribute('data-hn-config-authority', '1');
    root.setAttribute('data-hn-official-theme', String(cfg.themeName || 'ocean'));
    var filter = cfg.clientFilter || {};
    var index = Number.parseInt(filter.index, 10);
    root.setAttribute('data-hn-official-filter', String(Number.isFinite(index) ? index : 0));
    root.setAttribute('data-hn-official-filter-lock', filter.locked ? '1' : '0');
  } catch (e) {}
})();
