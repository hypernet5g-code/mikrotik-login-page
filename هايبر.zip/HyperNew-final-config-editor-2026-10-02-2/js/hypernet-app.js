/* HyperNet split application runtime. Script order matches the original document order. */

  try { document.cookie = 'uname=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/'; } catch(e) {}


  if(typeof cookieLogin==='function'){ try{ cookieLogin(); }catch(e){} }


/* ===== hn-contained-frame-theme-sync ===== */


(function(){
  'use strict';
  function syncFrameTheme(){
    var root=document.getElementById('hn-root');
    if(!root)return;
    var rootStyle=getComputedStyle(root);
    var target=document.body;
    ['--hn-start','--hn-end','--hn-brand'].forEach(function(name){
      var value=rootStyle.getPropertyValue(name).trim();
      if(value) target.style.setProperty(name,value);
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',syncFrameTheme,{once:true});
  else syncFrameTheme();
  window.addEventListener('load',syncFrameTheme,{once:true});
  var root=document.getElementById('hn-root');
  if(root) root.addEventListener('hn:theme-color-changed',syncFrameTheme,{passive:true});
})();


/* ===== hn-mobile-scroll-flash-background-sync ===== */


(function(){
  'use strict';
  function syncDocumentBackground(){
    try{
      var root=document.getElementById('hn-root');
      if(!root || document.body.classList.contains('hn-admin-preview-page')) return;
      var atmosphere=root.querySelector(':scope > .hn-atmosphere');
      var cs=getComputedStyle(root);
      var end=(cs.getPropertyValue('--hn-end')||'').trim() || '#0b3d2e';
      var bg=atmosphere ? getComputedStyle(atmosphere).background : '';
      document.documentElement.style.setProperty('--hn-page-bottom-bg',end);
      document.body.style.setProperty('--hn-page-bottom-bg',end);
      document.documentElement.style.setProperty('background-color',end,'important');
      document.body.style.setProperty('background-color',end,'important');
      if(bg && bg!=='none') document.body.style.setProperty('background',bg,'important');
    }catch(e){}
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',function(){if(window.__HN_STARTUP_READY)syncDocumentBackground();},{once:true});
  else if(window.__HN_STARTUP_READY) syncDocumentBackground();
  window.addEventListener('load',function(){if(window.__HN_STARTUP_READY)syncDocumentBackground();},{once:true});
  var root=document.getElementById('hn-root');
  if(root) root.addEventListener('hn:theme-color-changed',syncDocumentBackground,{passive:true});
})();


/* ===== hn-first-paint-boot-release-v1 ===== */


(function(){
  // The boot variables only lock the first-paint palette; release them after
  // the existing theme engine has applied the real saved configuration.
  function release(){ try{ document.documentElement.classList.remove('hn-first-paint-boot'); }catch(e){} }
  document.addEventListener('hn:theme-color-changed',release,{once:true});
  window.addEventListener('load',function(){ setTimeout(release,0); },{once:true});
})();


  // ربط بوابة الدفع الحقيقية يتم هنا بعد اعتماد API التاجر من مزود المحفظة.
  // لا تضع PIN أو OTP أو مفاتيح سرية في هذه الصفحة.
  window.HYPERNET_PAYMENT_API_BASE = '';


(function(){
  function cleanMikroTikError(){
    var e=document.getElementById('hn-mt-error');
    var t=document.getElementById('hn-mt-error-text');
    if(!e||!t)return;
    if(!t.textContent.replace(/\s+/g,'').trim()){
      e.classList.add('hn-empty-error');
      return;
    }
    try{document.cookie='uname=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/';}catch(x){}
    setTimeout(function(){
      var el=document.getElementById('hn-mt-error');
      if(el){el.classList.add('hn-inline-hide');setTimeout(function(){if(el.parentNode)el.parentNode.removeChild(el)},350)}
    },6000);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',cleanMikroTikError);
  else cleanMikroTikError();
  setTimeout(cleanMikroTikError,60);
})();


/* ===== hn-startup-sequence-v2-script ===== */

(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  if(!root) return;
  if(root.__HN_SINGLE_INTRO_STARTED) return;
  root.__HN_SINGLE_INTRO_STARTED=true;

  function syncBaseBody(){
    try{
      var start=getComputedStyle(root).getPropertyValue('--hn-start').trim();
      if(start) document.body.style.background=start;
    }catch(e){}
  }
  function resetIntro(){
    root.classList.remove('hn-intro-waiting','hn-intro-right-curtain-active','hn-intro-left-curtain-active','hn-intro-brand-ready','hn-intro-content-ready','hn-intro-complete');
    root.classList.add('hn-intro-pending');
    window.__HN_INTRO_DONE=false;
  }
  function showContent(){
    if(root.__HN_CONTENT_SHOWN) return;
    root.__HN_CONTENT_SHOWN=true;
    root.classList.add('hn-intro-content-ready','hn-intro-complete');
    root.classList.remove('hn-intro-pending','hn-intro-right-curtain-active');
  }
  function showBrand(){
    if(root.__HN_BRAND_SHOWN) return;
    root.__HN_BRAND_SHOWN=true;
    root.classList.add('hn-intro-brand-ready');
    // Keep the exact existing brand/logo animation; only its start time is
    // slightly delayed so the content can settle first.
    window.__HN_INTRO_DONE=true;
  }
  function showRightCurtain(){
    if(root.__HN_RIGHT_STARTED) return;
    root.__HN_RIGHT_STARTED=true;
    root.classList.add('hn-intro-right-curtain-active');
    // After the two curtains finish, reveal the network name + logo first.
    // When that brand/logo reveal completes, show the page content immediately
    // with no additional pause. The text animation is 1.05s, so use the same
    // duration as the authoritative completion point.
    window.setTimeout(function(){
      showBrand();
      window.setTimeout(showContent,1050);
    },1000);
  }
  function start(){
    if(root.__HN_INTRO_RUNNING) return;
    root.__HN_INTRO_RUNNING=true;
    root.__HN_BRAND_SHOWN=false;
    root.__HN_CONTENT_SHOWN=false;
    root.__HN_RIGHT_STARTED=false;
    root.__HN_LEFT_STARTED=false;
    resetIntro();
    syncBaseBody();

    var reduced=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(reduced){
      root.classList.add('hn-intro-brand-ready','hn-intro-content-ready');
      root.classList.remove('hn-intro-pending');
      window.__HN_INTRO_DONE=true;
      return;
    }

    var left=root.querySelector('.hn-curtain-one');
    if(!left){
      window.setTimeout(showRightCurtain,280);
      return;
    }

    var startLeft=function(){
      if(root.__HN_LEFT_STARTED) return;
      root.__HN_LEFT_STARTED=true;
      root.classList.add('hn-intro-left-curtain-active');
    };

    var done=false;
    var finish=function(){
      if(done) return;
      done=true;
      showRightCurtain();
    };
    left.addEventListener('animationend',function(e){
      if(e.target===left && (!e.animationName || e.animationName==='hnIntroLeftDrop')) finish();
    },{once:true});

    // Let the frame stand alone first, then start the first curtain.
    window.setTimeout(startLeft,40);
    // Safety fallback: 280ms frame-only pause + 1s first-curtain motion + margin.
    window.setTimeout(finish,1120);
  }

  root.addEventListener('hn:theme-color-changed',function(){syncBaseBody();},{passive:true});
  start();
})();


(() => {
  const root = document.getElementById('hn-root');
  const portable = document.getElementById('hn-portable-note');
  if (portable) portable.textContent = 'الحفظ يحدّث ملف config.js فقط. استبدل config.js على MikroTik، بينما تبقى login.html وملفات الصور والإعلانات والسكربتات كما هي.';
})();


(() => {
  const root = document.getElementById('hn-root');
  if (!root) return;
  const readAdminColorPolicy = () => {
    try {
      const source = window.HN_CONFIG && typeof window.HN_CONFIG === 'object' ? window.HN_CONFIG : null;
      const custom = source?.customColors;
      return custom && custom.enabled && custom.lockClient
        ? { locked: true, brand: custom.brand }
        : { locked: false, brand: '' };
    } catch (_) {
      return { locked: false, brand: '' };
    }
  };
  let adminColorPolicy = readAdminColorPolicy();

  const clientColors = [
    { name: 'الأخضر', start: '#0b5546', end: '#24b477', ink: '#087052', soft: '#d8f3e8', brand: '#5ee0a7', logoBlueShift: '-55deg' },
    { name: 'الأزرق', start: '#0b4f82', end: '#1598d1', ink: '#086da5', soft: '#d9effc', brand: '#62c5f0', logoBlueShift: '-22deg' },
    { name: 'البرتقالي', start: '#75411f', end: '#d58a43', ink: '#a85b26', soft: '#f8e5d2', brand: '#f2ad69', logoBlueShift: '160deg' },
    { name: 'البنفسجي', start: '#3f2870', end: '#7950b8', ink: '#5b35a0', soft: '#ebe2fa', brand: '#b998e8', logoBlueShift: '40deg' },
    { name: 'البني', start: '#51352a', end: '#956247', ink: '#704432', soft: '#f1e2d8', brand: '#c39476', logoBlueShift: '125deg' },
    { name: 'الرمادي', start: '#343f47', end: '#66747d', ink: '#485862', soft: '#e4e9ec', brand: '#aebdc5', logoBlueShift: '0deg' },
    { name: 'الليل النجمي', start: '#050816', end: '#172b5c', ink: '#243d78', soft: '#e8efff', brand: '#9ec5ff', logoBlueShift: '8deg', appearance: 'starry' },
    { name: 'تقنية AI', start: '#07131f', end: '#163c55', ink: '#145d78', soft: '#e3f8ff', brand: '#61e7ff', logoBlueShift: '-12deg', appearance: 'ai' },
    { name: 'فيروزي مضيء', start: '#07383b', end: '#13a7a2', ink: '#0b716f', soft: '#d9f8f6', brand: '#63d9d4', logoBlueShift: '-38deg' },
    { name: 'مرجاني ناعم', start: '#4b2228', end: '#d45f58', ink: '#99433f', soft: '#ffe2dc', brand: '#ff8b6d', logoBlueShift: '165deg' },
    { name: 'وردي لؤلؤي', start: '#432034', end: '#b85f91', ink: '#87466d', soft: '#fae3ef', brand: '#ff86b7', logoBlueShift: '145deg' },
    { name: 'ذهبي دافئ', start: '#4a3216', end: '#bd8a2c', ink: '#86601a', soft: '#f9ecd0', brand: '#f7c66a', logoBlueShift: '135deg' },
    { name: 'نعناعي', start: '#0f3d38', end: '#2bbf9a', ink: '#177f67', soft: '#d9f6ed', brand: '#5ad8c4', logoBlueShift: '-52deg' },
    { name: 'نيلي ملكي', start: '#21184e', end: '#5f61c8', ink: '#48469a', soft: '#e7e6ff', brand: '#8ea6ff', logoBlueShift: '22deg' },
    { name: 'أخضر ربيعي', start: '#173c24', end: '#55ae68', ink: '#347343', soft: '#e1f5e2', brand: '#8fe0b2', logoBlueShift: '-60deg' },
    { name: 'ياقوت أحمر', start: '#461c26', end: '#b62f4f', ink: '#82253c', soft: '#ffe1e7', brand: '#e65d6a', logoBlueShift: '170deg' },
    { name: 'برونزي', start: '#3e2a1d', end: '#9c653b', ink: '#70462b', soft: '#f3e2d4', brand: '#d89b68', logoBlueShift: '118deg' },
    { name: 'لافندر', start: '#33234d', end: '#8160a9', ink: '#5f4880', soft: '#eee6f8', brand: '#d7a7ee', logoBlueShift: '34deg' },
  ];
  const CLIENT_THEME_KEY = 'hypernet_client_theme_index_v1';
  const readEmbeddedClientFilterPolicy = () => {
    try {
      const policy = window.HN_CONFIG?.clientFilter || null;
      const index = Number.parseInt(policy?.index, 10);
      const validIndex = Number.isInteger(index) && index >= 0 && index < clientColors.length ? index : 0;
      return { configured: policy?.configured === true, index: validIndex, locked: policy?.locked === true };
    } catch (_) {
      return { configured: false, index: 0, locked: false };
    }
  };
  const embeddedClientFilterPolicy = readEmbeddedClientFilterPolicy();
  let clientColorIndex = embeddedClientFilterPolicy.configured
    ? embeddedClientFilterPolicy.index
    : Number.parseInt(window.__HN_STORAGE.get(CLIENT_THEME_KEY) || '0', 10);
  if (!Number.isFinite(clientColorIndex) || clientColorIndex < 0 || clientColorIndex >= clientColors.length) clientColorIndex = 0;
  let adminFilterLocked = embeddedClientFilterPolicy.configured && embeddedClientFilterPolicy.locked;

  // Exact logo recoloring based on the supplied animated GIF:
  // - the BLUE artwork is the only variable part
  // - the GRAY/BLACK artwork must stay fixed
  // - the selected blue must become the exact same RGB color used by Net
  //
  // Source reference blue measured from the supplied GIF: #4193EF.
  // We use a color matrix that maps this source blue exactly to the selected
  // Net accent while mathematically leaving every neutral gray/black pixel
  // unchanged. The GIF remains animated because CSS filters are applied per
  // frame by the browser.
  let hnClientLogoFilterNode = null;
  let hnClientLogoAccentFilterNode = null;
  const ensureClientLogoFilter = () => {
    if (hnClientLogoFilterNode?.isConnected) return hnClientLogoFilterNode;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    const filter = document.createElementNS('http://www.w3.org/2000/svg', 'filter');
    filter.setAttribute('id', 'hn-client-logo-color-filter');
    filter.setAttribute('color-interpolation-filters', 'sRGB');
    const matrix = document.createElementNS('http://www.w3.org/2000/svg', 'feColorMatrix');
    matrix.setAttribute('type', 'matrix');
    matrix.setAttribute('values', '1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0');
    filter.appendChild(matrix);
    defs.appendChild(filter);
    svg.appendChild(defs);
    document.documentElement.appendChild(svg);
    hnClientLogoFilterNode = matrix;
    return matrix;
  };
  // Animated GIF/WebP frames may be black, so RGB-based tinting leaves them
  // black. This second matrix paints every non-transparent pixel with Net's
  // active color while preserving the original frame alpha and animation.
  const ensureClientLogoAccentFilter = () => {
    if (hnClientLogoAccentFilterNode?.isConnected) return hnClientLogoAccentFilterNode;
    const svg = document.querySelector('[data-hn-logo-accent-filter]') || document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.setAttribute('data-hn-logo-accent-filter','1');
    svg.setAttribute('aria-hidden','true'); svg.setAttribute('width','0'); svg.setAttribute('height','0');
    svg.style.cssText='position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
    const defs=document.createElementNS('http://www.w3.org/2000/svg','defs');
    const filter=document.createElementNS('http://www.w3.org/2000/svg','filter');
    filter.setAttribute('id','hn-client-logo-accent-filter'); filter.setAttribute('color-interpolation-filters','sRGB');
    const matrix=document.createElementNS('http://www.w3.org/2000/svg','feColorMatrix');
    matrix.setAttribute('type','matrix');
    matrix.setAttribute('values','0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0');
    filter.appendChild(matrix); defs.appendChild(filter); svg.appendChild(defs); document.documentElement.appendChild(svg);
    hnClientLogoAccentFilterNode=matrix; return matrix;
  };
  const applyClientLogoTint = color => {
    const readHex = value => {
      const hex = String(value || '').trim().replace('#', '');
      return /^[0-9a-f]{6}$/i.test(hex) ? [
        parseInt(hex.slice(0, 2), 16),
        parseInt(hex.slice(2, 4), 16),
        parseInt(hex.slice(4, 6), 16)
      ] : null;
    };
    // The active filter is the single source of truth. This is important when
    // an animated logo is added after the page theme was loaded or after the
    // customer cycled the color filter: Net, Wi-Fi and every uploaded frame
    // must use exactly the same accent, not a stale theme brand value.
    const activeAccent = getComputedStyle(root).getPropertyValue('--hn-filter-accent').trim();
    const brand = String(activeAccent || color?.brand || '#34d399').trim();
    const src = [65 / 255, 147 / 255, 239 / 255];
    const targetRgb = readHex(brand) || [52, 211, 153];
    const t = targetRgb.map(v => v / 255);
    const unit = [1, 1, 1];
    const sourceMean = (src[0] + src[1] + src[2]) / 3;
    const centered = src.map(v => v - sourceMean);
    const denom = centered.reduce((sum, v) => sum + v * v, 0) || 1;
    const w = centered.map(v => v / denom);
    const v = t.map((x, i) => x - src[i]);
    const m = Array.from({ length: 3 }, (_, r) =>
      Array.from({ length: 3 }, (_, c) => (r === c ? 1 : 0) + v[r] * w[c])
    );
    // Preserve alpha exactly and map source blue -> selected Net color.
    const matrix = [
      m[0][0], m[0][1], m[0][2], 0, 0,
      m[1][0], m[1][1], m[1][2], 0, 0,
      m[2][0], m[2][1], m[2][2], 0, 0,
      0, 0, 0, 1, 0
    ];
    ensureClientLogoFilter().setAttribute('values', matrix.map(n => Number(n.toFixed(8))).join(' '));
    const accentMatrix = [0,0,0,t[0],0, 0,0,0,t[1],0, 0,0,0,t[2],0, 0,0,0,1,0];
    ensureClientLogoAccentFilter().setAttribute('values', accentMatrix.map(n => Number(n.toFixed(8))).join(' '));
    root.style.setProperty('--hn-logo-gradient-color', brand);
    root.style.setProperty('--hn-client-logo-blue-shift', '0deg');
    root.style.setProperty('--hn-logo-accent', brand);

    // Browser-safe animated-logo tint. The uploaded animated source uses
    // #4193EF as its variable blue. Hue rotation keeps neutral black/gray
    // pixels neutral, while saturation brings the blue close to the selected
    // Net/filter accent without relying on an SVG URL filter.
    const hsv = (r,g,b) => {
      r/=255; g/=255; b/=255;
      const max=Math.max(r,g,b), min=Math.min(r,g,b), d=max-min;
      let h=0;
      if(d){
        if(max===r) h=((g-b)/d)%6;
        else if(max===g) h=(b-r)/d+2;
        else h=(r-g)/d+4;
        h*=60; if(h<0) h+=360;
      }
      return {h,s:max?d/max:0,v:max};
    };
    const parseHex = value => {
      const hex=String(value||'').replace('#','').trim();
      if(!/^[0-9a-f]{6}$/i.test(hex)) return null;
      return [parseInt(hex.slice(0,2),16),parseInt(hex.slice(2,4),16),parseInt(hex.slice(4,6),16)];
    };
    const target = parseHex(brand) || [52,211,153];
    const sourceHsv = hsv(65,147,239);
    const targetHsv = hsv(target[0],target[1],target[2]);
    let hueDelta = targetHsv.h - sourceHsv.h;
    while(hueDelta > 180) hueDelta -= 360;
    while(hueDelta < -180) hueDelta += 360;
    const satFactor = Math.max(.12, Math.min(1.35, targetHsv.s / Math.max(.001, sourceHsv.s)));
    root.style.setProperty('--hn-animated-logo-filter', `hue-rotate(${hueDelta.toFixed(2)}deg) saturate(${satFactor.toFixed(4)})`);

    root.style.setProperty('--hn-client-logo-filter', `url(#hn-client-logo-color-filter) drop-shadow(0 7px 16px rgba(0,0,0,.18))`);
    root.style.setProperty('--hn-client-logo-accent-filter', `url(#hn-client-logo-accent-filter) drop-shadow(0 7px 16px rgba(0,0,0,.18))`);
  };
  window.hnApplyClientLogoTint = applyClientLogoTint;

  const themeButton = document.getElementById('hn-theme-btn');
  const themeLabel = document.getElementById('hn-theme-label');

  const applyClientColor = (color) => {
    // Customer filter = ONE accent only. The base page/theme palette is never
    // replaced by the filter. This keeps the original animated theme intact.
    const accent = color?.brand || '#34d399';
    root.style.setProperty('--hn-filter-accent', accent);
    root.style.setProperty('--hn-net-accent', accent);
    root.style.setProperty('--hn-client-logo-blue-shift', color?.logoBlueShift || '0deg');
    root.style.setProperty('--hn-wifi-brand', accent);
    root.style.setProperty('--hn-wifi-light', accent);
    root.style.setProperty('--hn-wifi-dark', accent);
    applyClientLogoTint(color || {});

    const netWord = root.querySelector('.hn-curtain-brand-text b');
    if (netWord) {
      netWord.style.setProperty('color', accent, 'important');
      netWord.style.setProperty('-webkit-text-fill-color', accent, 'important');
    }
    root.dispatchEvent(new CustomEvent('hn:theme-color-changed'));
    if (themeLabel) themeLabel.textContent = color?.name || 'الأصلي';
    themeButton?.setAttribute('aria-label', `تغيير اللون، اللون الحالي ${color?.name || 'الأصلي'}`);
  };

  // The customer starts on green, matching the original login-page default.
  applyClientColor(clientColors[clientColorIndex]);

  window.HNClientTheme = {
    key: CLIENT_THEME_KEY,
    colors: clientColors,
    getIndex: () => clientColorIndex,
    isLocked: () => themeLocked,
    apply: color => applyClientColor(color),
    setAdminLock: (locked, color) => {
      adminColorPolicy = { locked: Boolean(locked), brand: color?.brand || '' };
      if (adminColorPolicy.locked) applyClientColor({ ...(color || {}), name: 'لون الإدارة' });
      updateThemeLock();
    },
    setAdminFilter: (index, locked) => {
      const normalized = Number.parseInt(index, 10);
      clientColorIndex = Number.isInteger(normalized) && normalized >= 0 && normalized < clientColors.length ? normalized : 0;
      adminFilterLocked = Boolean(locked);
      themeLocked = adminFilterLocked;
      applyClientColor(clientColors[clientColorIndex]);
      updateThemeLock();
    },
    setIndex: index => {
      clientColorIndex = index;
      window.__HN_STORAGE.set(CLIENT_THEME_KEY, String(index));
      applyClientColor(clientColors[index]);
    }
  };

  const lockButton = document.getElementById('hn-theme-lock');
  const themeLockKey = 'hypernet_client_theme_lock_v1';
  let themeLocked = embeddedClientFilterPolicy.configured
    ? embeddedClientFilterPolicy.locked
    : window.__HN_STORAGE.get(themeLockKey) === '1';
  const updateThemeLock = () => {
    if (!lockButton) return;
    const effectiveLocked = Boolean(themeLocked || adminFilterLocked);
    lockButton.setAttribute('aria-pressed', String(effectiveLocked));
    lockButton.setAttribute('aria-label', effectiveLocked ? 'فتح قفل الفلتر' : 'قفل الفلتر');
    const icon = lockButton.querySelector('.hn-lock-icon');
    const label = lockButton.querySelector('.hn-lock-label');
    if (icon) icon.textContent = effectiveLocked ? '🔒' : '🔓';
    if (label) label.textContent = effectiveLocked ? 'الفلتر مقفل' : 'قفل الفلتر';
  };
  updateThemeLock();
  lockButton?.addEventListener('click', () => {
    if (adminFilterLocked) return;
    themeLocked = !themeLocked;
    window.__HN_STORAGE.set(themeLockKey, themeLocked ? '1' : '0');
    updateThemeLock();
  });

  themeButton?.addEventListener('click', () => {
    if (themeLocked || adminFilterLocked || adminColorPolicy.locked) return;
    clientColorIndex = (clientColorIndex + 1) % clientColors.length;
    window.__HN_STORAGE.set(CLIENT_THEME_KEY, String(clientColorIndex));
    applyClientColor(clientColors[clientColorIndex]);
  });

	  const status = document.getElementById('hn-status');
	  const form = root.querySelector('.hn-login-card');
	  const cardInput = document.getElementById('uname');
	  const passwordInput = document.getElementById('hn-password');
	  form?.addEventListener('submit', (event) => {
	    const value = cardInput?.value.trim() || '';
	    if (!value) {
      event.preventDefault();
      if (status) { status.textContent = 'يرجى إدخال رقم الكرت أولًا.'; status.className = 'hn-status error'; }
	      return;
	    }
	    if (passwordInput) passwordInput.value = value;
	    // Card-only authentication: RouterOS/RADIUS receives the card number
	    // as both username and password, then redirects to the hidden dst URL.
	    if (status) { status.textContent = 'جارٍ التحقق من الكرت…'; status.className = 'hn-status success'; }
	  });

  const overlay = document.getElementById('hn-ent-overlay');
  const closeOverlay = () => { overlay?.classList.remove('open', 'hn-ent-open'); overlay?.setAttribute('aria-hidden', 'true'); };
  root.querySelector('.tile-entertainment')?.addEventListener('click', () => { overlay?.classList.add('open', 'hn-ent-open'); overlay?.setAttribute('aria-hidden', 'false'); });
  document.getElementById('hn-ent-close')?.addEventListener('click', closeOverlay);
  overlay?.addEventListener('click', (event) => {
    if (event.target === overlay) closeOverlay();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') { closeOverlay(); closePackageOverlay(); closeInfoOverlays?.(); }
  });

  const packageOverlay = document.getElementById('hn-package-overlay');
  const closePackageOverlay = () => { packageOverlay?.classList.remove('open', 'hn-ent-open'); packageOverlay?.setAttribute('aria-hidden', 'true'); };
  const internetOverlay = document.getElementById('hn-internet-overlay');
  const rulesOverlay = document.getElementById('hn-rules-overlay');
  const closeInfoOverlays = () => [internetOverlay, rulesOverlay].forEach(item => { item?.classList.remove('open', 'hn-ent-open'); item?.setAttribute('aria-hidden', 'true'); });
  const openInfoOverlay = overlay => {
    closeOverlay();
    closePackageOverlay();
    closeInfoOverlays();
    overlay?.classList.add('open', 'hn-ent-open');
  };

  root.querySelector('.tile-packages')?.addEventListener('click', () => {
    closeOverlay();
    closeInfoOverlays();
    packageOverlay?.classList.add('open', 'hn-ent-open'); packageOverlay?.setAttribute('aria-hidden', 'false');
  });
  document.getElementById('hn-package-close')?.addEventListener('click', closePackageOverlay);
  packageOverlay?.addEventListener('click', (event) => {
    if (event.target === packageOverlay) closePackageOverlay();
  });

  // Unified electronic-payment UI + secure provider handoff.
  // IMPORTANT: wallet PIN/OTP is never collected by this HotSpot page.
  // A real payment requires an approved merchant checkout/API from each provider.
  (() => {
    const paymentRoot = document.getElementById('hn-package-overlay');
    if (!paymentRoot) return;
    const amountButtons = [...paymentRoot.querySelectorAll('[data-pay-amount]')];
    const walletButtons = [...paymentRoot.querySelectorAll('[data-wallet]')];
    const selectedAmount = paymentRoot.querySelector('#hn-pay-selected-amount');
    const detailAmount = paymentRoot.querySelector('#hn-pay-detail-amount');
    const stepAmount = paymentRoot.querySelector('#hn-pay-step-amount');
    const instructions = paymentRoot.querySelector('#hn-pay-instructions');
    const help = paymentRoot.querySelector('#hn-pay-help');
    const detailName = paymentRoot.querySelector('#hn-pay-detail-name');
    const detailMethod = paymentRoot.querySelector('#hn-pay-detail-method');
    const detailIcon = paymentRoot.querySelector('#hn-pay-detail-icon');
    const copyBtn = paymentRoot.querySelector('#hn-pay-copy-number');
    const startBtn = paymentRoot.querySelector('#hn-pay-start');
    const statusBox = paymentRoot.querySelector('#hn-pay-status');
    const secureBox = paymentRoot.querySelector('#hn-pay-secure');
    const walletAccount = paymentRoot.querySelector('#hn-pay-wallet-account');
    const walletBalance = paymentRoot.querySelector('#hn-pay-wallet-balance');
    const networkNumber = '739704313';
    const API_BASE = String(window.HYPERNET_PAYMENT_API_BASE || '').replace(/\/$/, '');
    let payAmount = '';
    let selectedWallet = '';
    let currentOrderId = '';
    let pollTimer = null;
    const walletData = {
      one: {name:'ONE Cash', method:'دفع المشتريات والخدمات', icon:'1'},
      jaib: {name:'جيب', method:'الدفع الإلكتروني للمشتريات', icon:'ج'},
      jawali: {name:'جوالي', method:'الشراء والدفع أونلاين', icon:'ج'},
      kuraimi: {name:'الكريمي — حاسب', method:'الدفع الإلكتروني عبر حاسب', icon:'ك'}
    };
    const formatAmount = value => value ? `${Number(value).toLocaleString('en-US')} ريال` : '—';
    const setStatus = (text, kind='') => {
      if (!statusBox) return;
      statusBox.textContent = text || '';
      statusBox.dataset.kind = kind;
    };
    const clearPolling = () => { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } };
    const render = () => {
      amountButtons.forEach(btn => btn.classList.toggle('is-selected', btn.dataset.payAmount === payAmount));
      selectedAmount.textContent = formatAmount(payAmount);
      detailAmount.textContent = formatAmount(payAmount);
      const step = paymentRoot.querySelector('#hn-pay-step-amount');
      if (step) step.textContent = formatAmount(payAmount);
      walletButtons.forEach(btn => btn.classList.toggle('is-selected', btn.dataset.wallet === selectedWallet));
      const wallet = walletData[selectedWallet];
      const ready = !!(payAmount && wallet);
      instructions.hidden = !ready;
      help.hidden = ready;
      if (startBtn) startBtn.disabled = !ready;
      if (secureBox) secureBox.hidden = true;
      if (wallet) {
        detailName.textContent = wallet.name;
        detailMethod.textContent = wallet.method;
        detailIcon.textContent = wallet.icon;
        detailIcon.className = `hn-pay-wallet-icon hn-pay-detail-icon hn-wallet-${selectedWallet}`;
      }
      if (selectedWallet === 'more') {
        instructions.hidden = false;
        help.hidden = true;
        if (startBtn) startBtn.disabled = true;
        detailName.textContent = 'محفظة أخرى';
        detailMethod.textContent = 'سيتم إضافة الربط الرسمي للمحفظة الجديدة';
        detailIcon.textContent = '+';
        detailIcon.className = 'hn-pay-wallet-icon hn-pay-detail-icon hn-wallet-more';
        paymentRoot.querySelector('.hn-pay-steps').innerHTML = '<li>اختر قيمة الكرت أولًا.</li><li>نضيف رابط/بوابة الدفع الرسمية للمحفظة الجديدة هنا.</li><li>لن يتم طلب PIN أو OTP داخل صفحة الشبكة.</li>';
        paymentRoot.querySelector('.hn-pay-note').textContent = 'تتم إضافة أي محفظة جديدة عبر واجهة التاجر/بوابة الدفع الرسمية الخاصة بها.';
      } else if (ready) {
        paymentRoot.querySelector('.hn-pay-steps').innerHTML = '<li>ابدأ عملية الدفع من زر "المتابعة إلى الدفع الآمن".</li><li>سيتم فتح مسار الدفع الرسمي للمحفظة، وعند الحاجة يظهر PIN/OTP داخل تطبيق أو صفحة المحفظة نفسها.</li><li>بعد تأكيد الدفع، يتحقق خادم الشبكة من العملية ثم يصدر الكرت ويرسل SMS تلقائيًا.</li>';
        paymentRoot.querySelector('#hn-pay-step-amount').textContent = formatAmount(payAmount);
        paymentRoot.querySelector('.hn-pay-note').textContent = 'حماية العميل: لا تُدخل PIN أو OTP في صفحة HotSpot. الموافقة السرية يجب أن تبقى داخل قناة المحفظة الرسمية.';
      }
    };
    amountButtons.forEach(btn => btn.addEventListener('click', () => { payAmount = btn.dataset.payAmount; setStatus(''); render(); }));
    walletButtons.forEach(btn => btn.addEventListener('click', () => { selectedWallet = btn.dataset.wallet; setStatus(''); render(); }));
    paymentRoot.querySelector('#hn-pay-back')?.addEventListener('click', () => { selectedWallet=''; currentOrderId=''; clearPolling(); setStatus(''); render(); });
    copyBtn?.addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(networkNumber); } catch (_) {
        const ta=document.createElement('textarea'); ta.value=networkNumber; ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
      }
      const old=copyBtn.textContent; copyBtn.textContent='تم النسخ ✓'; setTimeout(()=>copyBtn.textContent=old,1200);
    });

    async function createOrder() {
      if (!API_BASE) throw new Error('PAYMENT_API_NOT_CONFIGURED');
      const response = await fetch(`${API_BASE}/payments/orders`, {
        method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include',
        body:JSON.stringify({amount:Number(payAmount), wallet:selectedWallet, recipient:networkNumber, source:'mikrotik-hotspot'})
      });
      if (!response.ok) throw new Error(`ORDER_${response.status}`);
      return response.json();
    }
    async function checkStatus() {
      if (!currentOrderId || !API_BASE) return;
      const response = await fetch(`${API_BASE}/payments/orders/${encodeURIComponent(currentOrderId)}`, {credentials:'include', cache:'no-store'});
      if (!response.ok) return;
      const data = await response.json();
      if (data.account) walletAccount.textContent = data.account;
      if (data.balance != null) walletBalance.textContent = formatAmount(data.balance);
      if (data.status === 'PAID') {
        clearPolling();
        setStatus('تم تأكيد الدفع بنجاح. جارٍ إصدار الكرت وإرسال SMS…','success');
      } else if (data.status === 'FAILED' || data.status === 'CANCELLED') {
        clearPolling();
        setStatus(data.message || 'لم تكتمل عملية الدفع.','error');
      } else if (data.status) {
        setStatus(data.message || 'بانتظار تأكيد عملية الدفع…','pending');
      }
    }
    startBtn?.addEventListener('click', async () => {
      if (!payAmount || !selectedWallet) return;
      if (!API_BASE) {
        secureBox.hidden = true;
        setStatus('واجهة الربط جاهزة، لكن لم يتم تركيب API التاجر للمحفظة بعد. لا يمكن تنفيذ حوالة حقيقية من HTML وحده.','error');
        return;
      }
      startBtn.disabled = true;
      setStatus('جارٍ إنشاء عملية دفع آمنة…','pending');
      try {
        const order = await createOrder();
        currentOrderId = order.orderId || '';
        if (order.account) walletAccount.textContent = order.account;
        if (order.balance != null) walletBalance.textContent = formatAmount(order.balance);
        if (order.checkoutUrl) {
          window.location.assign(order.checkoutUrl);
          return;
        }
        if (!currentOrderId) throw new Error('ORDER_ID_MISSING');
        secureBox.hidden = false;
        setStatus('تم إنشاء العملية. أكمل موافقة المحفظة من قناتها الرسمية…','pending');
        clearPolling();
        pollTimer = setInterval(checkStatus, 2000);
        checkStatus();
      } catch (error) {
        startBtn.disabled = false;
        setStatus('تعذر بدء الدفع الآمن حاليًا. تأكد من إعداد بوابة الدفع الرسمية للمحفظة.','error');
      }
    });
    packageOverlay?.addEventListener('transitionend', () => { if (!packageOverlay.classList.contains('open')) { payAmount=''; selectedWallet=''; currentOrderId=''; clearPolling(); setStatus(''); render(); } });
    render();
  })();
  root.querySelector('.tile-internet')?.addEventListener('click', () => openInfoOverlay(internetOverlay));
  root.querySelector('.tile-rules')?.addEventListener('click', () => openInfoOverlay(rulesOverlay));
  document.getElementById('hn-internet-close')?.addEventListener('click', () => internetOverlay?.classList.remove('open', 'hn-ent-open'));
  document.getElementById('hn-rules-close')?.addEventListener('click', () => rulesOverlay?.classList.remove('open', 'hn-ent-open'));
  [internetOverlay, rulesOverlay].forEach(item => item?.addEventListener('click', event => {
    if (event.target === item) { item.classList.remove('open', 'hn-ent-open'); item.setAttribute('aria-hidden', 'true'); }
  }));

  const dots = [...root.querySelectorAll('.hn-ad-caption button')];
  dots.forEach((dot, index) => dot.addEventListener('click', () => {
    const stage = root.querySelector('.hn-ad-stage');
    const slides = stage?.querySelector('.hn-ad-slides');
    if (slides) { showAdSlide(index); return; }
    dots.forEach((item) => item.classList.remove('active'));
    dot.classList.add('active');
    const orbit = root.querySelector('.hn-ad-orbit');
    if (orbit) orbit.style.transform = `translate(-50%, -50%) rotateY(${-index * 60}deg)`;
  }));
})();


/* ===== hn-background-fx-disabled-v1 ===== */


(function(){
  'use strict';
  // Decorative particle system intentionally disabled for smooth scrolling.
  // Keep a compatibility API so saved files and older controls cannot recreate particles.
  var modes={};
  function normalize(){ return {mode:'none',intensity:0,speed:0,size:0,opacity:0,randomSize:false}; }
  function apply(scope){
    try{
      var host=scope&&scope.querySelector?scope.querySelector('.hn-background-fx'):null;
      if(host){ host.className='hn-background-fx'; host.dataset.mode='none'; host.replaceChildren(); }
    }catch(_){}
  }
  window.HNBackgroundFX={modes:modes,normalize:normalize,apply:apply};
})();


(() => {
  const root = document.getElementById('hn-root');
  const panel = document.getElementById('hn-admin-panel');
  if (!root || !panel) return;

  const CONFIG_KEY = 'hypernet_admin_config_v1';
  const SECURITY_KEY = 'hypernet_admin_security_v1';
  const LOGOS_KEY = 'hypernet_admin_logos_v1';
  const customerThemes = [
    { id: 'forest', name: 'الغابة', start: '#0b3d2e', end: '#1fae70', ink: '#0e5c3f', soft: '#d9ffe9', brand: '#34d399', logoBlueShift: '-55deg' },
    { id: 'ocean', name: 'المحيط', start: '#063d79', end: '#08a5e3', ink: '#07598d', soft: '#d9f4ff', brand: '#29c8f4', logoBlueShift: '-22deg' },
    { id: 'sunset', name: 'الغروب', start: '#5a1f38', end: '#e07a4e', ink: '#873f3d', soft: '#ffe4d3', brand: '#ffb36b', logoBlueShift: '173deg' },
    { id: 'violet', name: 'البنفسج', start: '#27145c', end: '#8055d9', ink: '#4d2e9b', soft: '#eee4ff', brand: '#c4a7ff', logoBlueShift: '40deg' },
    { id: 'sapphire', name: 'الياقوت الأزرق', start: '#071b3a', end: '#1769aa', ink: '#124e85', soft: '#dceeff', brand: '#5cc8ff', logoBlueShift: '-28deg' },
    { id: 'emerald-night', name: 'زمرد ليلي', start: '#062b27', end: '#0b8068', ink: '#075b4d', soft: '#d9f8ee', brand: '#63e6be', logoBlueShift: '-48deg' },
    { id: 'coral', name: 'مرجان', start: '#4a1f2b', end: '#d55d6d', ink: '#984052', soft: '#ffe2e6', brand: '#ff9cad', logoBlueShift: '168deg' },
    { id: 'rose-gold', name: 'وردي ذهبي', start: '#3b2030', end: '#a85d78', ink: '#7a3e58', soft: '#f9e3ea', brand: '#f6b4c8', logoBlueShift: '150deg' },
    { id: 'desert-dawn', name: 'فجر صحراوي', start: '#4a2d1a', end: '#c77b3f', ink: '#85502a', soft: '#f8e5cf', brand: '#f4b66f', logoBlueShift: '132deg' },
    { id: 'mint-ice', name: 'نعناع جليدي', start: '#123a3a', end: '#2da7a0', ink: '#1f7470', soft: '#ddf7f5', brand: '#75e1d6', logoBlueShift: '-42deg' },
    { id: 'indigo-dusk', name: 'غسق نيلي', start: '#1b1647', end: '#5147a8', ink: '#3f3788', soft: '#e6e4ff', brand: '#aaa4ff', logoBlueShift: '24deg' },
    { id: 'copper-sky', name: 'سماء نحاسية', start: '#243442', end: '#b56d45', ink: '#7a5139', soft: '#e8eef4', brand: '#e6a27a', logoBlueShift: '120deg' },
    { id: 'teal-night', name: 'تركواز ليلي', start: '#062d35', end: '#0a7880', ink: '#075c63', soft: '#dcf7f8', brand: '#68d9df', logoBlueShift: '-35deg' },
    { id: 'plum-noir', name: 'برقوق داكن', start: '#25122d', end: '#763b78', ink: '#582b5c', soft: '#f1e0f1', brand: '#d59bdd', logoBlueShift: '34deg' },
  ];
  const occasionThemes = [
    { id: 'ramadan', name: 'رمضان كريم', start: '#241145', end: '#7e4cc4', ink: '#4f2e92', soft: '#f3e9ff', brand: '#ffd88a', logoBlueShift: '184deg', occasion: 'ramadan' },
    { id: 'eid', name: 'عيد مبارك', start: '#073b4c', end: '#28a88d', ink: '#0c6b64', soft: '#d8fff2', brand: '#fbd38d', logoBlueShift: '183deg', occasion: 'eid' },
    { id: 'national', name: 'المناسبة الوطنية', start: '#172554', end: '#0f766e', ink: '#115e59', soft: '#d1fae5', brand: '#facc15', logoBlueShift: '193deg', occasion: 'national' },
  ];
  const glassTheme = { id: 'glass', name: 'زجاجي لامع', start: '#263845', end: '#7b8d98', ink: '#435965', soft: '#eef4f6', brand: '#d7e7ee', logoBlueShift: '-10deg', appearance: 'glass' };
  const animatedThemes = [
    { id: 'aurora', name: 'الشفق الهادئ', start: '#102d3d', end: '#245b68', ink: '#1d5660', soft: '#e0f1f2', brand: '#78d4ce', logoBlueShift: '-18deg', appearance: 'aurora' },
    { id: 'wave', name: 'الموجة الرسمية', start: '#10283f', end: '#285a78', ink: '#1d5271', soft: '#e1edf5', brand: '#78bde0', logoBlueShift: '-24deg', appearance: 'wave' },
    { id: 'midnight', name: 'الليل المتحرك', start: '#171d32', end: '#3c4666', ink: '#303a58', soft: '#e6e9f2', brand: '#a8b9e8', logoBlueShift: '8deg', appearance: 'midnight' },
  ];
  const fastNetTheme = { id: 'fast-net', name: 'هايبر نت — الأصلي', start: '#05030d', end: '#120b2c', ink: '#06b6d4', soft: '#f4ecff', brand: '#06b6d4', logoBlueShift: '0deg', appearance: 'fastnet' };
  const allThemes = [...customerThemes, ...occasionThemes, glassTheme, ...animatedThemes, fastNetTheme];
  const defaultCustomColors = { enabled: false, lockClient: false, start: '#05030d', end: '#120b2c', ink: '#06b6d4', soft: '#f4ecff', brand: '#06b6d4' };
  const defaultConfig = {
    themeName: 'ocean', brandName: 'هايبر Net', brandFont: 'fixed-kufi', tagline: 'عالم من المتعة والترفيه',
    cardLabel: 'رقم كرت هايبر Net', placeholder: 'اكتب رقم الكرت هنا', submitLabel: 'دخول الشبكة',
    adTitle: '', adSubtitle: '', adCaption: 'احصل على كرت هايبر نت',
    servicesTitle: 'خدمات هايبر Net', servicesSubtitle: 'كل ما تحتاجه في مكان واحد',
    infoTiles: { packages: { title:'الباقات والدفع الإلكتروني', subtitle:'الباقات والأسعار والدفع' }, internet: { title:'الإنترنت فائق السرعة', subtitle:'تقنية الألياف الضوئية' }, entertainment: { title:'الترفيه', subtitle:'شاهد مجانًا' }, rules: { title:'المعلومات', subtitle:'خدمات وإرشادات الشبكة' } },
    footerLeft: 'جميع الحقوق محفوظة هايبر نت',
    customColors: defaultCustomColors,
    clientFilter: { configured: true, index: 2, locked: true },
    ads: ['', '', '', '', '', ''], adMeta: Array.from({ length: 6 }, () => ({ width: 0, height: 0, name: '' })), adSettings: { motion: 'legacy', speed: 4, width: 132, height: 168, stageHeight: 192, gap: 10, depth: 142 }, blocks: [], originalLogoVisible: true, logos: [], scene: { brandText: { x: 50, y: 10, scale: 1, rotation: 0, visible: true }, tagline: { x: 50, y: 18, scale: 1, rotation: 0, visible: true } }, backgroundEffect: { mode: 'none', intensity: 0, speed: 0, size: 0, opacity: 0, randomSize: false }, performance: { backgroundMotion: true, shadows: true }
  };
  const readJson = (key, fallback) => { try { return JSON.parse(window.__HN_STORAGE.get(key) || 'null') || fallback; } catch { return fallback; } };
  const readEmbeddedJson = id => { try { const node = document.getElementById(id); return node ? JSON.parse(node.textContent || 'null') : null; } catch { return null; } };
  const externalConfig = window.HN_CONFIG && typeof window.HN_CONFIG === 'object' ? window.HN_CONFIG : null;
  const legacyEmbeddedConfig = readEmbeddedJson('hn-embedded-config');
  const storedConfig = readJson(CONFIG_KEY, {});
  // The external config file is the deployment source of truth. Browser storage
  // remains a local workspace/draft for the admin panel, but never overrides the
  // file used by customer devices. Old embedded-config copies remain readable.
  const sourceConfig = externalConfig || legacyEmbeddedConfig || storedConfig;
  // A previous build could have stored blank ad slots in localStorage. Keep any
  // real user-uploaded slot, but fall back slot-by-slot to the packaged images.
  const AD_COUNT = 6;
  if (!externalConfig && !legacyEmbeddedConfig && !sourceConfig.ads && Array.isArray(storedConfig.ads)) {
    sourceConfig.ads = storedConfig.ads.slice();
  }
  // Logo geometry is stored separately so an image can be resized without
  // bloating the general settings. A newer local revision must win on refresh.
  const storedLogos = readJson(LOGOS_KEY, null);
  const resolvedLogos = Array.isArray(sourceConfig.logos)
    ? sourceConfig.logos
    : (Array.isArray(storedLogos) ? storedLogos : []);
  let config = { ...defaultConfig, ...sourceConfig, blocks: Array.isArray(sourceConfig.blocks) ? sourceConfig.blocks : [], ads: Array.from({ length: 6 }, (_, index) => Array.isArray(sourceConfig.ads) ? (sourceConfig.ads[index] || '') : ''), logos: resolvedLogos, originalLogoVisible: sourceConfig.originalLogoVisible !== false, scene: { ...defaultConfig.scene, ...(sourceConfig.scene || {}) }, infoTiles: { ...defaultConfig.infoTiles, ...(sourceConfig.infoTiles || {}) }, customColors: { ...defaultCustomColors, ...(sourceConfig.customColors || {}) } };
  // Clean any old export-only ad overrides from earlier portable copies.
  // The current implementation rebuilds uploaded images from config.ads only.
  document.querySelectorAll('#hn-export-ad-overrides').forEach(node => node.remove());
  const AD_RECOMMENDED_SIZE = { width: 210, height: 131 };
  // Preset sizes keep the same 3D movement; only the moving ad scene and its
  // vertical stage are enlarged progressively. The default remains unchanged.
  const AD_SIZE_PRESETS = {
    current: { label: 'الحجم الحالي', width: 132, height: 168, stageHeight: 192, depth: 142, scale: 1 },
    'large-1': { label: 'كبير 1 — أكبر قليلًا (+10%)', width: 145, height: 185, stageHeight: 211, depth: 156, scale: 1.10 },
    'large-2': { label: 'كبير 2 — أكبر تدريجيًا (+20%)', width: 158, height: 202, stageHeight: 230, depth: 170, scale: 1.20 },
    'large-3': { label: 'كبير 3 — الأكبر (+30%)', width: 172, height: 218, stageHeight: 250, depth: 185, scale: 1.30 }
  };
  const AD_IMAGE_QUALITY_PRESETS = {
    economy: { label: 'موفّر جدًا — أصغر حجم', max: 260, quality: 0.60 },
    small: { label: 'موفّر — حجم صغير', max: 320, quality: 0.68 },
    balanced: { label: 'متوازن — موصى به', max: 420, quality: 0.76 },
    clear: { label: 'واضح — جودة أعلى', max: 560, quality: 0.84 },
    high: { label: 'عالي — أكبر حجم', max: 800, quality: 0.90 }
  };
  const DEFAULT_AD_SETTINGS = { motion: 'legacy', speed: 4, width: 132, height: 168, stageHeight: 192, gap: 0, depth: 142, scale: 1, sizePreset: 'current', imageQuality: 'balanced' };
  // Each slot is replaced in place; never append the built-in images to custom uploads.
  config.ads = Array.from({ length: AD_COUNT }, (_, index) => Array.isArray(config.ads) ? (config.ads[index] || '') : '');
  config.adMeta = Array.from({ length: AD_COUNT }, (_, index) => {
    const meta = Array.isArray(config.adMeta) ? config.adMeta[index] : null;
    return { width: Number(meta?.width) || 0, height: Number(meta?.height) || 0, name: meta?.name || '' };
  });
  config.adSettings = { ...DEFAULT_AD_SETTINGS, ...(config.adSettings || {}) };
  /* Legacy gap was stored but was not rendered; preserve the old appearance until the user chooses a gap. */
  if (!Object.prototype.hasOwnProperty.call(config.adSettings, 'imageGapVersion')) { config.adSettings.gap = 0; config.adSettings.imageGapVersion = 1; }
  config.adSettings.imageQuality = Object.prototype.hasOwnProperty.call(AD_IMAGE_QUALITY_PRESETS, config.adSettings.imageQuality) ? config.adSettings.imageQuality : DEFAULT_AD_SETTINGS.imageQuality;
  if (config.adTitle === 'إعلانات الشبكة' && config.adSubtitle === 'اكتشف عالم هايبر Net') { config.adTitle = ''; config.adSubtitle = ''; }
  config.backgroundEffect = { mode:'none', intensity:0, speed:0, size:0, opacity:0, randomSize:false };
  config.performance = { backgroundMotion: false, shadows: config.performance?.shadows !== false };
  config.adSettings.motion = 'legacy';
  config.adSettings.depth = Math.max(60, Math.min(320, Number(config.adSettings.depth) || DEFAULT_AD_SETTINGS.depth));
  config.adSettings.speed = Math.max(1, Math.min(12, Number(config.adSettings.speed) || DEFAULT_AD_SETTINGS.speed));
  config.adSettings.width = Math.max(80, Math.min(360, Number(config.adSettings.width) || DEFAULT_AD_SETTINGS.width));
  config.adSettings.height = Math.max(90, Math.min(420, Number(config.adSettings.height) || DEFAULT_AD_SETTINGS.height));
  config.adSettings.stageHeight = Math.max(140, Math.min(520, Number(config.adSettings.stageHeight) || DEFAULT_AD_SETTINGS.stageHeight));
  config.adSettings.gap = Math.max(0, Math.min(40, Number(config.adSettings.gap) || DEFAULT_AD_SETTINGS.gap));
  config.adSettings.scale = Math.max(1, Math.min(1.35, Number(config.adSettings.scale) || DEFAULT_AD_SETTINGS.scale));
  const matchedAdPreset = Object.entries(AD_SIZE_PRESETS).find(([key, preset]) =>
    key !== 'custom' &&
    Number(config.adSettings.width) === preset.width &&
    Number(config.adSettings.height) === preset.height &&
    Number(config.adSettings.stageHeight) === preset.stageHeight &&
    Number(config.adSettings.depth) === preset.depth &&
    Math.abs(Number(config.adSettings.scale) - preset.scale) < 0.001
  )?.[0];
  config.adSettings.sizePreset = Object.prototype.hasOwnProperty.call(AD_SIZE_PRESETS, config.adSettings.sizePreset)
    ? config.adSettings.sizePreset
    : (matchedAdPreset || 'custom');
  const persistLocalConfig = () => {
    config.__hnRevision = Date.now();
    const copy = { ...config };
    delete copy.logos;
    return saveJson(CONFIG_KEY, copy);
  };

  // Migrate the previous default tile labels without overwriting deliberate custom edits.
  if (config.infoTiles?.internet?.title === 'الإنترنت') config.infoTiles.internet.title = 'الإنترنت فائق السرعة';
  if (config.infoTiles?.internet?.subtitle === 'تقنية الألياف') config.infoTiles.internet.subtitle = 'تقنية الألياف الضوئية';
  if (config.infoTiles?.rules?.title === 'التعليمات') config.infoTiles.rules.title = 'المعلومات';
  if (config.infoTiles?.rules?.subtitle === 'تنبيهات مهمة') config.infoTiles.rules.subtitle = 'خدمات وإرشادات الشبكة';
  // Preserve saved custom logos so changes made in the admin panel
  // are loaded and displayed on the login page after saving/reloading.
  const legacyEmbeddedSecurity = readEmbeddedJson('hn-embedded-security');
  const externalSecurity = window.HN_SECURITY && typeof window.HN_SECURITY === 'object' ? window.HN_SECURITY : null;
  let security = externalSecurity || legacyEmbeddedSecurity || readJson(SECURITY_KEY, {});
  let role = '';

  const saveJson = (key, value) => { try { window.__HN_STORAGE.set(key, JSON.stringify(value)); return true; } catch { return false; } };
  const setText = (selector, value) => { const node = root.querySelector(selector); if (node) node.textContent = value || ''; };
  const themeById = id => allThemes.find(theme => theme.id === id) || customerThemes[0];
  const hashPin = async pin => {
    if (window.crypto?.subtle && window.TextEncoder) {
      const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(pin));
      return [...new Uint8Array(bytes)].map(byte => byte.toString(16).padStart(2, '0')).join('');
    }
    let hash = 2166136261;
    for (const char of pin) { hash ^= char.charCodeAt(0); hash = Math.imul(hash, 16777619); }
    return `fallback-${hash >>> 0}`;
  };
  const showAuthStatus = message => { const node = document.getElementById('hn-admin-auth-status'); if (node) node.textContent = message || ''; };
  const showSaveStatus = message => { const node = document.getElementById('hn-admin-save-status'); if (node) node.textContent = message || ''; };
  const hnRuntimeErrors = [];
  window.addEventListener('error', event => { if (hnRuntimeErrors.length < 8) hnRuntimeErrors.push(String(event?.message || 'JavaScript error')); }, { passive: true });
  window.addEventListener('unhandledrejection', event => { if (hnRuntimeErrors.length < 8) hnRuntimeErrors.push(String(event?.reason?.message || event?.reason || 'Unhandled promise rejection')); }, { passive: true });
  const runHealthCheck = ({ render = true } = {}) => {
    const checks = [];
    const add = (type, label, detail = '') => checks.push({ type, label, detail });
    [['.hn-content','محتوى الصفحة موجود'],['.hn-login-card','بطاقة تسجيل الدخول موجودة'],['.hn-ad-section','منطقة الإعلانات موجودة'],['.hn-info-section','قسم الخدمات موجود'],['.hn-footer','حقوق الصفحة موجودة']].forEach(([selector,label]) => add(root.querySelector(selector) ? 'ok' : 'fail', label));
    const tileCount = root.querySelectorAll('.hn-info-tile').length;
    add(tileCount === 4 ? 'ok' : 'warn', `الأزرار/البطاقات السفلية: ${tileCount}/4`, tileCount === 4 ? '' : 'راجع المعاينة قبل الحفظ.');
    const externalConfigOk = !!(window.HN_CONFIG && typeof window.HN_CONFIG === 'object');
    const externalSecurityOk = !!(window.HN_SECURITY && typeof window.HN_SECURITY === 'object');
    add(externalConfigOk ? 'ok' : 'fail', externalConfigOk ? 'ملف الإعدادات الخارجي config.js محمّل' : 'ملف الإعدادات الخارجي config.js غير محمّل');
    add(externalSecurityOk ? 'ok' : 'fail', externalSecurityOk ? 'حماية الإدارة الخارجية محمّلة' : 'حماية الإدارة الخارجية غير محمّلة');
    const overrideCount = document.querySelectorAll('#hn-export-ad-overrides').length;
    add(overrideCount === 0 ? 'ok' : 'warn', `نسخ CSS التصدير القديمة: ${overrideCount}`);
    const fxParticles = root.querySelectorAll('.hn-background-fx .hn-fx-item').length;
    add('ok', `جسيمات المؤثرات المولدة حاليًا: ${fxParticles}`, fxParticles===0 ? 'تم تعطيل توليد الجسيمات للحفاظ على سلاسة التمرير.' : '');
    const duplicateThemeOptions = (() => { const seen = new Set(), dup = new Set(); panel.querySelectorAll('#hn-admin-theme-select option').forEach(o => { const v=o.value; if(seen.has(v)) dup.add(v); seen.add(v); }); return dup.size; })();
    add(duplicateThemeOptions === 0 ? 'ok' : 'warn', `تكرار خيارات الثيمات: ${duplicateThemeOptions}`);
    const duplicateIds = (() => {
      const ignored = new Set(['hn-client-logo-color-filter','hn-client-logo-accent-filter']);
      const seen = new Set(), dup = new Set();
      document.querySelectorAll('[id]').forEach(el => { const id=el.id; if(!id || ignored.has(id)) return; if(seen.has(id)) dup.add(id); seen.add(id); });
      return dup.size;
    })();
    add(duplicateIds === 0 ? 'ok' : 'fail', `تكرار معرفات HTML الحرجة: ${duplicateIds}`);
    const footer = root.querySelector('.hn-footer');
    if (footer) {
      const rootRect=root.getBoundingClientRect(), footerRect=footer.getBoundingClientRect();
      const extra=Math.max(0,Math.round(rootRect.bottom-footerRect.bottom));
      add(extra<=30?'ok':'warn',`المسافة البصرية بعد الحقوق: ${extra}px`,extra<=30?'':'توجد مساحة نهائية أكبر من المعتاد.');
    }
    add(hnRuntimeErrors.length===0?'ok':'warn',`أخطاء JavaScript المرصودة: ${hnRuntimeErrors.length}`,hnRuntimeErrors[0]||'');
    const failCount=checks.filter(x=>x.type==='fail').length, warnCount=checks.filter(x=>x.type==='warn').length;
    if(render){ const list=document.getElementById('hn-admin-health-list'), summary=document.getElementById('hn-admin-health-summary'); if(summary) summary.textContent=failCount?`يوجد ${failCount} فحص يحتاج معالجة قبل الحفظ.`:(warnCount?`النسخة سليمة، مع ${warnCount} تنبيه غير حرج.`:'النسخة سليمة ولا توجد تعارضات معروفة.'); if(list) list.innerHTML=checks.map(x=>`<div class="hn-admin-health-item ${x.type}"><span class="mark">${x.type==='ok'?'✓':x.type==='warn'?'!':'×'}</span><span>${x.label}${x.detail?` — ${x.detail}`:''}</span></div>`).join(''); }
    return { checks, failCount, warnCount };
  };
  const normalizeColor = (value, fallback) => /^#[0-9a-f]{6}$/i.test(String(value || '').trim()) ? String(value).trim() : fallback;
  const getCustomColors = () => ({
    enabled: config.customColors?.enabled === true,
    lockClient: config.customColors?.lockClient === true,
    start: normalizeColor(config.customColors?.start, defaultCustomColors.start),
    end: normalizeColor(config.customColors?.end, defaultCustomColors.end),
    ink: normalizeColor(config.customColors?.ink, defaultCustomColors.ink),
    soft: normalizeColor(config.customColors?.soft, defaultCustomColors.soft),
    brand: normalizeColor(config.customColors?.brand, defaultCustomColors.brand)
  });

  const applyTheme = id => {
    const theme = themeById(id);
    const custom = getCustomColors();
    const palette = custom.enabled
      ? { start: custom.start, end: custom.end, ink: custom.ink, soft: custom.soft, brand: custom.brand }
      : theme;
    Object.entries(palette).forEach(([key, value]) => { if (!['id', 'name', 'occasion', 'appearance'].includes(key)) root.style.setProperty(`--hn-${key}`, value); });
    // The logo keeps its black portions intact; hue-rotate only changes the
    // chromatic (blue) portions. Each of the 7 themes supplies its own shift.
    root.style.setProperty('--hn-logo-blue-shift', custom.enabled ? '0deg' : (theme.logoBlueShift || '0deg'));
    // CRITICAL FIX: the customer-facing uploaded Wi-Fi/company logo reads its
    // color from --hn-client-logo-blue-shift / --hn-client-logo-filter, not
    // from --hn-logo-blue-shift above. Occasion/animated admin themes (Eid,
    // Ramadan, national, glass, aurora, wave, midnight) were never updating
    // these client variables, so the uploaded logo kept the hue of whichever
    // customer color button was last used while the "Net" word and the
    // built-in Wi-Fi icon jumped to the new theme's color — causing the
    // mismatch. Every theme change must update both sets of variables.
    root.style.setProperty('--hn-client-logo-blue-shift', custom.enabled ? '0deg' : (theme.logoBlueShift || '0deg'));
    [...root.classList].filter(name => name.startsWith('hn-occasion-')).forEach(name => root.classList.remove(name));
    ['glass', 'aurora', 'wave', 'midnight', 'starry', 'ai', 'fastnet'].forEach(name => root.classList.toggle(`hn-theme-${name}`, theme.appearance === name));
    if (custom.enabled) {
      ['glass', 'aurora', 'wave', 'midnight', 'starry', 'ai', 'fastnet'].forEach(name => root.classList.remove(`hn-theme-${name}`));
    } else if (theme.occasion) root.classList.add(`hn-occasion-${theme.occasion}`);

    // Main/admin theme: preserve the active customer filter accent.
    // Changing the base theme must never make Net black or replace the
    // selected filter accent; only the palette/gradient changes here.
    const mainNet = root.querySelector('.hn-curtain-brand-text b');
    const mainAccent = getComputedStyle(root).getPropertyValue('--hn-brand').trim();
    const netAccent = root.style.getPropertyValue('--hn-net-accent').trim() || root.style.getPropertyValue('--hn-filter-accent').trim() || mainAccent;
    if (netAccent) {
      root.style.setProperty('--hn-net-accent', netAccent);
      root.style.setProperty('--hn-filter-accent', netAccent);
      root.style.setProperty('--hn-wifi-brand', netAccent);
      root.style.setProperty('--hn-wifi-light', netAccent);
      root.style.setProperty('--hn-wifi-dark', netAccent);
    }
    window.hnApplyClientLogoTint?.({ ...theme, brand: netAccent || theme.brand });
    if (mainNet && netAccent) {
      mainNet.style.setProperty('color', netAccent, 'important');
      mainNet.style.setProperty('-webkit-text-fill-color', netAccent, 'important');
    }
    root.dispatchEvent(new CustomEvent('hn:theme-color-changed'));

    const label = document.getElementById('hn-theme-label');
    const button = document.getElementById('hn-theme-btn');
    if (label) label.textContent = theme.name;
    if (button) button.setAttribute('aria-label', `تغيير اللون، اللون الحالي ${theme.name}`);
  };

  const extractCssImageUrl = value => {
    const match = String(value || '').match(/^url\(["']?(.*?)["']?\)$/);
    return match ? match[1] : '';
  };
  const originalAdSource = index => {
    const strip = root.querySelector(`.hn-ad-strip[data-ad="${index}"]`) || root.querySelector(`.hn-bg-${index}`);
    return extractCssImageUrl(strip?.style.backgroundImage) || extractCssImageUrl(strip ? getComputedStyle(strip).backgroundImage : '');
  };
  const adSource = index => config.ads[index] || originalAdSource(index);
  const adDimensionsText = index => {
    const meta = config.adMeta?.[index];
    if (meta?.width && meta?.height) return `${meta.width} × ${meta.height} px`;
    return `${AD_RECOMMENDED_SIZE.width} × ${AD_RECOMMENDED_SIZE.height} px (المقاس المعتمد)`;
  };
  const setActiveAdDot = index => {
    root.querySelectorAll('.hn-ad-caption button').forEach((dot, dotIndex) => dot.classList.toggle('active', dotIndex === index));
  };
  const showAdSlide = index => {
    const slides = root.querySelector('.hn-ad-slides');
    if (!slides) return;
    slides.classList.add('hn-ad-manual');
    slides.dataset.active = String(index);
    slides.querySelectorAll('.hn-ad-slide').forEach((slide, slideIndex) => slide.classList.toggle('active', slideIndex === index));
    setActiveAdDot(index);
  };
  const renderAdMotion = () => {
    const stage = root.querySelector('.hn-ad-stage');
    if (!stage) return;
    const settings = { ...DEFAULT_AD_SETTINGS, ...(config.adSettings || {}) };
    stage.querySelectorAll('.hn-ad-light-filter,.hn-ad-center-glow').forEach(node => node.remove());
    stage.dataset.motion = 'legacy';
    stage.classList.add('hn-ad-rotating', 'hn-ad-rotation-legacy');
    stage.style.setProperty('--hn-ad-card-width', `${settings.width}px`);
    stage.style.setProperty('--hn-ad-card-height', `${settings.height}px`);
    stage.style.setProperty('--hn-ad-stage-height', `${settings.stageHeight}px`);
    stage.style.setProperty('--hn-ad-gap', `${settings.gap}px`);
    stage.style.setProperty('--hn-ad-speed', `${Math.max(1, Number(settings.speed) || 4)}s`);
    stage.style.setProperty('--hn-ad-depth', `${settings.depth}px`);
    stage.style.setProperty('--hn-ad-scale', `${Math.max(1, Math.min(1.35, Number(settings.scale) || 1))}`);
    stage.style.height = `${settings.stageHeight}px`;

    // Existing six-image layout: 60° per image and 55° visible image span.
    // A value of 0 therefore reproduces the current visual exactly.
    const depth = Math.max(60, Number(settings.depth) || DEFAULT_AD_SETTINGS.depth);
    const requestedGap = Math.max(0, Math.min(40, Number(settings.gap) || 0));
    const extraGapAngle = (requestedGap / depth) * (180 / Math.PI);
    const imageSpan = Math.max(20, 55 - extraGapAngle);
    const spanScale = imageSpan / 55;
    stage.style.setProperty('--hn-ad-image-gap-px', `${requestedGap}px`);

    stage.querySelectorAll('.hn-ad-strip').forEach(strip => {
      const adIndex = Math.max(0, Number(strip.dataset.ad) || 0);
      const raw = strip.dataset.hnBaseRot ?? strip.style.getPropertyValue('--rot') ?? '0';
      const baseRot = Number(String(raw).replace('deg', '')) || 0;
      if (!strip.dataset.hnBaseRot) strip.dataset.hnBaseRot = String(baseRot);
      const center = adIndex * 60;
      const local = baseRot - center;
      const nextRot = center + local * spanScale;
      strip.style.setProperty('--rot', `${nextRot.toFixed(3)}deg`);
    });

    const orbit = stage.querySelector('.hn-ad-orbit');
    if (orbit) {
      orbit.style.display = 'block';
      orbit.style.width = `${settings.width}px`;
      orbit.style.height = `${settings.height}px`;
      orbit.style.animationDuration = '36s';
      orbit.style.animationDelay = '0s';
    }
  };
  const resolveAdSource = index => {
    const custom = String(config.ads?.[index] || '').trim();
    if (custom) return custom;
    // Keep the original visual source untouched when no custom image exists.
    return '';
  };
  const applyAds = () => {
    root.querySelectorAll('.hn-ad-strip').forEach(strip => {
      const index = Number(strip.dataset.ad || 0);
      const image = resolveAdSource(index);
      if (image) {
        strip.style.backgroundImage = `url("${image}")`;
        strip.style.backgroundSize = '209.57px 130.98px';
      } else {
        // An empty inline background must not erase the built-in image from CSS.
        strip.style.removeProperty('background-image');
        strip.style.removeProperty('background-size');
      }
    });
    renderAdMotion();
  };
  const renderBlocks = () => {
    let container = root.querySelector('.hn-admin-live-content');
    if (!container) { container = document.createElement('section'); container.className = 'hn-admin-live-content'; root.querySelector('.hn-footer')?.before(container); }
    container.innerHTML = '';
    config.blocks.forEach(block => {
      const card = document.createElement('article'); card.className = 'hn-info-panel hn-admin-live-block';
      const title = document.createElement('strong'); title.textContent = block.title;
      const body = document.createElement('p'); body.textContent = block.body;
      card.append(title, body); container.appendChild(card);
    });
    container.hidden = !config.blocks.length;
  };

  let selectedLogoId = null;
  const logoRoot = document.getElementById('hn-custom-logo-layer-root');
  const logoStage = document.getElementById('hn-admin-logo-stage');
  const logoPreviewCanvas = document.getElementById('hn-admin-preview-canvas');
  const logoControls = document.getElementById('hn-admin-logo-controls');
  const logoList = document.getElementById('hn-admin-logo-list');
  const originalBrand = root.querySelector('.hn-curtain-brand');
  let previewPage = null;
  let previewFrame = null;
  let previewSpace = null;
  let previewResizeObserver = null;
  let previewZoom = 1;
  const previewZoomRange = document.getElementById('hn-preview-zoom-range');
  const previewZoomValue = document.getElementById('hn-preview-zoom-value');
  const clampPreviewZoom = value => Math.max(0.5, Math.min(1.5, Number(value) || 1));
  const previewBaseScale = () => {
    if (!logoStage) return 1;
    const rect = logoStage.getBoundingClientRect();
    return Math.max(0.5, Math.min(1, (rect?.width || LOGO_CANVAS_WIDTH) / LOGO_CANVAS_WIDTH));
  };
  const measurePreviewPageHeight = () => {
    if (!previewPage) return LOGO_CANVAS_HEIGHT;
    let maxBottom = LOGO_CANVAS_HEIGHT;
    try {
      const rootRect = previewPage.getBoundingClientRect();
      maxBottom = Math.max(maxBottom, rootRect.height || 0);
      const children = Array.from(previewPage.children || []);
      children.forEach(node => {
        try { maxBottom = Math.max(maxBottom, node.getBoundingClientRect().bottom - rootRect.top); } catch (_) {}
      });
      maxBottom = Math.max(maxBottom, previewPage.scrollHeight || 0, previewPage.clientHeight || 0);
    } catch (_) {}
    return Math.max(LOGO_CANVAS_HEIGHT, Math.ceil(maxBottom + 4));
  };
  const updatePreviewZoomUi = () => {
    if (previewZoomRange) previewZoomRange.value = String(Math.round(previewZoom * 100));
    if (previewZoomValue) previewZoomValue.textContent = `${Math.round(previewZoom * 100)}%`;
  };
  const syncLogoPreviewScale = () => {
    if (!logoStage || !previewFrame || !previewSpace) return;
    const scale = previewBaseScale() * previewZoom;
    const pageHeight = measurePreviewPageHeight();
    const visualWidth = LOGO_CANVAS_WIDTH * scale;
    const visualHeight = pageHeight * scale;
    logoStage.style.setProperty('--hn-preview-scale', String(scale || 1));
    previewSpace.style.width = `${Math.max(1, visualWidth)}px`;
    previewSpace.style.height = `${Math.max(1, visualHeight)}px`;
    previewFrame.style.width = `${LOGO_CANVAS_WIDTH}px`;
    previewFrame.style.height = `${pageHeight}px`;
    previewFrame.style.left = `${Math.max(0, (logoStage.clientWidth - visualWidth) / 2)}px`;
    previewFrame.style.top = '0px';
    previewFrame.style.transform = `scale(${scale})`;
    if (previewPage) {
      previewPage.style.width = '390px';
      previewPage.style.minWidth = '390px';
      previewPage.style.maxWidth = '390px';
      previewPage.style.height = `${pageHeight}px`;
      previewPage.style.minHeight = '844px';
      previewPage.style.maxHeight = 'none';
    }
    updatePreviewZoomUi();
  };
  const setPreviewZoom = value => {
    previewZoom = clampPreviewZoom(value);
    syncLogoPreviewScale();
  };

  const buildLogoPreview = () => {
    if (!logoPreviewCanvas) return;
    logoPreviewCanvas.innerHTML = '';
    previewFrame = document.createElement('iframe');
    previewFrame.className = 'hn-admin-real-preview-frame';
    previewFrame.title = 'معاينة مطابقة لصفحة تسجيل الدخول';
    previewFrame.setAttribute('aria-label', 'معاينة مطابقة لصفحة تسجيل الدخول');
    previewFrame.setAttribute('scrolling', 'no');
    previewFrame.style.width = '390px';
    previewFrame.style.height = '844px';
    previewFrame.style.border = '0';
    previewFrame.style.display = 'block';
    previewFrame.style.position = 'absolute';
    previewFrame.style.left = '0';
    previewFrame.style.top = '0';
    previewFrame.style.transformOrigin = 'top left';
    previewSpace = document.createElement('div');
    previewSpace.className = 'hn-admin-preview-space';
    previewSpace.setAttribute('aria-hidden', 'true');
    logoPreviewCanvas.appendChild(previewSpace);
    logoPreviewCanvas.appendChild(previewFrame);
    const sourceHead = document.head.cloneNode(true);
    sourceHead.querySelectorAll('script').forEach(node => node.remove());
    // A number of legacy styles are emitted after </head> in the portable file.
    // Copy them explicitly so the iframe receives exactly the same cascade.
    document.body.querySelectorAll('style').forEach(node => {
      const copy = document.createElement('style');
      copy.textContent = node.textContent || '';
      sourceHead.appendChild(copy);
    });
    // Styles appended after the portable document's closing html tag are not
    // reliably returned by body.querySelectorAll() before iframe creation.
    // Copy the canonical ad-flow rule explicitly so preview and live page share
    // the same order and measurements.
    ['hn-ad-label-caption-canonical-v2','hn-theme-controls-bottom-bg-v1','hn-fixed-curtain-design-canvas-v2'].forEach(id => {
      const node = document.getElementById(id);
      if (node) {
        const copy = document.createElement('style');
        copy.textContent = node.textContent || '';
        sourceHead.appendChild(copy);
      }
    });
    // The old admin preview rules were authored for an in-page scaled clone
    // and add a large desktop offset. The iframe is a real 390x844 page, so
    // restore the same mobile flow used by the customer-facing page.
    const liveContent = root.querySelector('.hn-content');
    const liveFooter = root.querySelector('.hn-footer');
    const liveTopbar = root.querySelector('.hn-topbar');
    const liveFastRights = root.querySelector('.hn-fast-theme-rights');
    const liveContentStyle = liveContent ? getComputedStyle(liveContent) : null;
    const liveFooterStyle = liveFooter ? getComputedStyle(liveFooter) : null;
    const liveTopbarStyle = liveTopbar ? getComputedStyle(liveTopbar) : null;
    const liveRightsStyle = liveFastRights ? getComputedStyle(liveFastRights) : null;
    const previewParityStyle = document.createElement('style');
    previewParityStyle.textContent = `
      /* The editor preview is the actual customer canvas, with no second layout. */
      html,body{margin:0!important;padding:0!important;width:390px!important;min-width:390px!important;max-width:390px!important;height:auto!important;min-height:100%!important;overflow:visible!important;background:transparent!important}
      body.hn-admin-preview-page{display:block!important;height:auto!important;min-height:844px!important;max-height:none!important;overflow:visible!important;touch-action:none!important}
      #hn-root.hypernet-page{width:390px!important;min-width:390px!important;max-width:390px!important;height:auto!important;min-height:844px!important;max-height:none!important;margin:0!important;padding:0!important;overflow:visible!important;position:relative!important;left:0!important;top:0!important;transform:none!important;zoom:1!important}
      #hn-root.hypernet-page>.hn-atmosphere,#hn-root.hypernet-page>.hn-background-fx,#hn-root.hypernet-page>.hn-stars{position:absolute!important;left:0!important;top:0!important;width:390px!important;height:100%!important;min-height:844px!important;max-height:none!important;margin:0!important;pointer-events:none!important}
      #hn-root.hypernet-page .hn-custom-logo-layer{display:block!important}
      #hn-root.hypernet-page .hn-curtain{top:-37.136px!important;width:304.2px!important;height:236.32px!important;min-height:236.32px!important;max-height:236.32px!important;max-width:none!important}
      #hn-root.hypernet-page .hn-curtain-brand{animation:none!important;opacity:1!important}
      #hn-root.hypernet-page *{transition:none!important}
      #hn-root.hypernet-page .hn-content>*,#hn-root.hypernet-page .hn-topbar,#hn-root.hypernet-page .hn-footer{animation:none!important}
      #hn-root.hypernet-page .hn-content{width:${liveContentStyle?.width || '352px'}!important;margin-left:${liveContentStyle?.marginLeft || 'auto'}!important;margin-right:${liveContentStyle?.marginRight || 'auto'}!important;margin-top:${liveContentStyle?.marginTop || '22px'}!important}
      #hn-root.hypernet-page .hn-topbar{padding-left:${liveTopbarStyle?.paddingLeft || '22px'}!important;padding-right:${liveTopbarStyle?.paddingRight || '22px'}!important}
      #hn-root.hypernet-page .hn-footer{width:${liveFooterStyle?.width || '366px'}!important;margin-left:${liveFooterStyle?.marginLeft || 'auto'}!important;margin-right:${liveFooterStyle?.marginRight || 'auto'}!important}
      #hn-root.hypernet-page .hn-fast-theme-rights{width:${liveRightsStyle?.width || '366px'}!important;margin-left:${liveRightsStyle?.marginLeft || 'auto'}!important;margin-right:${liveRightsStyle?.marginRight || 'auto'}!important}
    `;
    sourceHead.appendChild(previewParityStyle);
    // Keep the area outside the canonical 390x844 canvas on the same base theme
    // as the live login page; this prevents a dark/black iframe surround.
    const previewThemeEnd = getComputedStyle(root).getPropertyValue('--hn-end').trim() || '#0b3d2e';
    const previewBottomTheme = document.createElement('style');
    previewBottomTheme.textContent = `html,body{background:${previewThemeEnd}!important}`;
    sourceHead.appendChild(previewBottomTheme);
    const sourceRoot = root.cloneNode(true);
    sourceRoot.dataset.hnPreviewRoot = '1';
    sourceRoot.setAttribute('aria-hidden', 'true');
    // The live page is currently in its startup gate while the admin panel is
    // open. The preview has no startup controller, so never inherit the
    // customer's pending/hidden state into the editor canvas.
    sourceRoot.classList.remove('hn-intro-waiting','hn-intro-pending','hn-intro-left-curtain-active','hn-intro-right-curtain-active','hn-intro-brand-ready','hn-intro-content-ready');
    sourceRoot.classList.add('hn-intro-complete');
    sourceRoot.querySelectorAll('#hn-admin-panel').forEach(node => node.remove());
    // The recoloring filters live on the main document, not inside #hn-root.
    // Clone them into the iframe so the preview uses the same two-tone logo
    // rendering as the customer page and the portable export.
    ['hn-client-logo-color-filter', 'hn-client-logo-accent-filter'].forEach(filterId => {
      const filter = document.getElementById(filterId);
      const svg = filter?.ownerSVGElement;
      if (svg) sourceRoot.appendChild(svg.cloneNode(true));
    });
    const sourceCustomRoot = sourceRoot.querySelector('#hn-custom-logo-layer-root');
    const liveCustomRoot = root.querySelector('#hn-custom-logo-layer-root');
    if (sourceCustomRoot && liveCustomRoot) sourceCustomRoot.innerHTML = liveCustomRoot.innerHTML;
    const sourceMarquee = sourceRoot.querySelector('.hn-welcome-marquee');
    const liveMarquee = root.querySelector('.hn-welcome-marquee');
    const sourceStage = sourceRoot.querySelector('.hn-ad-stage');
    if (!sourceMarquee && sourceStage) {
      const box = liveMarquee ? liveMarquee.cloneNode(true) : document.createElement('div');
      if (!liveMarquee) {
        box.className = 'hn-welcome-marquee';
        box.setAttribute('role', 'note');
        box.setAttribute('aria-label', 'رسالة ترحيبية');
        const message = document.createElement('span');
        message.textContent = 'أهلاً وسهلاً بكم في استراحة وشبكة هايبر نت، استمتع بمشاهدة وتحميل جميع مسلسلاتك بجودة عالية وبشكل مجاني على استراحة الشبكة';
        box.appendChild(message);
      }
      sourceStage.parentElement.insertBefore(box, sourceStage);
    }
    previewFrame.addEventListener('load', () => {
      previewPage = previewFrame.contentDocument?.querySelector('#hn-root');
      if (!previewPage) return;
      previewPage.setAttribute('aria-hidden', 'true');
      applySceneTo(previewPage, true);
      applyPerformanceState(config.performance);
      applyFreeLayout(previewPage);
      bindFreeLayoutDrag(previewPage);
      updateFreeLayoutHelp();
      if (previewResizeObserver) { try { previewResizeObserver.disconnect(); } catch (_) {} }
      // Avoid ResizeObserver feedback loops in the admin preview. The preview
      // size is stabilized by bounded animation-frame/time syncs instead.
      if (previewResizeObserver) { try { previewResizeObserver.disconnect(); } catch (_) {} previewResizeObserver = null; }
      requestAnimationFrame(() => syncLogoPreviewScale());
      setTimeout(syncLogoPreviewScale, 80);
      setTimeout(syncLogoPreviewScale, 250);
      setTimeout(syncLogoPreviewScale, 600);
      setTimeout(syncLogoPreviewScale, 1200);
    }, { once: true });
    const doc = '<!doctype html><html lang="ar" dir="rtl"><head>' + sourceHead.innerHTML + '<meta name="viewport" content="width=390, initial-scale=1, viewport-fit=cover"></head><body class="hn-admin-preview-page" style="margin:0;overflow:visible;background:transparent">' + sourceRoot.outerHTML + '';
    previewFrame.srcdoc = doc;
  };
  const previewZoomOut = document.getElementById('hn-preview-zoom-out');
  const previewZoomIn = document.getElementById('hn-preview-zoom-in');
  const previewZoomFit = document.getElementById('hn-preview-fit');
  const previewZoomReset = document.getElementById('hn-preview-reset-zoom');
  previewZoomRange?.addEventListener('input', () => setPreviewZoom(Number(previewZoomRange.value) / 100));
  previewZoomOut?.addEventListener('click', () => setPreviewZoom(previewZoom - 0.05));
  previewZoomIn?.addEventListener('click', () => setPreviewZoom(previewZoom + 0.05));
  previewZoomReset?.addEventListener('click', () => setPreviewZoom(1));
  previewZoomFit?.addEventListener('click', () => {
    if (!logoStage || !previewPage) return;
    const pageHeight = measurePreviewPageHeight();
    const fitWidth = logoStage.clientWidth / LOGO_CANVAS_WIDTH;
    const fitHeight = logoStage.clientHeight / pageHeight;
    const base = previewBaseScale();
    setPreviewZoom(Math.max(0.5, Math.min(1.5, Math.min(fitWidth, fitHeight) / Math.max(0.001, base))));
    logoStage.scrollTop = 0;
    logoStage.scrollLeft = 0;
  });
  updatePreviewZoomUi();
  window.addEventListener('resize', () => {
    syncLogoPreviewScale();
    if (logoStage && !document.getElementById('hn-admin-workspace')?.hidden) renderLogoStage();
  });
  const normalizeLogo = logo => ({ id: logo.id || `logo-${Date.now()}-${Math.random().toString(36).slice(2,8)}`, src: logo.src || '', x: Number.isFinite(Number(logo.x)) ? Number(logo.x) : 50, y: Number.isFinite(Number(logo.y)) ? Number(logo.y) : 14, size: Number.isFinite(Number(logo.size)) ? Math.max(20, Math.min(500, Number(logo.size))) : 120, rotation: Number.isFinite(Number(logo.rotation)) ? Number(logo.rotation) : 0, name: logo.name || 'لوجو الشبكة' });
  // Saved custom logos stay anchored to the saved brand text on the same 390x844 canvas.
  const logoPlacement = logo => {
    let x = Number.isFinite(Number(logo?.x)) ? Number(logo.x) : 50;
    let y = Number.isFinite(Number(logo?.y)) ? Number(logo.y) : 14;
    if (logo?.anchorToBrand && config.scene?.brandText) {
      const bx = Number(config.scene.brandText.x);
      const by = Number(config.scene.brandText.y);
      if (Number.isFinite(bx) && Number.isFinite(by)) {
        x = bx + (Number(logo.anchorDx) || 0);
        y = by + (Number(logo.anchorDy) || 0);
      }
    }
    return { x: clamp(x, 1, 99), y: clamp(y, 1, 99) };
  };
  const setLogoPosition = (logo, x, y) => {
    const nx = clamp(Number(x) || 50, 1, 99);
    const ny = clamp(Number(y) || 14, 1, 99);
    if (logo?.anchorToBrand && config.scene?.brandText) {
      const bx = Number(config.scene.brandText.x);
      const by = Number(config.scene.brandText.y);
      if (Number.isFinite(bx) && Number.isFinite(by)) {
        logo.anchorDx = nx - bx;
        logo.anchorDy = ny - by;
      }
    }
    logo.x = nx; logo.y = ny;
  };
  const syncAnchoredLogos = () => {
    config.logos.forEach(logo => {
      if (!logo?.anchorToBrand) return;
      const pos=logoPlacement(logo);
      logoRoot?.querySelectorAll(`[data-logo-id="${CSS.escape(logo.id)}"]`).forEach(node => {
        node.style.setProperty('--hn-logo-x', `${pos.x}%`);
        node.style.setProperty('--hn-logo-y', `${pos.y}%`);
        node.style.setProperty('--hn-logo-y-px', `${logoYpx({ ...logo, y: pos.y })}px`);
        node.style.left=`${pos.x}%`; node.style.top=`${logoYpx({ ...logo, y: pos.y })}px`;
      });
      logoStage?.querySelectorAll(`[data-logo-id="${CSS.escape(logo.id)}"]`).forEach(node => {
        const metrics=logoStageMetrics();
        node.style.left=`${pos.x}%`; node.style.top=`${logoStageYpx({ ...logo, y: pos.y },metrics)}px`;
      });
    });
  };

  // Every uploaded logo is split into two synchronized layers:
  // a fixed black base plus a transparent accent layer animated like Net.
  const twoToneLogoCache = new Map();
  const logoLayerCache = new Map();
  const twoToneLogo = src => {
    if (!src || twoToneLogoCache.has(src)) return twoToneLogoCache.get(src) || Promise.resolve(null);
    // Preserve native animation; Canvas would freeze GIF/WebP/APNG at one frame.
    if (/^data:image\/(?:gif|webp|apng)(?:;|,)/i.test(src)) {
      const animated = Promise.resolve({base:src, accent:src, animated:true});
      twoToneLogoCache.set(src, animated);
      return animated;
    }
    const task = new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        const scale = Math.min(1, 1200 / Math.max(image.naturalWidth || image.width, image.naturalHeight || image.height));
        const width = Math.max(1, Math.round((image.naturalWidth || image.width) * scale));
        const height = Math.max(1, Math.round((image.naturalHeight || image.height) * scale));
        const source = document.createElement('canvas');
        source.width = width; source.height = height;
        const ctx = source.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(image, 0, 0, width, height);
        const pixels = ctx.getImageData(0, 0, width, height);
        const base = new ImageData(width, height);
        const accent = new ImageData(width, height);
        for (let i = 0; i < pixels.data.length; i += 4) {
          const alpha = pixels.data[i + 3];
          if (!alpha) continue;
          const luminance = (pixels.data[i] * 299 + pixels.data[i + 1] * 587 + pixels.data[i + 2] * 114) / 1000;
          const target = luminance < 145 ? base.data : accent.data;
          // Keep the accent as a white alpha mask. Its color is applied by
          // the live SVG matrix so it always follows the current Net color.
          target[i] = luminance < 145 ? 0 : 255;
          target[i + 1] = luminance < 145 ? 0 : 255;
          target[i + 2] = luminance < 145 ? 0 : 255;
          target[i + 3] = alpha;
        }
        const render = (data) => {
          const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
          canvas.getContext('2d').putImageData(data, 0, 0);
          return canvas.toDataURL('image/png');
        };
        resolve({ base: render(base), accent: render(accent) });
      };
      image.onerror = () => reject(new Error('logo image could not be read'));
      image.src = src;
    }).catch(() => ({ base: src, accent: src }));
    twoToneLogoCache.set(src, task);
    return task;
  };
  // All logo positions use one fixed phone canvas in both the editor and the
  // portable page. This prevents a taller page flow or a scaled preview from
  // changing the saved vertical position.
  const LOGO_CANVAS_WIDTH = 390;
  const LOGO_CANVAS_HEIGHT = 844;
  const logoYpx = logo => (clamp(Number(logo.y), 2, 98) * LOGO_CANVAS_HEIGHT / 100);
  const logoStageMetrics = () => {
    const rect = logoStage?.getBoundingClientRect?.();
    return {
      rect,
      scaleX: rect?.width ? rect.width / LOGO_CANVAS_WIDTH : 1,
      scaleY: rect?.height ? rect.height / LOGO_CANVAS_HEIGHT : 1
    };
  };
  const logoStageYpx = (logo, metrics = logoStageMetrics()) => logoYpx(logo) * (metrics.scaleY || 1);
  const logoStageSizePx = (logo, metrics = logoStageMetrics()) => Math.max(24, Number(logo.size) || 120) * (metrics.scaleX || 1);
  config.logos = config.logos.map(normalizeLogo).filter(logo => logo.src);
  config.logos.forEach(logo => {
    if (logo.anchorToBrand !== true) {
      logo.anchorToBrand = true;
      logo.anchorDx = Number(logo.x) - Number(config.scene?.brandText?.x || 50);
      logo.anchorDy = Number(logo.y) - Number(config.scene?.brandText?.y || 10);
      logo.anchorRelation = 'brandText';
    }
  });
  const selectedLogo = () => config.logos.find(logo => logo.id === selectedLogoId) || null;
  const clamp = (v,min,max) => Math.max(min, Math.min(max, v));

  const FIXED_BRAND_FONT = 'fixed-kufi';
  config.brandFont = FIXED_BRAND_FONT;
  const applyBrandFont = (scope=root) => {
    if (!scope) return;
    const brand = scope.querySelector('.hn-curtain-brand-text');
    if (!brand) return;
    brand.classList.remove('hn-font-modern','hn-font-royal-kufi','hn-font-naskh','hn-font-amiri-sign','hn-font-condensed','hn-font-neon','hn-font-outline','hn-font-emboss','hn-font-stamp','hn-font-wide-tech','hn-font-rounded','hn-font-signature');
    brand.classList.add('hn-font-fixed-kufi');
    brand.style.setProperty('font-family','"HN-Kufi-Black","Noto Kufi Arabic",sans-serif','important');
    brand.style.setProperty('font-weight','900','important');
    brand.style.setProperty('letter-spacing','-1.1px','important');
    brand.style.setProperty('font-variant-ligatures','none','important');
    brand.style.setProperty('text-shadow','none','important');
    brand.dataset.hnBrandFont = FIXED_BRAND_FONT;
    brand.dataset.hnBrandFontStyle = FIXED_BRAND_FONT;
  };
  const sceneDefaults = {
    brandText: { label:'هايبر Net', x:50, y:10, scale:1, rotation:0, visible:true },
    tagline: { label:'عالم من المتعة والترفيه', x:50, y:18, scale:1, rotation:0, visible:true },
  };
  config.scene = { ...sceneDefaults, ...(config.scene || {}) };
  Object.keys(sceneDefaults).forEach(key => {
    config.scene[key] = { ...sceneDefaults[key], ...(config.scene[key] || {}) };
    config.scene[key].x = clamp(Number(config.scene[key].x) || sceneDefaults[key].x, 1, 99);
    config.scene[key].y = clamp(Number(config.scene[key].y) || sceneDefaults[key].y, 1, 99);
    config.scene[key].scale = clamp(Number(config.scene[key].scale) || sceneDefaults[key].scale, .35, 3);
    config.scene[key].rotation = clamp(Number(config.scene[key].rotation) || sceneDefaults[key].rotation, -180, 180);
    config.scene[key].visible = config.scene[key].visible !== false;
  });

  let selectedSceneId = 'brandText';
  let sceneDrag = null;

  const sceneElementFrom = (scope, id) => {
    const rootEl = scope || root;
    if (id === 'brandText') return rootEl.querySelector('.hn-curtain-brand-text');
    if (id === 'tagline') return rootEl.querySelector('.hn-curtain-brand-tagline');
    return null;
  };

  const ensureSecondaryWifi = (scope) => scope ? scope.querySelector('.hn-wifi-two') : null;

  const styleSceneElement = (el, data, id) => {
    if (!el || !data) return;
    el.classList.add('hn-scene-editable');
    el.style.setProperty('left', `${data.x}%`, 'important');
    const sceneYpx = clamp(Number(data.y) || 50, 1, 99) * 844 / 100;
    el.style.setProperty('top', `${sceneYpx}px`, 'important');
    el.style.setProperty('transform', `translate(-50%,-50%) rotate(${data.rotation}deg) scale(${data.scale})`, 'important');
    el.style.setProperty('transform-origin','center center','important');
    el.style.setProperty('position','absolute','important');
    el.style.setProperty('margin','0','important');
    el.style.setProperty('z-index',id==='brandText'||id==='tagline'?'9':'10','important');
    if (id==='tagline') el.style.setProperty('white-space','nowrap','important');

    // During the customer startup sequence, opacity/visibility belong to the
    // single intro gate below. Writing them inline here used to defeat the gate
    // and made the whole page paint before the curtains had finished.
    const startupDone = !!window.__HN_INTRO_DONE;
    if (!data.visible) {
      el.style.setProperty('opacity','0');
      el.style.setProperty('visibility','hidden','important');
    } else if (startupDone) {
      el.style.setProperty('opacity','1');
      el.style.setProperty('visibility','visible','important');
    } else {
      el.style.removeProperty('opacity');
      el.style.removeProperty('visibility');
    }
  };

  const bindSceneDrag = scope => {
    if (!scope || scope.dataset.sceneDragBound === '1') return;
    scope.dataset.sceneDragBound='1';

    // Robust touch/mouse dragging for scene text.  Movement is calculated in
    // the preview page's own 390x844 coordinate system, so vertical dragging
    // remains fully functional even when the preview is scaled on a phone.
    ['brandText','tagline'].forEach(id => {
      const el = sceneElementFrom(scope,id);
      if (!el) return;

      el.dataset.sceneId=id;
      el.style.setProperty('touch-action','none','important');
      el.style.setProperty('cursor','grab','important');
      el.style.setProperty('pointer-events','auto','important');

      const getMetrics = () => {
        const rect = scope.getBoundingClientRect();
        const scaleX = rect.width / 390;
        const scaleY = rect.height / 844;
        return { rect, scaleX: scaleX || 1, scaleY: scaleY || 1 };
      };

      el.addEventListener('pointerdown', ev => {
        if (ev.pointerType === 'mouse' && ev.button !== 0) return;
        ev.preventDefault();
        ev.stopPropagation();

        selectedSceneId=id;
        renderSceneEditor();

        const data=config.scene[id];
        const {rect,scaleX,scaleY}=getMetrics();
        const centerX=rect.left + (data.x/100)*rect.width;
        const centerY=rect.top + (data.y/100)*rect.height;

        sceneDrag={
          id,
          pointerId:ev.pointerId,
          rect,
          scaleX,
          scaleY,
          offsetX:ev.clientX-centerX,
          offsetY:ev.clientY-centerY,
          nextX:data.x,
          nextY:data.y,
          raf:0
        };

        el.classList.add('hn-admin-scene-dragging','hn-admin-scene-selected');
        try { el.setPointerCapture(ev.pointerId); } catch (_) {}
      }, {passive:false});

      const moveScene = ev => {
        if(!sceneDrag || sceneDrag.id!==id || sceneDrag.pointerId!==ev.pointerId) return;
        ev.preventDefault();

        const d=sceneDrag;
        const px=ev.clientX-d.rect.left-d.offsetX;
        const py=ev.clientY-d.rect.top-d.offsetY;

        // Use the actual displayed scale independently for X and Y.
        d.nextX=clamp((px/(390*d.scaleX))*100,1,99);
        d.nextY=clamp((py/(844*d.scaleY))*100,1,99);

        if(!d.raf){
          d.raf=requestAnimationFrame(()=>{
            d.raf=0;
            if(!sceneDrag || sceneDrag.id!==id) return;
            const data=config.scene[id];
            data.x=d.nextX;
            data.y=d.nextY;
            styleSceneElement(el,data,id);
            if(id==='brandText') syncAnchoredLogos();
            updateSceneToolsOnly();
          });
        }
      };

      const finish=ev=>{
        if(!sceneDrag || sceneDrag.id!==id || (ev && sceneDrag.pointerId!==ev.pointerId)) return;
        const d=sceneDrag;
        if(d.raf){ cancelAnimationFrame(d.raf); d.raf=0; }
        const data=config.scene[id];
        data.x=d.nextX;
        data.y=d.nextY;
        styleSceneElement(el,data,id);
        if(id==='brandText') syncAnchoredLogos();
        sceneDrag=null;
        el.classList.remove('hn-admin-scene-dragging');
        try { if(ev) el.releasePointerCapture(ev.pointerId); } catch (_) {}
        showSaveStatus('تم تحريك العنصر. اضغط «حفظ الإعدادات وتنزيل config.js».');
        renderSceneEditor();
      };

      el.addEventListener('pointermove',moveScene,{passive:false});
      el.addEventListener('pointerup',finish,{passive:false});
      el.addEventListener('pointercancel',finish,{passive:false});
      el.addEventListener('lostpointercapture',()=>{
        if(sceneDrag && sceneDrag.id===id){
          const d=sceneDrag;
          if(d.raf) cancelAnimationFrame(d.raf);
          const data=config.scene[id];
          data.x=d.nextX;
          data.y=d.nextY;
          sceneDrag=null;
          el.classList.remove('hn-admin-scene-dragging');
          renderSceneEditor();
        }
      });

      // Continue receiving movement even if the browser moves the pointer
      // outside the text's small bounding box during a vertical drag.
      scope.addEventListener('pointermove',moveScene,{passive:false});
      scope.addEventListener('pointerup',finish,{passive:false});
      scope.addEventListener('pointercancel',finish,{passive:false});
    });
  };

  const applySceneTo = (scope, preview=false) => {
    if(!scope)return;
    applyBrandFont(scope);
    const brandContainer=scope.querySelector('.hn-curtain-brand');
    if(brandContainer){
      // Keep the network name anchored as a real top-layer over the curtains.
      // The startup gate owns only opacity/visibility/animation; layout values
      // remain editable and stable so the admin editor continues to work.
      brandContainer.style.setProperty('position','absolute','important');
      brandContainer.style.setProperty('top','0','important');
      brandContainer.style.setProperty('left','0','important');
      brandContainer.style.setProperty('right','0','important');
      brandContainer.style.setProperty('width','100%','important');
      brandContainer.style.setProperty('height','100%','important');
      brandContainer.style.setProperty('margin','0','important');
      brandContainer.style.setProperty('pointer-events','none','important');
      brandContainer.style.setProperty('z-index','20','important');
      if (preview || window.__HN_INTRO_DONE) {
        brandContainer.style.setProperty('opacity','1','important');
        brandContainer.style.setProperty('visibility','visible','important');
        brandContainer.style.setProperty('animation','none','important');
      } else {
        brandContainer.style.removeProperty('opacity');
        brandContainer.style.removeProperty('visibility');
        brandContainer.style.removeProperty('animation');
      }
    }
    const els={brandText:sceneElementFrom(scope,'brandText'),tagline:sceneElementFrom(scope,'tagline')};
    Object.entries(els).forEach(([id,el])=>styleSceneElement(el,config.scene[id],id));
    Object.entries(els).forEach(([id,el])=>{if(el){el.classList.toggle('hn-admin-scene-selected',preview&&id===selectedSceneId);el.dataset.sceneId=id;}});
    if(preview)bindSceneDrag(scope);
  };

  const updateSceneToolsOnly=()=>{
    const data=config.scene[selectedSceneId];
    document.querySelectorAll('#hn-admin-scene-tools input[data-scene-key]').forEach(input=>{input.value=data[input.dataset.sceneKey];});
    document.querySelectorAll('#hn-admin-scene-tools [data-scene-value]').forEach(v=>{v.textContent=data[v.dataset.sceneValue];});
  };

  const renderSceneEditor=()=>{
    const buttons=document.getElementById('hn-admin-scene-buttons'),tools=document.getElementById('hn-admin-scene-tools');
    if(!buttons||!tools)return;
    buttons.innerHTML='';
    Object.entries(sceneDefaults).forEach(([id,meta])=>{const b=document.createElement('button');b.type='button';b.textContent=meta.label;b.className=id===selectedSceneId?'is-active':'';b.onclick=()=>{selectedSceneId=id;applySceneTo(previewPage,true);renderSceneEditor();};buttons.appendChild(b);});
    const data=config.scene[selectedSceneId]; tools.innerHTML='';
    const range=(label,key,min,max,step)=>{const wrap=document.createElement('div');wrap.className='scene-tool';const lab=document.createElement('label');const title=document.createElement('span');title.textContent=label+' ';const val=document.createElement('b');val.dataset.sceneValue=key;val.textContent=data[key];title.appendChild(val);const input=document.createElement('input');input.type='range';input.min=min;input.max=max;input.step=step;input.value=data[key];input.dataset.sceneKey=key;input.oninput=()=>{data[key]=Number(input.value);val.textContent=input.value;applySceneTo(root,false);applySceneTo(previewPage,true);if(selectedSceneId==='brandText')syncAnchoredLogos();persistLocalConfig();};lab.append(title,input);wrap.appendChild(lab);tools.appendChild(wrap);};
    range('الموضع الأفقي %','x',1,99,.1);range('الموضع العمودي %','y',1,99,.1);range('الحجم','scale',.35,3,.01);range('الدوران °','rotation',-180,180,1);
    const toggle=document.createElement('div');toggle.className='scene-tool';const tb=document.createElement('button');tb.type='button';tb.textContent=data.visible?'إخفاء العنصر':'إظهار العنصر';tb.onclick=()=>{data.visible=!data.visible;applySceneTo(previewPage,true);renderSceneEditor();};toggle.appendChild(tb);tools.appendChild(toggle);
    const reset=document.createElement('div');reset.className='scene-tool';const rb=document.createElement('button');rb.type='button';rb.textContent='إرجاع العنصر للوضع الأصلي';rb.onclick=()=>{config.scene[selectedSceneId]={...sceneDefaults[selectedSceneId]};applySceneTo(previewPage,true);renderSceneEditor();};reset.appendChild(rb);tools.appendChild(reset);
  };


  // Free layout editor for the real 390x844 login canvas. Values are pixel
  // offsets from the original layout, so the normal spacing and responsive
  // flow remain intact until the administrator deliberately drags an item.
  const FREE_LAYOUT_ITEMS = {
    topbar: { label: 'الشريط العلوي', selector: '.hn-topbar' },
    adArea: { label: 'منطقة الإعلانات كاملة — العنوان والصور والوصف', selector: '.hn-ad-section' },
    loginCard: { label: 'مربع تسجيل الدخول', selector: '.hn-login-card' },
    services: { label: 'قسم الخدمات كامل — العنوان والباقات', selector: '.hn-info-section' },
    footer: { label: 'التذييل كامل', selector: '.hn-footer' }
  };
  config.freeLayout = (config.freeLayout && typeof config.freeLayout === 'object') ? config.freeLayout : {};
  // Migrate the previous independent ad offsets into one parent offset. This keeps
  // the old saved position while making the heading, marquee, images and caption
  // move together as one unit.
  if (!config.freeLayout.adArea) {
    const legacy = config.freeLayout.adStage || config.freeLayout.adHeader || config.freeLayout.welcomeMarquee || config.freeLayout.adCaption || {};
    config.freeLayout.adArea = { x: Number(legacy.x) || 0, y: Number(legacy.y) || 0 };
  }
  delete config.freeLayout.adHeader;
  delete config.freeLayout.welcomeMarquee;
  delete config.freeLayout.adStage;
  delete config.freeLayout.adCaption;
  Object.keys(FREE_LAYOUT_ITEMS).forEach(id => {
    const value = config.freeLayout[id] || {};
    config.freeLayout[id] = {
      x: clamp(Number(value.x) || 0, -180, 180),
      y: clamp(Number(value.y) || 0, -300, 300)
    };
  });
  const freeLayoutElement = (scope, id) => {
    const meta = FREE_LAYOUT_ITEMS[id];
    return meta && scope?.querySelector(meta.selector);
  };
  const applyFreeLayout = scope => {
    if (!scope) return;
    Object.keys(FREE_LAYOUT_ITEMS).forEach(id => {
      const el = freeLayoutElement(scope, id);
      if (!el) return;
      const data = config.freeLayout[id] || { x: 0, y: 0 };
      el.dataset.freeLayoutId = id;
      el.style.setProperty('translate', `${data.x}px ${data.y}px`, 'important');
      el.style.setProperty('touch-action', scope === previewPage ? 'none' : 'auto', 'important');
      if (scope === previewPage) {
        el.classList.add('hn-free-layout-editable');
        el.setAttribute('title', `${FREE_LAYOUT_ITEMS[id].label} — اسحب باللمس لتحريكه`);
      }
    });
  };
  let freeDrag = null;
  const updateFreeLayoutHelp = () => {
    const host = document.getElementById('hn-admin-scene-tools')?.parentElement;
    if (!host) return;
    let help = document.getElementById('hn-free-layout-help');
    if (!help) {
      help = document.createElement('div');
      help.id = 'hn-free-layout-help';
      help.className = 'hn-free-layout-help';
      host.appendChild(help);
    }
    help.innerHTML = '<strong>تحرير حر للعناصر</strong><span>اضغط على أي عنصر داخل المعاينة واسحبه بإصبعك أو بالفأرة. العناصر التابعة مثل عنوان الإعلان والصور والوصف تتحرك مع العنصر الرئيسي كوحدة واحدة.</span>';
    if (!help.querySelector('[data-free-layout-reset]')) {
      const reset = document.createElement('button');
      reset.type = 'button'; reset.dataset.freeLayoutReset = '1'; reset.textContent = 'إرجاع مواقع العناصر الأصلية';
      reset.addEventListener('click', () => {
        Object.keys(FREE_LAYOUT_ITEMS).forEach(id => { config.freeLayout[id] = { x: 0, y: 0 }; });
        applyFreeLayout(root); applyFreeLayout(previewPage); syncLogoPreviewScale(); persistLocalConfig();
        showSaveStatus('تم إرجاع مواقع العناصر الأصلية. اضغط «حفظ الإعدادات وتنزيل config.js».');
      });
      help.appendChild(reset);
    }
  };
  const bindFreeLayoutDrag = scope => {
    if (!scope) return;
    Object.keys(FREE_LAYOUT_ITEMS).forEach(id => {
      const el = freeLayoutElement(scope, id);
      if (!el || el.dataset.freeLayoutBound === '1') return;
      el.dataset.freeLayoutBound = '1';
      el.addEventListener('pointerdown', event => {
        if (scope !== previewPage) return;
        const rect = previewPage.getBoundingClientRect();
        const scale = rect.width / 390 || 1;
        const data = config.freeLayout[id];
        freeDrag = { id, pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, baseX: data.x, baseY: data.y, scale };
        event.preventDefault(); event.stopPropagation();
        el.classList.add('hn-free-layout-dragging');
        try { el.setPointerCapture(event.pointerId); } catch (_) {}
      }, { passive: false });
      const move = event => {
        if (!freeDrag || freeDrag.id !== id || freeDrag.pointerId !== event.pointerId) return;
        event.preventDefault();
        const data = config.freeLayout[id];
        data.x = clamp(freeDrag.baseX + (event.clientX - freeDrag.startX) / freeDrag.scale, -180, 180);
        data.y = clamp(freeDrag.baseY + (event.clientY - freeDrag.startY) / freeDrag.scale, -300, 300);
        applyFreeLayout(root); applyFreeLayout(previewPage); syncLogoPreviewScale();
      };
      const finish = event => {
        if (!freeDrag || freeDrag.id !== id || (event && freeDrag.pointerId !== event.pointerId)) return;
        const data = config.freeLayout[id];
        freeDrag = null; el.classList.remove('hn-free-layout-dragging');
        try { if (event) el.releasePointerCapture(event.pointerId); } catch (_) {}
        applyFreeLayout(root); applyFreeLayout(previewPage); syncLogoPreviewScale(); persistLocalConfig(); updateFreeLayoutHelp();
        showSaveStatus(`تم تحريك «${FREE_LAYOUT_ITEMS[id].label}». اضغط «حفظ الإعدادات وتنزيل config.js».`);
      };
      el.addEventListener('pointermove', move, { passive: false });
      el.addEventListener('pointerup', finish, { passive: false });
      el.addEventListener('pointercancel', finish, { passive: false });
    });
  };

  const syncPreviewLogos = () => {
    if (!previewPage || !logoRoot) return;
    const previewLogoRoot = previewPage.querySelector('#hn-custom-logo-layer-root');
    if (!previewLogoRoot) return;
    previewLogoRoot.innerHTML = logoRoot.innerHTML;
    ['hn-client-logo-color-filter', 'hn-client-logo-accent-filter'].forEach(filterId => {
      const source = document.getElementById(filterId);
      const target = previewPage.ownerDocument.getElementById(filterId);
      if (source && target) target.setAttribute('values', source.getAttribute('values') || '');
    });
  };
  root.addEventListener('hn:theme-color-changed', () => {
    syncPreviewLogos();
  }, { passive: true });
  const applyLogos = async () => {
    if (!logoRoot) return;
    await Promise.all(config.logos.map(async logo => {
      const originalSrc = logo.src;
      logoLayerCache.set(originalSrc, await twoToneLogo(originalSrc));
    }));
    logoRoot.innerHTML = '';
    if (originalBrand) originalBrand.style.visibility = config.originalLogoVisible === false ? 'hidden' : 'visible';
    config.logos.forEach(logo => {
      const layers = logoLayerCache.get(logo.src) || {base: logo.src, accent: logo.src};
      const wrap = document.createElement('span');
      wrap.className = `hn-custom-logo-pair${layers.animated ? ' hn-animated-logo-pair' : ''}`;
      wrap.dataset.logoId = logo.id;
      const appendLogoImage = (src, className, filter) => {
        const img = document.createElement('img');
        img.className = `hn-custom-logo-layer ${className}`; img.src = src; img.alt = ''; img.dataset.logoId = logo.id;
        const pos = logoPlacement(logo);
        img.style.setProperty('--hn-logo-x', `${pos.x}%`); img.style.setProperty('--hn-logo-y', `${pos.y}%`); img.style.setProperty('--hn-logo-y-px', `${logoYpx({ ...logo, y: pos.y })}px`); img.style.setProperty('--hn-logo-size', `${logo.size}px`); img.style.setProperty('--hn-logo-rot', `${logo.rotation}deg`);
        img.style.left = `${pos.x}%`; img.style.top = `${logoYpx({ ...logo, y: pos.y })}px`; img.style.width = `${logo.size}px`; img.style.transform = `translate(-50%,-50%) rotate(${logo.rotation}deg)`;
        if (className.includes('hn-custom-logo-animated') && logo.__hnPerfCrop === 'v1') {
          /* Cropped from the exact alpha union of the original 800x600 GIF.
             The visible pixels are unchanged; only transparent empty canvas is removed. */
          const size = Math.max(1, Number(logo.size) || 120);
          const angle = (Number(logo.rotation) || 0) * Math.PI / 180;
          const dx0 = -0.003125 * size;
          const dy0 = -0.020625 * size;
          const dx = dx0 * Math.cos(angle) - dy0 * Math.sin(angle);
          const dy = dx0 * Math.sin(angle) + dy0 * Math.cos(angle);
          img.style.width = `${size * 0.19375}px`;
          img.style.left = `calc(${pos.x}% + ${dx.toFixed(3)}px)`;
          img.style.top = `${logoYpx({ ...logo, y: pos.y }) + dy}px`;
        }
        if (filter) img.style.setProperty('filter', filter, 'important');
        wrap.appendChild(img);
      };
      if (layers.animated) {
        // Cross-browser animated path: keep the native GIF/WebP animation and
        // recolor it with a standard CSS filter instead of an SVG URL filter.
        // SVG URL filters on animated raster images are not rendered
        // consistently by some mobile browser engines.
        appendLogoImage(logo.src, 'hn-custom-logo-animated', '');
      } else {
        ['base','accent'].forEach(layer => appendLogoImage(
          layers[layer],
          `hn-custom-logo-${layer}`,
          layer === 'accent'
            ? 'var(--hn-client-logo-accent-filter,url(#hn-client-logo-accent-filter)) drop-shadow(0 7px 16px rgba(0,0,0,.18))'
            : ''
        ));
      }
      logoRoot.appendChild(wrap);
    });
    applySceneTo(root, false);
    renderLogoStage(); renderLogoList(); renderLogoControls();
    syncPreviewLogos();
    if (previewPage) applySceneTo(previewPage, true);
    renderSceneEditor();
  };
  const renderLogoStage = () => {
    if (!logoStage) return;
    if (!previewPage) buildLogoPreview();
    logoStage.querySelectorAll('.hn-admin-logo-stage-item').forEach(n => n.remove());
    const stageMetrics = logoStageMetrics();

    config.logos.forEach(logo => {
      const img = document.createElement('img');
      img.className = `hn-admin-logo-stage-item${logo.id === selectedLogoId ? ' is-selected' : ''}`;
      const stageLayers = logoLayerCache.get(logo.src) || {};
      img.src = stageLayers.accent || logo.src;
      if (stageLayers.animated) {
        img.dataset.hnLogoAnimated = '1';
        // Do not bind the SVG URL filter here. The final CSS fallback below
        // is intentionally the same on the live page and in the editor.
      } else if (stageLayers.accent) {
        img.style.setProperty('filter', 'var(--hn-client-logo-accent-filter,url(#hn-client-logo-accent-filter))', 'important');
      }
      img.alt = '';
      img.draggable = false;
      img.dataset.logoId = logo.id;
      const pos = logoPlacement(logo);
      img.style.left = `${pos.x}%`;
      img.style.top = `${logoStageYpx({ ...logo, y: pos.y }, stageMetrics)}px`;
      img.style.width = `${logoStageSizePx(logo, stageMetrics)}px`;
      img.style.transform = `translate(-50%,-50%) rotate(${logo.rotation}deg)`;

      const select = () => {
        selectedLogoId = logo.id;
        logoStage.querySelectorAll('.hn-admin-logo-stage-item').forEach(n =>
          n.classList.toggle('is-selected', n.dataset.logoId === logo.id)
        );
        renderLogoList();
        renderLogoControls();
      };

      let drag = null;

      img.addEventListener('pointerdown', event => {
        if (event.pointerType === 'mouse' && event.button !== 0) return;
        event.preventDefault();
        event.stopPropagation();
        select();

        const rect = logoStage.getBoundingClientRect();
        const px = event.clientX - rect.left;
        const py = event.clientY - rect.top;
        const centerX = (logo.x / 100) * rect.width;
        const centerY = logoStageYpx(logo, { rect, scaleX: rect.width / LOGO_CANVAS_WIDTH, scaleY: rect.height / LOGO_CANVAS_HEIGHT });

        // Preserve the exact point where the finger touched the logo.
        // This prevents the logo from jumping under the finger on drag start.
        drag = {
          pointerId: event.pointerId,
          rect,
          offsetX: px - centerX,
          offsetY: py - centerY,
          raf: 0,
          nextX: logo.x,
          nextY: logo.y
        };

        img.classList.add('is-dragging');
        try { img.setPointerCapture(event.pointerId); } catch (_) {}
      }, { passive: false });

      img.addEventListener('pointermove', event => {
        if (!drag || drag.pointerId !== event.pointerId) return;
        event.preventDefault();

        const px = event.clientX - drag.rect.left - drag.offsetX;
        const py = event.clientY - drag.rect.top - drag.offsetY;
        drag.nextX = clamp((px / drag.rect.width) * 100, 2, 98);
        drag.nextY = clamp((py / drag.rect.height) * 100, 2, 98);

        if (!drag.raf) {
          drag.raf = requestAnimationFrame(() => {
            drag.raf = 0;
            if (!drag) return;
            logo.x = drag.nextX;
            logo.y = drag.nextY;
            const livePos = logoPlacement(logo);
            img.style.left = `${livePos.x}%`;
            img.style.top = `${logoStageYpx({ ...logo, y: livePos.y }, { rect: drag.rect, scaleX: drag.rect.width / LOGO_CANVAS_WIDTH, scaleY: drag.rect.height / LOGO_CANVAS_HEIGHT })}px`;

            const live = logoRoot?.querySelector(`[data-logo-id="${CSS.escape(logo.id)}"]`);
            if (live) {
              const livePos = logoPlacement(logo);
              live.style.setProperty('--hn-logo-x', `${livePos.x}%`);
              live.style.setProperty('--hn-logo-y', `${livePos.y}%`);
              live.style.setProperty('--hn-logo-y-px', `${logoYpx({ ...logo, y: livePos.y })}px`);
            }
            syncPreviewLogos();
          });
        }
      }, { passive: false });

      const finish = event => {
        if (!drag || (event && drag.pointerId !== event.pointerId)) return;
        if (drag.raf) cancelAnimationFrame(drag.raf);
        setLogoPosition(logo, drag.nextX, drag.nextY);
        const finalPos = logoPlacement(logo);
        img.style.left = `${finalPos.x}%`;
        img.style.top = `${logoStageYpx({ ...logo, y: finalPos.y })}px`;
        syncPreviewLogos();
        drag = null;
        img.classList.remove('is-dragging');
        renderLogoList();
        saveJson(LOGOS_KEY,config.logos);
        persistLocalConfig();
        showSaveStatus('تم تحريك اللوجو بسلاسة وحفظ مكانه ومقاسه.');
      };

      img.addEventListener('pointerup', finish);
      img.addEventListener('pointercancel', finish);
      img.addEventListener('lostpointercapture', () => { if (drag) finish(); });
      img.addEventListener('click', event => { event.preventDefault(); select(); });
      logoStage.appendChild(img);
    });
    syncLogoPreviewScale();
  };
  const renderLogoControls = () => {
    if (!logoControls) return;
    logoControls.innerHTML = '';
    const logo = selectedLogo();
    if (!logo) { logoControls.innerHTML = '<div class="hn-admin-logo-empty" style="grid-column:1/-1">اختر لوجو من المعاينة أو أضف لوجو جديدًا للبدء.</div>'; return; }
    const makeRange = (labelText, key, min, max, step) => {
      const label = document.createElement('label');
      label.textContent = `${labelText} (${logo[key]})`;
      const input = document.createElement('input');
      input.type='range'; input.min=min; input.max=max; input.step=step; input.value=logo[key];
      const applyRangeValue = () => {
        const rawValue=Number(input.value);
        if (key==='x' || key==='y') {
          const pos=logoPlacement(logo);
          setLogoPosition(logo, key==='x'?rawValue:pos.x, key==='y'?rawValue:pos.y);
        } else logo[key]=rawValue;
        const shown=logoPlacement(logo);
        label.firstChild.nodeValue = `${labelText} (${key==='x'?shown.x:key==='y'?shown.y:logo[key]})`;
        const live = logoRoot?.querySelector(`[data-logo-id="${CSS.escape(logo.id)}"]`);
        if (live) {
          live.style.setProperty('--hn-logo-x',`${shown.x}%`);
          live.style.setProperty('--hn-logo-y',`${shown.y}%`);
          live.style.setProperty('--hn-logo-y-px',`${logoYpx({ ...logo, y: shown.y })}px`);
          live.style.setProperty('--hn-logo-size',`${logo.size}px`);
          live.style.setProperty('--hn-logo-rot',`${logo.rotation}deg`);
          live.style.left=`${shown.x}%`; live.style.top=`${logoYpx({ ...logo, y: shown.y })}px`;
          live.style.width=`${Math.max(24,logo.size)}px`;
          live.style.transform=`translate(-50%,-50%) rotate(${logo.rotation}deg)`;
        }
        const stage = logoStage?.querySelector(`[data-logo-id="${CSS.escape(logo.id)}"]`);
        if (stage) {
          const metrics = logoStageMetrics();
          stage.style.left=`${logo.x}%`; stage.style.top=`${logoStageYpx(logo,metrics)}px`;
          stage.style.width=`${logoStageSizePx(logo,metrics)}px`;
          stage.style.transform=`translate(-50%,-50%) rotate(${logo.rotation}deg)`;
        }
        saveJson(LOGOS_KEY, config.logos);
        persistLocalConfig();
        renderLogoList();
      };
      input.addEventListener('input', applyRangeValue);
      input.addEventListener('change', applyRangeValue);
      label.appendChild(input); logoControls.appendChild(label);
    };
    makeRange('الموضع الأفقي %','x',2,98,1);
    makeRange('الموضع العمودي % (مرجع 844px)','y',2,98,1);
    makeRange('حجم اللوجو px','size',20,500,1);
    makeRange('الدوران °','rotation',-180,180,1);
  };
  const renderLogoList = () => {
    if (!logoList) return; logoList.innerHTML='';
    if (!config.logos.length) { logoList.innerHTML='<div class="hn-admin-logo-empty">لا توجد لوجوهات مخصصة حاليًا.</div>'; return; }
    config.logos.forEach((logo,index)=>{ const item=document.createElement('div'); item.className='hn-admin-logo-item'; if(logo.id===selectedLogoId) item.style.outline='2px solid #2da78e'; const thumb=document.createElement('img'); thumb.className='hn-admin-logo-thumb'; thumb.src=logo.src; const text=document.createElement('div'); const strong=document.createElement('strong'); strong.textContent=`${logo.name} ${index+1}`; const small=document.createElement('small'); const pos=logoPlacement(logo); small.textContent=`X ${Math.round(pos.x)}% • Y ${Math.round(pos.y)}% • ${Math.round(logo.size)}px • ${Math.round(logo.rotation)}°`; text.append(strong,small); const select=document.createElement('button'); select.type='button'; select.textContent=logo.id===selectedLogoId?'محدد':'تحرير'; select.addEventListener('click',()=>{selectedLogoId=logo.id;renderLogoStage();renderLogoList();renderLogoControls();}); item.append(thumb,text,select); logoList.appendChild(item); });
  };
  const compressLogo = file => new Promise((resolve,reject)=>{
    /* Preserve animated formats exactly as uploaded. The previous implementation
       decoded every image through a canvas, which turns an animated GIF/WebP into
       a single static frame. GIF/WebP are kept as data URLs so their native frames
       continue animating on the real login page. */
    if (file && (file.type === 'image/gif' || file.type === 'image/webp')) {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
      return;
    }
    const reader=new FileReader(); reader.onerror=reject; reader.onload=()=>{ const image=new Image(); image.onload=()=>{ const max=1200, scale=Math.min(1,max/Math.max(image.width,image.height)); const canvas=document.createElement('canvas'); canvas.width=Math.max(1,Math.round(image.width*scale)); canvas.height=Math.max(1,Math.round(image.height*scale)); const ctx=canvas.getContext('2d'); ctx.clearRect(0,0,canvas.width,canvas.height); ctx.drawImage(image,0,0,canvas.width,canvas.height); resolve(canvas.toDataURL('image/webp',.9)); }; image.onerror=reject; image.src=reader.result; }; reader.readAsDataURL(file);
  });
  const addLogo = async file => { if(!file || !file.type.startsWith('image/')) { showSaveStatus('اختر ملف صورة صالحًا للوجو.'); return; } try { const src=await compressLogo(file); const logo=normalizeLogo({src,name:file.name.replace(/\.[^.]+$/,'')||'لوجو الشبكة',x:50,y:18,size:120,rotation:0}); config.logos.push(logo); selectedLogoId=logo.id; applyLogos(); showSaveStatus('تمت إضافة اللوجو بلونين: أسود ثابت ولون مطابق لـ Net. اضغط «حفظ الإعدادات وتنزيل config.js».'); } catch { showSaveStatus('تعذر قراءة صورة اللوجو.'); } };
  const mutateSelected = fn => { const logo=selectedLogo(); if(!logo) { showSaveStatus('اختر لوجو أولًا.'); return; } fn(logo); applyLogos(); showSaveStatus('تم تعديل اللوجو. اضغط «حفظ الإعدادات وتنزيل config.js».'); };
  document.getElementById('hn-admin-logo-file')?.addEventListener('change',event=>{ const file=event.target.files?.[0]; if(file) addLogo(file); event.target.value=''; });
  document.getElementById('hn-admin-original-logo-visible')?.addEventListener('change',event=>{ config.originalLogoVisible=event.target.checked; applyLogos(); showSaveStatus('تم تغيير ظهور اللوجو الأصلي. اضغط «حفظ الإعدادات وتنزيل config.js».'); });
  document.getElementById('hn-admin-logo-rotate-left')?.addEventListener('click',()=>mutateSelected(logo=>logo.rotation=clamp(logo.rotation-15,-180,180)));
  document.getElementById('hn-admin-logo-rotate-right')?.addEventListener('click',()=>mutateSelected(logo=>logo.rotation=clamp(logo.rotation+15,-180,180)));
  document.getElementById('hn-admin-logo-duplicate')?.addEventListener('click',()=>{ const logo=selectedLogo(); if(!logo){showSaveStatus('اختر لوجو أولًا.');return;} const copy=normalizeLogo({...logo,id:'',name:`${logo.name} - نسخة`,x:clamp(logo.x+5,2,98),y:clamp(logo.y+5,2,98)}); config.logos.push(copy); selectedLogoId=copy.id; applyLogos(); showSaveStatus('تم تكرار اللوجو.'); });
  document.getElementById('hn-admin-logo-remove')?.addEventListener('click',()=>{ const logo=selectedLogo(); if(!logo){showSaveStatus('اختر لوجو أولًا.');return;} config.logos=config.logos.filter(item=>item.id!==logo.id); selectedLogoId=config.logos.at(-1)?.id||null; applyLogos(); showSaveStatus('تم حذف اللوجو. اضغط «حفظ الإعدادات وتنزيل config.js».'); });
  document.getElementById('hn-admin-logo-clear-all')?.addEventListener('click',()=>{ if(!config.logos.length){showSaveStatus('لا توجد لوجوهات مخصصة لحذفها.');return;} if(!confirm('سيتم حذف جميع اللوجوهات المضافة يدويًا من الصفحة. هل تريد المتابعة؟')) return; config.logos=[]; selectedLogoId=null; applyLogos(); showSaveStatus('تم حذف جميع اللوجوهات المخصصة. اضغط «حفظ الإعدادات وتنزيل config.js».'); });
	
  const applyPerformanceState = settings => {
    const performance = { backgroundMotion: false, shadows: settings?.shadows !== false };
    root.classList.toggle('hn-motion-sleep', !performance.backgroundMotion);
    root.classList.toggle('hn-no-shadows', !performance.shadows);
    document.body.classList.toggle('hn-motion-sleep', !performance.backgroundMotion);
    if (previewPage) {
      previewPage.classList.toggle('hn-motion-sleep', !performance.backgroundMotion);
      previewPage.classList.toggle('hn-no-shadows', !performance.shadows);
      previewPage.ownerDocument?.body?.classList.toggle('hn-motion-sleep', !performance.backgroundMotion);
    }
  };
  const renderPerformanceControls = () => {
    const motion = document.getElementById('hn-admin-motion-enabled');
    const shadows = document.getElementById('hn-admin-shadows-enabled');
    if (motion) motion.checked = config.performance?.backgroundMotion !== false;
    if (shadows) shadows.checked = config.performance?.shadows !== false;
  };
  const applyConfig = () => {
	    applyTheme(config.themeName);
    if (window.HNBackgroundFX) window.HNBackgroundFX.apply(root, { mode:'none' });
    applyPerformanceState(config.performance);
	    // The main theme is the default, but it must not overwrite a customer's
	    // saved filter after refresh. The main green theme remains the first
	    // customer filter and can still be selected normally.
    const clientTheme = window.HNClientTheme;
    const savedFilterPolicy = normalizeClientFilterConfig();
    if (clientTheme && savedFilterPolicy.configured) {
      clientTheme.setAdminFilter(savedFilterPolicy.index, savedFilterPolicy.locked);
    }
    const savedClientTheme = clientTheme ? window.__HN_STORAGE.get(clientTheme.key) : null;
    if (clientTheme && !savedFilterPolicy.configured && clientTheme.isLocked() && savedClientTheme !== null) {
      const savedIndex = Number.parseInt(savedClientTheme, 10);
      if (Number.isInteger(savedIndex) && savedIndex >= 0 && savedIndex < clientTheme.colors.length) {
        clientTheme.setIndex(savedIndex);
      }
    }
    const custom = getCustomColors();
    if (clientTheme) {
      clientTheme.setAdminLock(custom.enabled && custom.lockClient, custom.enabled ? { name: 'لون الإدارة', brand: custom.brand, logoBlueShift: '0deg' } : null);
    }
	    // Reveal the page only after the final saved filter has replaced every default color.
	    document.documentElement.classList.remove('hn-theme-preload');
    applyBrandFont(root);
    const brand = root.querySelector('.hn-curtain-brand-text');
    if (brand) {
      const parts = String(config.brandName || '').trim().split(/\s+/).filter(Boolean);
      brand.replaceChildren();
      if (parts.length > 1) { brand.append(document.createTextNode(`${parts.slice(0, -1).join(' ')} `)); const accent = document.createElement('b'); accent.textContent = parts.at(-1); brand.appendChild(accent); }
      else brand.textContent = parts[0] || 'هايبر Net';
    }
    const tagline = root.querySelector('.hn-curtain-brand-tagline'); if (tagline) tagline.textContent = config.tagline;
    const login = root.querySelector('.hn-login-card');
    if (login) { login.querySelector('label')?.replaceChildren(document.createTextNode(config.cardLabel)); login.querySelector('input')?.setAttribute('placeholder', config.placeholder); login.querySelector('.hn-submit span')?.replaceChildren(document.createTextNode(config.submitLabel)); }
    const adLabel = root.querySelector('.hn-ad-section .hn-section-label');
    const effectiveAdTitle = config.adTitle == null ? '' : String(config.adTitle);
    const effectiveAdSubtitle = config.adSubtitle == null ? '' : String(config.adSubtitle);
    const effectiveAdCaption = String(config.adCaption || 'احصل على كرت هايبر نت');
    adLabel?.querySelector('b') && (adLabel.querySelector('b').textContent = effectiveAdTitle);
    adLabel?.querySelector('span') && (adLabel.querySelector('span').textContent = effectiveAdSubtitle);
    const infoLabel = root.querySelector('.hn-info-section .hn-section-label'); infoLabel?.querySelector('b') && (infoLabel.querySelector('b').textContent = config.servicesTitle); infoLabel?.querySelector('span') && (infoLabel.querySelector('span').textContent = config.servicesSubtitle);
    const tileMap = { 'tile-packages':'packages', 'tile-internet':'internet', 'tile-entertainment':'entertainment', 'tile-rules':'rules' };
    root.querySelectorAll('.hn-info-tile').forEach(tile => { const data=config.infoTiles?.[tileMap[[...tile.classList].find(c=>tileMap[c])]]; if(data){ tile.querySelector('strong')?.replaceChildren(document.createTextNode(data.title || '')); tile.querySelector('small')?.replaceChildren(document.createTextNode(data.subtitle || '')); } });
    document.querySelectorAll('[data-hn-tile][data-hn-tile-field]').forEach(input => { const data=config.infoTiles?.[input.dataset.hnTile]; if(data) input.value=data[input.dataset.hnTileField] || ''; });
    const caption = root.querySelector('.hn-ad-caption > span'); if (caption) caption.textContent = effectiveAdCaption;
    const footer = root.querySelector('.hn-footer'); const rights = footer?.querySelector('.hn-footer-rights'); if (rights) rights.textContent = config.footerLeft || 'جميع الحقوق محفوظة هايبر نت'; const fastRights = root.querySelector('.hn-fast-theme-rights'); if (fastRights) { const copy = fastRights.querySelector('.fast-rights-copy'); if (copy) copy.textContent = config.footerLeft || 'جميع الحقوق محفوظة هايبر نت'; const metaYear = fastRights.querySelector('.fast-rights-year'); if (metaYear) metaYear.textContent = '© 2027 هايبر نت'; }
    applyAds(); renderBlocks();
    if (logoPreviewCanvas) buildLogoPreview();
    applyLogos();
    applyFreeLayout(root);
    if (previewPage) { applyFreeLayout(previewPage); bindFreeLayoutDrag(previewPage); }
    updateFreeLayoutHelp();
    // The previous build called a removed live-sync helper and aborted the whole admin initializer.
    // Keep the lightweight preview scale sync here; it is safe before the full preview pass.
    syncLogoPreviewScale();
    const originalLogoCheckbox = document.getElementById('hn-admin-original-logo-visible'); if (originalLogoCheckbox) originalLogoCheckbox.checked = config.originalLogoVisible !== false;
  };

  const themeSelect = document.getElementById('hn-admin-theme-select');
  // Idempotent admin rebuild: never append a second copy after reload/export.
  if (themeSelect) themeSelect.replaceChildren();
  allThemes.forEach(theme => { const option = document.createElement('option'); option.value = theme.id; option.textContent = theme.name; themeSelect?.appendChild(option); });
  const customColorInputs = {
    start: document.getElementById('hn-admin-color-start'),
    end: document.getElementById('hn-admin-color-end'),
    ink: document.getElementById('hn-admin-color-ink'),
    soft: document.getElementById('hn-admin-color-soft'),
    brand: document.getElementById('hn-admin-color-brand')
  };
  const customColorsEnabled = document.getElementById('hn-admin-custom-colors-enabled');
  const customColorsLock = document.getElementById('hn-admin-custom-colors-lock');
  const clientFilterSelect = document.getElementById('hn-admin-client-filter');
  const clientFilterLock = document.getElementById('hn-admin-client-filter-lock');
  const normalizeClientFilterConfig = () => {
    const raw = config.clientFilter || {};
    const colors = window.HNClientTheme?.colors || [];
    const index = Number.parseInt(raw.index, 10);
    return {
      configured: raw.configured === true,
      index: Number.isInteger(index) && index >= 0 && index < colors.length ? index : 0,
      locked: raw.locked === true
    };
  };
  const ensureClientFilterOptions = () => {
    if (!clientFilterSelect) return;
    const colors = window.HNClientTheme?.colors || [];
    const signature = colors.map((color, index) => `${index}:${color.name}`).join('|');
    if (clientFilterSelect.dataset.signature === signature) return;
    clientFilterSelect.replaceChildren();
    colors.forEach((color, index) => {
      const option = document.createElement('option');
      option.value = String(index);
      option.textContent = color.name;
      clientFilterSelect.appendChild(option);
    });
    clientFilterSelect.dataset.signature = signature;
  };
  const renderClientFilterControls = () => {
    ensureClientFilterOptions();
    const policy = normalizeClientFilterConfig();
    if (clientFilterSelect) clientFilterSelect.value = String(policy.index);
    if (clientFilterLock) clientFilterLock.checked = policy.locked;
  };
  const applyClientFilterControls = (message = 'تم ضبط فلتر العميل. اضغط «حفظ الإعدادات وتنزيل config.js» لتثبيته داخل النسخة.') => {
    ensureClientFilterOptions();
    const colors = window.HNClientTheme?.colors || [];
    const index = Number.parseInt(clientFilterSelect?.value || '0', 10);
    const safeIndex = Number.isInteger(index) && index >= 0 && index < colors.length ? index : 0;
    const locked = clientFilterLock?.checked === true;
    config.clientFilter = { configured: true, index: safeIndex, locked };
    window.HNClientTheme?.setAdminFilter?.(safeIndex, locked);
    persistLocalConfig();
    showSaveStatus(message);
  };
  clientFilterSelect?.addEventListener('change', () => applyClientFilterControls());
  clientFilterLock?.addEventListener('change', () => applyClientFilterControls());
  const syncPreviewTheme = () => {
    if (!previewPage) return;
    ['--hn-start', '--hn-end', '--hn-ink', '--hn-soft', '--hn-brand', '--hn-filter-accent', '--hn-wifi-brand', '--hn-wifi-light', '--hn-wifi-dark', '--hn-logo-accent', '--hn-client-logo-filter', '--hn-client-logo-accent-filter'].forEach(name => {
      const value = root.style.getPropertyValue(name);
      if (value) previewPage.style.setProperty(name, value);
      else previewPage.style.removeProperty(name);
    });
    [...previewPage.classList].filter(name => name.startsWith('hn-theme-') || name.startsWith('hn-occasion-')).forEach(name => previewPage.classList.remove(name));
    [...root.classList].filter(name => name.startsWith('hn-theme-') || name.startsWith('hn-occasion-')).forEach(name => previewPage.classList.add(name));
  };
  const renderCustomColorControls = () => {
    const colors = getCustomColors();
    Object.entries(customColorInputs).forEach(([key, input]) => { if (input) input.value = colors[key]; });
    if (customColorsEnabled) customColorsEnabled.checked = colors.enabled;
    if (customColorsLock) customColorsLock.checked = colors.lockClient;
    const swatch = document.getElementById('hn-admin-color-swatch');
    if (swatch) {
      swatch.style.setProperty('--hn-custom-start', colors.start);
      swatch.style.setProperty('--hn-custom-end', colors.end);
      swatch.style.setProperty('--hn-custom-brand', colors.brand);
    }
  };
  const applyCustomColorControls = (message = 'تم تطبيق الألوان المخصصة. اضغط «حفظ الإعدادات وتنزيل config.js» لتضمينها في الملف.') => {
    config.customColors = {
      ...getCustomColors(),
      enabled: customColorsEnabled?.checked === true,
      lockClient: customColorsLock?.checked === true,
      ...Object.fromEntries(Object.entries(customColorInputs).map(([key, input]) => [key, normalizeColor(input?.value, defaultCustomColors[key])]))
    };
    applyTheme(config.themeName);
    const colors = getCustomColors();
    window.HNClientTheme?.setAdminLock(colors.enabled && colors.lockClient, colors.enabled ? { name: 'لون الإدارة', brand: colors.brand, logoBlueShift: '0deg' } : null);
    syncPreviewTheme();
    syncPreviewLogos();
    renderCustomColorControls();
    persistLocalConfig();
    showSaveStatus(message);
  };
  Object.values(customColorInputs).forEach(input => input?.addEventListener('input', () => {
    if (customColorsEnabled) customColorsEnabled.checked = true;
    applyCustomColorControls();
  }));
  customColorsEnabled?.addEventListener('change', () => applyCustomColorControls());
  customColorsLock?.addEventListener('change', () => applyCustomColorControls());
  renderCustomColorControls();
  const renderAdInputs = () => {
    const holder = document.getElementById('hn-admin-ad-files');
    if (!holder) return;
    holder.innerHTML = '';
    for (let index = 0; index < AD_COUNT; index += 1) {
      const card = document.createElement('div');
      card.className = 'hn-admin-ad-card';
      const preview = document.createElement('div');
      preview.className = 'hn-admin-ad-thumb';
      const customSource = config.ads[index];
      let previewNode = preview;
      if (customSource) {
        const image = document.createElement('img');
        image.className = 'hn-admin-ad-thumb';
        image.src = customSource;
        image.alt = `معاينة الإعلان ${index + 1}`;
        previewNode = image;
      } else {
        preview.textContent = 'الصورة الأصلية';
      }
      const details = document.createElement('div');
      details.className = 'hn-admin-ad-details';
      const name = document.createElement('strong');
      name.textContent = `الإعلان ${index + 1}`;
      const state = document.createElement('small');
      const meta = config.adMeta?.[index];
      state.textContent = customSource
        ? `صورة مخصصة — ${meta?.width || '?'} × ${meta?.height || '?'} بكسل`
        : `الصورة الأصلية — ${AD_RECOMMENDED_SIZE.width} × ${AD_RECOMMENDED_SIZE.height} بكسل تقريبًا`;
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/png,image/jpeg,image/webp,image/gif';
      input.dataset.adIndex = String(index);
      details.append(name, state, input);
      if (customSource) {
        const clear = document.createElement('button');
        clear.type = 'button';
        clear.className = 'hn-admin-ad-clear';
        clear.dataset.clearAd = String(index);
        clear.textContent = 'إرجاع الصورة الأصلية';
        details.appendChild(clear);
      }
      card.append(previewNode, details);
      holder.appendChild(card);
    }
  };
  const renderAdSettings = () => {
    const settings = { ...DEFAULT_AD_SETTINGS, ...(config.adSettings || {}) };
    const fields = { speed: 'hn-admin-ad-speed', width: 'hn-admin-ad-width', height: 'hn-admin-ad-height', stageHeight: 'hn-admin-ad-stage-height', gap: 'hn-admin-ad-gap', depth: 'hn-admin-ad-depth' };
    Object.entries(fields).forEach(([key, id]) => { const input = document.getElementById(id); if (input) input.value = settings[key]; });
    const sizeSelect = document.getElementById('hn-admin-ad-size-preset');
    if (sizeSelect) {
      const selected = Object.prototype.hasOwnProperty.call(AD_SIZE_PRESETS, settings.sizePreset) ? settings.sizePreset : 'custom';
      sizeSelect.value = selected === 'custom' ? 'custom' : selected;
    }
    const qualitySelect = document.getElementById('hn-admin-ad-image-quality');
    if (qualitySelect) qualitySelect.value = Object.prototype.hasOwnProperty.call(AD_IMAGE_QUALITY_PRESETS, settings.imageQuality) ? settings.imageQuality : DEFAULT_AD_SETTINGS.imageQuality;
  };

  const applyAdSizePreset = key => {
    const preset = AD_SIZE_PRESETS[key];
    if (!preset) return;
    const { label, ...values } = preset;
    config.adSettings = { ...DEFAULT_AD_SETTINGS, ...(config.adSettings || {}), ...values, sizePreset: key };
    applyAds();
    renderAdSettings();
    persistLocalConfig();
    showSaveStatus(`تم اختيار ${preset.label}. بقيت حركة الإعلانات نفسها، وتغيّر حجم المساحة والصور فقط. اضغط «حفظ الإعدادات وتنزيل config.js».`);
  };
  const renderBlockList = () => {
    const holder = document.getElementById('hn-admin-block-list'); if (!holder) return;
    holder.innerHTML = '';
    config.blocks.forEach((block, index) => {
      const item = document.createElement('div'); item.className = 'hn-admin-block-item';
      const text = document.createElement('div'); const title = document.createElement('strong'); title.textContent = block.title; const body = document.createElement('p'); body.textContent = block.body; text.append(title, body);
      const remove = document.createElement('button'); remove.type = 'button'; remove.dataset.removeBlock = String(index); remove.textContent = 'حذف'; item.append(text, remove); holder.appendChild(item);
    });
  };
  const fillWorkspace = () => {
    document.querySelectorAll('[data-hn-config]').forEach(input => { input.value = config[input.dataset.hnConfig] || ''; });
    if (themeSelect) themeSelect.value = config.themeName;
    renderCustomColorControls(); renderClientFilterControls(); renderAdInputs(); renderAdSettings(); renderPerformanceControls(); renderBlockList(); renderSceneEditor();
    const managerOnly = document.querySelector('[data-hn-manager-only]'); if (managerOnly) managerOnly.hidden = role !== 'manager';
    const roleLabel = document.getElementById('hn-admin-role'); if (roleLabel) roleLabel.textContent = role === 'manager' ? 'مدير الشبكة' : 'إداري';
  };

  const setPanelOpen = open => { panel.hidden = !open; panel.setAttribute('aria-hidden', String(!open)); if (open) { showAuthStatus(''); const pinInput=document.getElementById('hn-admin-pin-input'); try{pinInput?.focus({preventScroll:true});}catch(_){pinInput?.focus();} } };
  const resetToGate = () => { role = ''; document.getElementById('hn-admin-gate').hidden = false; document.getElementById('hn-admin-workspace').hidden = true; document.getElementById('hn-admin-pin-input').value = ''; };
  const openPanel = () => { setPanelOpen(true); const note = document.getElementById('hn-admin-auth-note'); const label = document.getElementById('hn-admin-pin-label'); const input = document.getElementById('hn-admin-pin-input'); if (!security.managerHash) { if (note) note.textContent = 'هذه أول مرة تفتح فيها اللوحة. أنشئ رمز مدير الشبكة الآن، ثم احتفظ به بعيدًا عن الزبائن.'; if (label) label.firstChild.nodeValue = 'أنشئ رمز مدير الشبكة'; if (input) input.autocomplete = 'new-password'; } else { if (note) note.textContent = 'أدخل رمز مدير الشبكة أو رمز الإداري. لن يظهر هذا المدخل للزبائن العاديين.'; if (label) label.firstChild.nodeValue = 'رمز الدخول الإداري'; if (input) input.autocomplete = 'current-password'; } };
  const unlock = currentRole => {
    role = currentRole;
    document.getElementById('hn-admin-gate').hidden = true;
    document.getElementById('hn-admin-workspace').hidden = false;
    fillWorkspace();
    // The workspace is hidden during the initial page boot. Re-render the
    // logo stage after it becomes visible so its real CSS size is available
    // for the 390x844 coordinate conversion.
    renderLogoStage();
    renderLogoControls();
    syncLogoPreviewScale();
  };

  document.getElementById('hn-admin-auth-form')?.addEventListener('submit', async event => {
    event.preventDefault(); const input = document.getElementById('hn-admin-pin-input'); const pin = input?.value.trim() || '';
    if (pin.length < 6) { showAuthStatus('استخدم رمزًا من 6 أرقام أو أحرف على الأقل.'); return; }
    const hashed = await hashPin(pin);
    if (!security.managerHash) { security.managerHash = hashed; saveJson(SECURITY_KEY, security); unlock('manager'); showAuthStatus(''); return; }
    if (hashed === security.managerHash) unlock('manager'); else if (hashed === security.editorHash) unlock('editor'); else showAuthStatus('رمز الدخول غير صحيح.');
  });
  document.getElementById('hn-admin-forgot-pin')?.addEventListener('click', () => {
    if (!security.managerHash && !security.editorHash) { showAuthStatus('لا يوجد رمز محفوظ بعد؛ يمكنك إنشاء رمز جديد مباشرة.'); return; }
    const sure = window.confirm('سيتم حذف رمز الدخول الحالي فقط (سيُطلب منك إنشاء رمز جديد). كل الإعدادات الأخرى (اللوجو، الثيمات، الإعلانات، البطاقات) ستبقى كما هي. هل تريد المتابعة؟');
    if (!sure) return;
    security = {}; saveJson(SECURITY_KEY, security);
    document.getElementById('hn-admin-pin-input').value = '';
    openPanel(); showAuthStatus('تم حذف الرمز القديم. أنشئ رمزًا جديدًا الآن.');
  });
  document.getElementById('hn-admin-lock')?.addEventListener('click', resetToGate);
  panel.querySelectorAll('[data-hn-admin-close]').forEach(button => button.addEventListener('click', () => { setPanelOpen(false); resetToGate(); }));
  document.getElementById('hn-admin-add-block')?.addEventListener('click', () => {
    const title = document.getElementById('hn-admin-block-title'); const body = document.getElementById('hn-admin-block-body');
    if (!title?.value.trim() || !body?.value.trim()) { showSaveStatus('اكتب عنوان البطاقة ومحتواها أولًا.'); return; }
    config.blocks.push({ title: title.value.trim(), body: body.value.trim() }); title.value = ''; body.value = ''; renderBlockList(); showSaveStatus('تمت إضافة البطاقة، اضغط «حفظ الإعدادات وتنزيل config.js».');
  });
  document.getElementById('hn-admin-block-list')?.addEventListener('click', event => { const button = event.target.closest('[data-remove-block]'); if (button) { config.blocks.splice(Number(button.dataset.removeBlock), 1); renderBlockList(); } });
  const readFileAsDataUrl = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('تعذر قراءة الملف'));
    reader.onload = () => resolve(String(reader.result || ''));
    reader.readAsDataURL(file);
  });
  const loadImageInfo = src => new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve({ image, width: image.naturalWidth || image.width, height: image.naturalHeight || image.height });
    image.onerror = () => reject(new Error('تعذر قراءة أبعاد الصورة'));
    image.src = src;
  });
  const prepareAdImage = async file => {
    const source = await readFileAsDataUrl(file);
    const info = await loadImageInfo(source);
    // Convert uploaded raster images to compact WebP using the quality preset selected
    // in the admin panel. Animated GIFs are intentionally reduced to their first frame
    // because the ad motion is supplied by the page itself.
    const qualityPreset = AD_IMAGE_QUALITY_PRESETS[config.adSettings?.imageQuality] || AD_IMAGE_QUALITY_PRESETS.balanced;
    const max = qualityPreset.max;
    const scale = Math.min(1, max / Math.max(info.width, info.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(info.width * scale));
    canvas.height = Math.max(1, Math.round(info.height * scale));
    const context = canvas.getContext('2d');
    if (!context) return { src: source, width: info.width, height: info.height };
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.drawImage(info.image, 0, 0, canvas.width, canvas.height);
    return { src: canvas.toDataURL('image/webp', qualityPreset.quality), width: info.width, height: info.height };
  };
  document.getElementById('hn-admin-ad-files')?.addEventListener('change', async event => {
    const input = event.target.closest('input[type=file][data-ad-index]');
    const file = input?.files?.[0];
    if (!file) return;
    const index = Number(input.dataset.adIndex);
    if (!file.type.startsWith('image/')) { showSaveStatus('اختر ملف صورة فقط.'); return; }
    showSaveStatus('جارٍ تجهيز الصورة ومعاينتها…');
    try {
      const prepared = await prepareAdImage(file);
      config.ads[index] = prepared.src;
      config.adMeta[index] = { width: prepared.width, height: prepared.height, name: file.name };
      renderAdInputs();
      applyAds();
      persistLocalConfig();
      showSaveStatus(`تم رفع الإعلان ${index + 1} بمقاس ${prepared.width} × ${prepared.height} بكسل. اضغط «حفظ الإعدادات وتنزيل config.js».`);
    } catch {
      showSaveStatus('تعذر قراءة الصورة. جرّب PNG أو JPG أو WebP أو GIF صالحًا.');
    } finally {
      input.value = '';
    }
  });
  document.getElementById('hn-admin-ad-files')?.addEventListener('click', event => {
    const button = event.target.closest('[data-clear-ad]');
    if (!button) return;
    const index = Number(button.dataset.clearAd);
    config.ads[index] = '';
    config.adMeta[index] = { width: 0, height: 0, name: '' };
    renderAdInputs();
    applyAds();
    persistLocalConfig();
    showSaveStatus(`تمت إعادة الإعلان ${index + 1} إلى الصورة الأصلية.`);
  });
  document.getElementById('hn-admin-ad-image-quality')?.addEventListener('change', event => {
    const key = Object.prototype.hasOwnProperty.call(AD_IMAGE_QUALITY_PRESETS, event.target.value) ? event.target.value : DEFAULT_AD_SETTINGS.imageQuality;
    config.adSettings = { ...DEFAULT_AD_SETTINGS, ...(config.adSettings || {}), imageQuality: key };
    renderAdSettings();
    persistLocalConfig();
    const preset = AD_IMAGE_QUALITY_PRESETS[key];
    showSaveStatus(`تم اختيار ${preset.label} للصور الجديدة. الإعلانات المرفوعة سابقًا لا تتغير حتى تعيد رفعها.`);
  });
  const updateAdSetting = (key, value) => {
    const nextSettings = { ...DEFAULT_AD_SETTINGS, ...(config.adSettings || {}), [key]: value };
    if (['width', 'height', 'stageHeight', 'depth'].includes(key)) nextSettings.sizePreset = 'custom';
    config.adSettings = nextSettings;
    applyAds();
    renderAdSettings();
    persistLocalConfig();
    showSaveStatus('تم تطبيق إعدادات الإعلانات وحفظها داخل المتصفح. اضغط «حفظ الإعدادات وتنزيل config.js» لتضمينها في الملف.');
  };
  document.getElementById('hn-admin-ad-size-preset')?.addEventListener('change', event => applyAdSizePreset(event.target.value));
  ['speed', 'width', 'height', 'stageHeight', 'gap', 'depth'].forEach(key => {
    const id = { speed: 'hn-admin-ad-speed', width: 'hn-admin-ad-width', height: 'hn-admin-ad-height', stageHeight: 'hn-admin-ad-stage-height', gap: 'hn-admin-ad-gap', depth: 'hn-admin-ad-depth' }[key];
    ['input', 'change'].forEach(eventName => document.getElementById(id)?.addEventListener(eventName, event => updateAdSetting(key, Number(event.target.value))));
  });
  document.getElementById('hn-admin-ad-reset')?.addEventListener('click', () => {
    config.adSettings = { ...DEFAULT_AD_SETTINGS, sizePreset: 'current' };
    applyAds();
    renderAdSettings();
    persistLocalConfig();
    showSaveStatus('تمت إعادة إعدادات الحركة والمقاس الافتراضية.');
  });
  let saveInProgress = false;
  const downloadTextFile = (filename, text, mime = 'text/javascript;charset=utf-8') => {
    const blob = new Blob([text], { type: mime });
    const href = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = href;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(href), 1500);
  };
  const serializeExternalConfig = () => {
    const clean = value => JSON.parse(JSON.stringify(value, (key, value) => {
      // Runtime-only fields are not needed for the deployment file.
      if (key === '__hnDraft' || key === '__hnRuntime') return undefined;
      return value;
    }));
    const exportConfig = clean(config);
    exportConfig.__hnAuthority = true;
    exportConfig.__hnRevision = Date.now();
    const exportSecurity = clean(security);
    const jsonConfig = JSON.stringify(exportConfig, null, 2);
    const jsonSecurity = JSON.stringify(exportSecurity, null, 2);
    return `/* HyperNet external configuration. Replace the existing config.js on MikroTik with this file. */\nwindow.HN_CONFIG = ${jsonConfig};\nwindow.HN_SECURITY = ${jsonSecurity};\n(function(){try{var c=window.HN_CONFIG||{},r=document.documentElement;if(!r)return;r.setAttribute('data-hn-config-authority','1');r.setAttribute('data-hn-official-theme',String(c.themeName||'ocean'));var f=c.clientFilter||{},i=Number.parseInt(f.index,10);r.setAttribute('data-hn-official-filter',String(Number.isFinite(i)?i:0));r.setAttribute('data-hn-official-filter-lock',f.locked?'1':'0');}catch(e){}})();\n`;
  };
  document.getElementById('hn-admin-save')?.addEventListener('click', async () => {
    if (saveInProgress) return;
    saveInProgress = true;
    const saveButton = document.getElementById('hn-admin-save');
    if (saveButton) { saveButton.disabled = true; saveButton.setAttribute('aria-busy', 'true'); }
    showSaveStatus('جارٍ تجهيز ملف الإعدادات فقط…');
    try {
      document.querySelectorAll('[data-hn-config]').forEach(input => { config[input.dataset.hnConfig] = input.value.trim(); });
      ensureClientFilterOptions();
      config.clientFilter = {
        configured: true,
        index: Number.parseInt(clientFilterSelect?.value || '0', 10) || 0,
        locked: clientFilterLock?.checked === true
      };
      config.customColors = getCustomColors();
      config.blocks = Array.isArray(config.blocks) ? config.blocks : [];
      config.ads = Array.from({ length: AD_COUNT }, (_, index) => Array.isArray(config.ads) ? (config.ads[index] || '') : '');
      config.adMeta = Array.from({ length: AD_COUNT }, (_, index) => config.adMeta?.[index] || ({ width: 0, height: 0, name: '' }));
      config.adSettings = { ...DEFAULT_AD_SETTINGS, ...(config.adSettings || {}) };
      config.adSettings.scale = Math.max(1, Math.min(1.35, Number(config.adSettings.scale) || DEFAULT_AD_SETTINGS.scale));
      if (!Object.prototype.hasOwnProperty.call(AD_SIZE_PRESETS, config.adSettings.sizePreset)) config.adSettings.sizePreset = 'custom';
      config.backgroundEffect = window.HNAdminFX?.get?.() || config.backgroundEffect;
      config.logos = Array.isArray(config.logos) ? config.logos.map(normalizeLogo).filter(logo => logo.src) : [];
      config.originalLogoVisible = config.originalLogoVisible !== false;
      config.__hnRevision = Date.now();
      if (role === 'manager') {
        const managerPin = document.getElementById('hn-admin-manager-pin')?.value.trim();
        const editorPin = document.getElementById('hn-admin-editor-pin')?.value.trim();
        if (managerPin) { if (managerPin.length < 6) { showSaveStatus('رمز مدير الشبكة يجب أن يكون 6 أحرف أو أرقام على الأقل.'); return; } security.managerHash = await hashPin(managerPin); }
        if (editorPin) { if (editorPin.length < 6) { showSaveStatus('رمز الإداري يجب أن يكون 6 أحرف أو أرقام على الأقل.'); return; } security.editorHash = await hashPin(editorPin); }
        if (managerPin) document.getElementById('hn-admin-manager-pin').value = '';
        if (editorPin) document.getElementById('hn-admin-editor-pin').value = '';
      }
      const health = runHealthCheck({ render: true });
      if (health.failCount) { showSaveStatus('توقّف الحفظ: ملف config.js الخارجي غير جاهز أو يوجد تعارض بنيوي.'); return; }
      if (themeSelect) {
        const selectedThemeId = String(themeSelect.value || '').trim();
        if (allThemes.some(theme => theme.id === selectedThemeId)) config.themeName = selectedThemeId;
      }
      applyTheme(config.themeName);
      const configForDraft = { ...config };
      if (!saveJson(CONFIG_KEY, configForDraft)) { showSaveStatus('تعذر حفظ نسخة العمل المحلية؛ يمكنك متابعة الحفظ إلى الملف الخارجي.'); }
      if (!saveJson(LOGOS_KEY, config.logos)) { showSaveStatus('تعذر حفظ نسخة عمل اللوجوهات محليًا؛ سيتم تضمين المواضع الحالية في config.js.'); }
      applyConfig();
      const externalText = serializeExternalConfig();
      downloadTextFile('config.js', externalText);
      showSaveStatus('تم حفظ التعديلات وتنزيل config.js فقط. استبدل config.js القديم على MikroTik؛ لا حاجة لتغيير login.html أو ملفات الصور والإعلانات.');
    } catch (error) {
      console.error('HyperNet config export failed:', error);
      showSaveStatus('تعذر إنشاء config.js. تحقق من المتصفح وحاول مرة أخرى.');
    } finally {
      saveInProgress = false;
      if (saveButton) { saveButton.disabled = false; saveButton.removeAttribute('aria-busy'); }
    }
  });

  const healthButton = document.getElementById('hn-admin-health-run');
  if (healthButton) healthButton.addEventListener('click', () => runHealthCheck({ render: true }));
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => runHealthCheck({ render: true }), { once: true });
  else setTimeout(() => runHealthCheck({ render: true }), 0);

  // Hidden admin entrance: exactly six taps on the visible HyperNet brand text.
  // One delegated pointer handler prevents double-counting on Android WebView.
  const adminTapTargetSelector='.hn-fast-theme-rights .fast-rights-brand-name, .hn-footer .hn-footer-brand-row strong';
  let adminTapCount=0,adminTapTimer=0,adminTapLastAt=0,adminTapIgnoreUntil=0;
  const resetAdminTaps=()=>{adminTapCount=0;clearTimeout(adminTapTimer);adminTapTimer=0;adminTapLastAt=0;};
  document.addEventListener('pointerup',event=>{
    if(panel&&!panel.hidden)return;
    if(Date.now()<adminTapIgnoreUntil)return;
    if(event.pointerType==='mouse'&&event.button!==0)return;
    const target=event.target?.closest?.(adminTapTargetSelector);
    if(!target)return;
    event.preventDefault();event.stopPropagation();
    const now=Date.now();
    if(adminTapLastAt&&now-adminTapLastAt>2800)resetAdminTaps();
    adminTapCount++;
    clearTimeout(adminTapTimer);adminTapLastAt=now;adminTapTimer=window.setTimeout(resetAdminTaps,2800);
    if(adminTapCount===6){
      resetAdminTaps();adminTapIgnoreUntil=now+700;
      window.requestAnimationFrame(()=>{if(panel?.hidden)openPanel();});
    }
  },{capture:true,passive:false});
  // Keep desktop shortcut.
  document.addEventListener('keydown',event=>{
    if((event.ctrlKey||event.metaKey)&&event.shiftKey&&event.key.toLowerCase()==='a'){event.preventDefault();openPanel();}
    if(event.key==='Escape'&&!panel.hidden){setPanelOpen(false);resetToGate();}
  });
  document.querySelectorAll('[data-hn-tile][data-hn-tile-field]').forEach(input => input.addEventListener('input', () => {
    config.infoTiles = config.infoTiles || {};
    config.infoTiles[input.dataset.hnTile] = config.infoTiles[input.dataset.hnTile] || {};
    config.infoTiles[input.dataset.hnTile][input.dataset.hnTileField] = input.value;
    const tile = root.querySelector(`.tile-${input.dataset.hnTile}`);
    const node = input.dataset.hnTileField === 'title' ? tile?.querySelector('strong') : tile?.querySelector('small');
    if (node) node.textContent = input.value;
    showSaveStatus('تم تعديل المربع. اضغط «حفظ الإعدادات وتنزيل config.js».');
  }));
  document.addEventListener('click', event => {
    const tile = event.target.closest?.('#hn-root .hn-info-tile');
    if (!tile) return;
    const key = [...tile.classList].find(c => ({'tile-internet':1,'tile-rules':1}[c]));
    if (!key) return;
    setTimeout(() => {
      const data = config.infoTiles?.[{ 'tile-internet':'internet', 'tile-rules':'rules' }[key]];
      const panel = root.querySelector('.hn-info-panel');
      if (data && panel) { panel.querySelector('strong')?.replaceChildren(document.createTextNode(data.title || '')); panel.querySelector('p')?.replaceChildren(document.createTextNode(data.subtitle || '')); }
    }, 0);
  });
  window.HN_ADMIN_BACKGROUND_EFFECT = config.backgroundEffect;
  // Every live customer page starts from the same clean intro state. Saved
  // files must never inherit the runtime "already revealed" classes.
  root.classList.remove('hn-intro-brand-ready','hn-intro-content-ready','hn-intro-right-curtain-active','hn-intro-left-curtain-active','hn-intro-complete');
  root.classList.add('hn-intro-waiting');
  window.__HN_INTRO_DONE = false;
  window.__HN_STARTUP_READY = true;
  applyConfig();
  const readySaveButton = document.getElementById('hn-admin-save');
  if (readySaveButton) {
    readySaveButton.disabled = false;
    readySaveButton.removeAttribute('aria-busy');
  }
  const syncV20Preview = () => {
    if (previewPage) {
      previewPage.style.width='390px'; previewPage.style.height='844px';
      previewPage.style.minHeight='844px'; previewPage.style.maxHeight='844px';
    }
    syncLogoPreviewScale();
    const selected = selectedLogo();
    if (selected) {
      const stage = logoStage?.querySelector(`[data-logo-id="${CSS.escape(selected.id)}"]`);
      if (stage) stage.style.width=`${logoStageSizePx(selected)}px`;
    }
  };
  window.addEventListener('orientationchange',()=>setTimeout(syncV20Preview,60),{passive:true});
  setTimeout(syncV20Preview,0);
})();


/* ===== hn-wifi-exact-net-js ===== */


(() => {
  const root = document.getElementById('hn-root');
  if (!root) return;

  const WIFI_SELECTORS = [
    '.hn-wifi-mark',
    '.hn-customer-main-wifi',
    '.hn-wifi-two',
    '.hn-admin-wifi-secondary'
  ];

  const getAccent = () => {
    /*
     * ONE source of truth for the customer color control: --hn-filter-accent.
     * Do not inspect hn-theme-fastnet here. That class can remain active while
     * the customer cycles the color filters, and using --hn-brand in that case
     * would immediately overwrite Net with the base-theme color.
     */
    const cssAccent = getComputedStyle(root).getPropertyValue('--hn-filter-accent').trim();
    if (cssAccent) return cssAccent;
    return '#34d399';
  };

  const syncNetAccent = () => {
    const accent = getAccent();
    // Net and Wi-Fi must always receive the exact same filter accent source.
    root.style.setProperty('--hn-net-accent', accent);
    root.style.setProperty('--hn-wifi-primary', accent);
    root.style.setProperty('--hn-wifi-brand', accent);
    root.style.setProperty('--hn-wifi-light', accent);
    root.style.setProperty('--hn-wifi-dark', accent);
    const net = root.querySelector('.hn-curtain-brand-text b');
    if (net) {
      net.style.setProperty('color', accent, 'important');
      net.style.setProperty('-webkit-text-fill-color', accent, 'important');
    }
  };

  const prepareWifi = mark => {
    if (!mark || mark.dataset.hnWifiAccentReady === '1') return;
    const sourceSvg = mark.querySelector('svg');
    if (!sourceSvg) return;

    /* Never duplicate a duplicate. The first SVG remains the permanent black base. */
    sourceSvg.classList.add('hn-wifi-base');
    sourceSvg.setAttribute('aria-hidden', 'true');

    const wrap = document.createElement('span');
    wrap.className = 'hn-wifi-accent-wrap';
    wrap.setAttribute('aria-hidden', 'true');

    const accentSvg = sourceSvg.cloneNode(true);
    accentSvg.classList.remove('hn-wifi-base');
    accentSvg.classList.add('hn-wifi-accent-svg');
    accentSvg.removeAttribute('id');
    accentSvg.querySelectorAll('[id]').forEach(node => node.removeAttribute('id'));
    accentSvg.setAttribute('focusable', 'false');
    accentSvg.setAttribute('aria-hidden', 'true');

    /* Inline SVG presentation attributes can otherwise override the filter color. */
    accentSvg.style.setProperty('color', 'var(--hn-filter-accent,#34d399)', 'important');
    accentSvg.style.setProperty('stroke', 'var(--hn-filter-accent,#34d399)', 'important');
    accentSvg.querySelectorAll('*').forEach(node => {
      node.style.setProperty('color', 'var(--hn-filter-accent,#34d399)', 'important');
      if (node.getAttribute('stroke') !== 'none') node.style.setProperty('stroke', 'var(--hn-filter-accent,#34d399)', 'important');
      if (node.getAttribute('fill') && node.getAttribute('fill') !== 'none') node.style.setProperty('fill', 'var(--hn-filter-accent,#34d399)', 'important');
    });

    wrap.appendChild(accentSvg);
    mark.appendChild(wrap);
    mark.dataset.hnWifiAccentReady = '1';
  };

  const syncWifi = () => {
    syncNetAccent();
    const marks = root.querySelectorAll(WIFI_SELECTORS.join(','));
    marks.forEach(prepareWifi);
    /* Built-in Wi-Fi logo remains black at rest; only the animated duplicate uses the filter. */
    marks.forEach(mark => {
      mark.style.setProperty('color', '#090909', 'important');
      mark.querySelectorAll('.hn-wifi-dot').forEach(dot => {
        dot.style.setProperty('background-color', '#090909', 'important');
        dot.style.setProperty('color', '#090909', 'important');
      });
    });
  };

  syncWifi();
  root.addEventListener('hn:theme-color-changed', syncWifi);

  let queued = false;
  const observer = new MutationObserver(() => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => { queued = false; syncWifi(); });
  });
  observer.observe(root, { childList: true, subtree: true });
})();


(function(){
"use strict";
const O=document.getElementById("hn-flow-overlay"), C=document.getElementById("hn-flow-content");
const state={username:"",speed:"2M",timer:null,returnToReport:false};
function open(){O.classList.add("hn-open");O.setAttribute("aria-hidden","false");document.body.style.overflow="hidden"}
function close(){
 clearInterval(state.timer);
 if(state.returnToReport){state.returnToReport=false;reportView(state.speed||"2M");return}
 O.classList.remove("hn-open");O.setAttribute("aria-hidden","true");document.body.style.overflow=""
}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function speedView(){
 O.classList.remove("hn-flow-no-close");
 let n=10;
 C.innerHTML='<h2 class="hn-flow-title">اختر سرعة الإنترنت</h2><p class="hn-flow-sub">اختر السرعة المناسبة لك، وإذا لم تختر خلال 10 ثوانٍ سيتم استخدام السرعة المتوسطة تلقائيًا.</p>'+
 '<div class="hn-speed-list">'+
 '<button class="hn-speed-btn" data-speed="514K"><div><div class="hn-speed-main">514 كيلوبت/ثانية</div><div class="hn-speed-desc">توفير البيانات</div></div><span class="hn-speed-tag">توفير</span></button>'+
 '<button class="hn-speed-btn" data-speed="2M"><div><div class="hn-speed-main">2 ميجابت/ثانية</div><div class="hn-speed-desc">السرعة الافتراضية</div></div><span class="hn-speed-tag">افتراضي</span></button>'+
 '<button class="hn-speed-btn" data-speed="100M"><div><div class="hn-speed-main">100 ميجابت/ثانية</div><div class="hn-speed-desc">سرعة عالية</div></div><span class="hn-speed-tag">عالية</span></button></div>'+
 '<div class="hn-countdown">سيتم الدخول تلقائيًا بالسرعة المتوسطة خلال <b id="hn-sec">10</b> ثوانٍ</div>';
 document.querySelectorAll(".hn-speed-btn").forEach(b=>b.onclick=()=>choose(b.dataset.speed));
 clearInterval(state.timer);state.timer=setInterval(()=>{n--;let e=document.getElementById("hn-sec");if(e)e.textContent=n;if(n<=0){clearInterval(state.timer);choose("2M")}},1000);
}
function choose(speed){clearInterval(state.timer);state.speed=speed;state.returnToReport=false;successView(speed)}
function playSuccessSound(){
 try{
  const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
  const ac=new AC(), now=ac.currentTime;
  [[523.25,0],[659.25,.12],[783.99,.24]].forEach(function(item){
   const o=ac.createOscillator(),g=ac.createGain();o.type="sine";o.frequency.value=item[0];
   g.gain.setValueAtTime(.0001,now+item[1]);g.gain.exponentialRampToValueAtTime(.12,now+item[1]+.025);g.gain.exponentialRampToValueAtTime(.0001,now+item[1]+.28);
   o.connect(g);g.connect(ac.destination);o.start(now+item[1]);o.stop(now+item[1]+.3);
  });
 }catch(e){}
}
function successView(speed){
 O.classList.add("hn-flow-no-close");
 playSuccessSound();
 C.innerHTML='<div id="hn-success-screen" role="button" tabindex="0" aria-label="متابعة إلى بيانات الكرت" onclick="HNFlow.openReportNow()" onkeydown="if(event.key===\'Enter\'||event.key===\' \')HNFlow.openReportNow()"><div class="hn-flow-brand">هايبر <b>Net</b></div><div class="hn-success-icon">✓</div><h2 class="hn-flow-title">تم تسجيل الدخول بنجاح</h2><p class="hn-flow-sub">تم قبول الكرت. السرعة المختارة: <b>'+esc(speed)+'</b></p><div class="hn-countdown">جاري فتح بيانات الكرت المستخدم خلال <b id="hn-report-sec">3</b> ثوانٍ...</div></div>';
 let n=3;state.timer=setInterval(()=>{n--;let e=document.getElementById("hn-report-sec");if(e)e.textContent=n;if(n<=0){clearInterval(state.timer);reportView(speed)}},1000);
	}
	function openReportNow(){clearInterval(state.timer);reportView(state.speed||"2M")}
	function reportView(speed){
 state.speed=speed||state.speed||"2M";
 state.returnToReport=false;
 O.classList.add("hn-flow-no-close");
	 C.innerHTML='<div class="hn-flow-brand">هايبر <b>Net</b></div>'+
	 '<h2 class="hn-flow-title">بيانات الكرت المستخدم</h2><p class="hn-flow-sub">بيانات الجلسة الحالية للكرت المستخدم.</p>'+
	 '<div class="hn-report-grid">'+
 '<div class="hn-report-item"><b>'+esc(state.username||"$(username)")+'</b><span>رقم الكرت</span></div>'+
 '<div class="hn-report-item"><b>'+esc(speed)+'</b><span>السرعة الحالية</span></div>'+
 '<div class="hn-report-item"><b>$(uptime)</b><span>مدة الجلسة الحالية</span></div>'+
 '<div class="hn-report-item"><b>$(session-time-left)</b><span>الوقت المتبقي</span></div></div>'+
 '<div class="hn-report-actions">'+
 '<button class="hn-action hn-report" type="button" onclick="HNFlow.sessionReport()">▣ تقرير جلسات الكرت للمستخدم</button>'+
 '<button class="hn-action hn-speed" type="button" onclick="HNFlow.changeSpeed()">⚡ تغيير السرعة</button>'+
 '<button class="hn-action hn-rest" type="button" onclick="HNFlow.go(\'http://10.10.10.10\')">☕ الدخول للاستراحة</button>'+
 '<button class="hn-action hn-direct" type="button" onclick="HNFlow.go(\'http://10.10.10.10:3333\')">▶ الدخول للمباشر</button>'+
 '<button class="hn-logout" type="button" onclick="HNFlow.logout()">تسجيل الخروج</button><button class="hn-action hn-google" type="button" onclick="HNFlow.go(\'https://www.google.com/\')">🌐 الذهاب إلى Google</button></div>'+
 '<div class="hn-session-note">ملاحظة: سجل الجلسات التاريخي الكامل يعرضه MikroTik/RADIUS حسب إعدادات المحاسبة لديك.</div>';
}
function start(user){state.username=user||"";open();speedView()}
function logout(){
 // MikroTik HotSpot supplies this URL on status.html/alogin.html.
 const u=(typeof window.HN_LOGOUT_URL==="string"&&window.HN_LOGOUT_URL)||"$(link-logout)";
 if(u && !u.includes("$(")){location.href=u}else{location.href="/logout"}
	}
	function sessionReport(){
 O.classList.add("hn-flow-no-close");
	 C.innerHTML='<div class="hn-flow-brand">هايبر <b>Net</b></div>'+
	 '<h2 class="hn-flow-title">تقرير جلسات الكرت للمستخدم</h2><p class="hn-flow-sub">تفاصيل جلسة الاتصال الحالية كما يوردها HotSpot.</p>'+
	 '<div class="hn-report-grid">'+
 '<div class="hn-report-item"><b>'+esc(state.username||"$(username)")+'</b><span>الكرت</span></div>'+
 '<div class="hn-report-item"><b>متصل</b><span>حالة الاتصال</span></div>'+
 '<div class="hn-report-item"><b>$(uptime)</b><span>مدة الاستخدام</span></div>'+
 '<div class="hn-report-item"><b>$(session-time-left)</b><span>الوقت المتبقي</span></div>'+
 '<div class="hn-report-item"><b>$(bytes-in-nice)</b><span>التحميل</span></div>'+
 '<div class="hn-report-item"><b>$(bytes-out-nice)</b><span>الرفع</span></div></div>'+
 '<button class="hn-action hn-report" type="button" onclick="HNFlow.report()">العودة لتقرير الكرت</button>'+
 '<div class="hn-session-note">لإظهار جميع الجلسات السابقة بالتفصيل، يجب أن تكون Accounting الخاصة بـ RADIUS/MikroTik مفعلة ومربوطة بسجل المحاسبة.</div>';
}
function report(){ reportView(state.speed||"2M"); }
function changeSpeed(){ state.returnToReport=true; speedView(); }
function go(url){ window.location.href=url; }
 function exitBrowser(){
  try{window.open("","_self");window.close()}catch(e){}
  window.setTimeout(function(){
   if(!document.hidden){
    var note=document.querySelector(".hn-session-note");
    if(note)note.textContent="تم طلب إغلاق نافذة المتصفح. إذا لم تُغلق تلقائيًا، يمكنك إغلاقها من زر الرجوع أو إغلاق النافذة، وستبقى الجلسة متصلة.";
   }
  },250);
 }
window.HNFlow={start,close,logout,report,sessionReport,changeSpeed,go,openReportNow};
})();


/* ===== hn-hotspot-login-flow-hook ===== */


(function(){
  var form=document.querySelector('form[name="login"]');
  if(!form) return;
  var card=document.getElementById('uname'), pass=document.getElementById('hn-password'), domain=document.getElementById('hn-domain'), status=document.getElementById('hn-status');
  if(card) card.addEventListener('input',function(){
    if(status){status.textContent='';status.className='hn-status';}
    var e=document.getElementById('hn-mt-error'); if(e)e.remove();
  });
  window.HN_REAL_LOGIN=function(){
    if(!card || !(card.value||'').trim()) return false;
    var value=card.value.trim();
    if(pass) pass.value=value;
    if(domain && !domain.value) domain.value='512k/1M';
    var speed=document.getElementById('speed');
    if(speed) speed.value=(domain&&domain.value)||'512k/1M';
    if(typeof saveValueToCookie==='function') { try{ saveValueToCookie(value); }catch(e){} }
    if(window.__HN_CHAP_ENABLED===true && typeof doLogin==='function') return doLogin();
    try{ if(typeof rem==='function') rem(); }catch(e){}
    try{ HTMLFormElement.prototype.submit.call(form); }catch(e){ form.submit(); }
    return false;
  };
})();


/* ===== hn-prelogin-speed-script ===== */


(function(){
  var form=document.querySelector('form[name="login"]'), ov=document.getElementById('hn-prelogin-speed-overlay'), domain=document.getElementById('hn-domain'), card=document.getElementById('uname'), status=document.getElementById('hn-status');
  var speed=document.getElementById('speed'); if(speed && domain) speed.value=domain.value||'512k/1M';
  if(!form||!ov) return;
  var timer=null, choosing=false;
  function close(){clearInterval(timer);timer=null;ov.classList.remove('hn-open');ov.setAttribute('aria-hidden','true');document.body.style.overflow='';}
  function loginWith(v){if(choosing)return;choosing=true;clearInterval(timer);if(domain)domain.value=v;var speed=document.getElementById('speed');if(speed)speed.value=v;close();if(status){status.textContent='جارٍ تسجيل الدخول…';status.className='hn-status success';}if(typeof window.HN_REAL_LOGIN==='function') window.HN_REAL_LOGIN();}
  function open(){
    if(!(card&&card.value.trim())){if(status){status.textContent='يرجى إدخال رقم الكرت أولًا.';status.className='hn-status error';}return;}
    var old=document.getElementById('hn-mt-error');if(old)old.remove();
    if(document.getElementById('hn-password'))document.getElementById('hn-password').value=card.value.trim();
    choosing=false;ov.classList.add('hn-open');ov.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';
    var n=10,e=document.getElementById('hn-prelogin-sec');if(e)e.textContent=n;
    clearInterval(timer);timer=setInterval(function(){n--;var el=document.getElementById('hn-prelogin-sec');if(el)el.textContent=n;if(n<=0)loginWith('512k/1M');},1000);
  }
  // Capture phase prevents any old/bubble submit listener from directly posting before speed is chosen.
  form.addEventListener('submit',function(e){e.preventDefault();e.stopImmediatePropagation();open();return false;},true);
  ov.querySelectorAll('[data-domain]').forEach(function(b){b.addEventListener('click',function(){loginWith(b.getAttribute('data-domain'));});});
  window.HNPreLoginSpeed={open:open,close:close};
})();


/* ===== HNFlowThemeSyncV4 ===== */


(function(){
 function sync(){
   var root=document.getElementById('hn-root'), modal=document.getElementById('hn-flow-modal');
   if(!root||!modal)return;
   var cs=getComputedStyle(root);
   ['start','end','ink','soft','brand'].forEach(function(k){
     var v=cs.getPropertyValue('--hn-'+k).trim();
     if(v)modal.style.setProperty('--flow-'+k,v);
   });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sync);else sync();
 var root=document.getElementById('hn-root');
 if(root){
   root.addEventListener('hn:theme-color-changed',sync);
   new MutationObserver(sync).observe(root,{attributes:true,attributeFilter:['class','style']});
 }
})();


/* ===== hn-v51-smooth-core-js ===== */


(function(){
  'use strict';
  const root=document.getElementById('hn-root');
  if(!root) return;

  /* One authoritative touch/click path for the four service tiles. */
  const tileSpecs=[
    ['tile-entertainment','hn-ent-overlay'],
    ['tile-packages','hn-package-overlay'],
    ['tile-internet','hn-internet-overlay'],
    ['tile-rules','hn-rules-overlay']
  ];
  const closeAll=()=>{
    root.querySelectorAll('.hn-ent-overlay.open,.hn-ent-overlay.hn-ent-open').forEach(ov=>{
      ov.classList.remove('open','hn-ent-open');
      ov.setAttribute('aria-hidden','true');
    });
  };
  const openOverlay=(ov)=>{
    if(!ov) return;
    closeAll();
    ov.classList.add('open','hn-ent-open');
    ov.setAttribute('aria-hidden','false');
  };
  tileSpecs.forEach(([tileClass,overlayId])=>{
    const old=root.querySelector('.'+tileClass);
    if(!old) return;
    const tile=old.cloneNode(true);
    old.replaceWith(tile);
    let tracking=false,startX=0,startY=0,lastOpen=0;
    const activate=(event)=>{
      const now=Date.now();
      if(now-lastOpen<450) return;
      lastOpen=now;
      event.preventDefault();
      event.stopPropagation();
      tile.classList.add('is-pressed');
      window.setTimeout(()=>tile.classList.remove('is-pressed'),110);
      openOverlay(document.getElementById(overlayId));
    };
    tile.addEventListener('pointerdown',(event)=>{
      if(event.pointerType==='mouse'&&event.button!==0) return;
      tracking=true;startX=event.clientX;startY=event.clientY;
    },{passive:true});
    tile.addEventListener('pointerup',(event)=>{
      if(!tracking) return;
      tracking=false;
      if(Math.hypot(event.clientX-startX,event.clientY-startY)>12) return;
      activate(event);
    },{passive:false});
    tile.addEventListener('pointercancel',()=>{tracking=false;});
    tile.addEventListener('click',(event)=>{
      /* Click follows pointerup on Android; suppress that duplicate. */
      event.preventDefault();event.stopPropagation();
    },true);
  });

  /* Prevent accidental page scrolling while a modal is open; never lock the document otherwise. */
  document.addEventListener('keydown',(event)=>{if(event.key==='Escape') closeAll();},{passive:true});

  /* Pause costly animations only while the document is hidden. */
  const syncVisibility=()=>root.classList.toggle('hn-v51-hidden',document.hidden);
  document.addEventListener('visibilitychange',syncVisibility,{passive:true});
  syncVisibility();

  /* Pause the 3D advertising orbit when it is off-screen. No visual change when visible. */
  const stage=root.querySelector('.hn-ad-stage');
  if(stage&&'IntersectionObserver' in window){
    const io=new IntersectionObserver(entries=>{
      const visible=entries.some(entry=>entry.isIntersecting&&entry.intersectionRatio>0.05);
      const orbit=root.querySelector('.hn-ad-orbit');
      if(orbit) orbit.style.animationPlayState=visible?'running':'paused';
    },{root:null,threshold:[0,.05]});
    io.observe(stage);
  }
})();


/* ===== hn-v52-polish-js ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  if(!root)return;

  /* Card field: clear button without changing the existing form markup. */
  var shell=root.querySelector('.hn-input-shell'), input=document.getElementById('uname');
  if(shell&&input&&!shell.querySelector('.hn-card-clear')){
    var clear=document.createElement('button');
    clear.type='button'; clear.className='hn-card-clear'; clear.setAttribute('aria-label','مسح رقم الكرت'); clear.textContent='×';
    shell.appendChild(clear);
    var sync=function(){shell.classList.toggle('has-value',!!String(input.value||'').trim());};
    input.addEventListener('input',sync,{passive:true});
    clear.addEventListener('click',function(){input.value='';input.focus({preventScroll:true});input.dispatchEvent(new Event('input',{bubbles:true}));});
    sync();
  }

  /* Do not let a swipe be interpreted as a service-button activation. */
  root.querySelectorAll('.hn-info-tile').forEach(function(tile){
    tile.style.touchAction='manipulation';
  });
})();


/* ===== hn-welcome-marquee-script ===== */


(function () {
  function addWelcomeMarquee() {
    var section = document.querySelector('#hn-root.hypernet-page .hn-ad-section');
    var stage = section && section.querySelector('.hn-ad-stage');
    if (!section || !stage || section.querySelector('.hn-welcome-marquee')) return;
    var box = document.createElement('div');
    box.className = 'hn-welcome-marquee';
    box.setAttribute('role', 'note');
    box.setAttribute('aria-label', 'رسالة ترحيبية');
    var message = document.createElement('span');
    message.textContent = 'أهلاً وسهلاً بكم في استراحة وشبكة هايبر نت، استمتع بمشاهدة وتحميل جميع مسلسلاتك بجودة عالية وبشكل مجاني على استراحة الشبكة';
    box.appendChild(message);
    stage.parentNode.insertBefore(box, stage);
    var motion = section.querySelector('.hn-ad-orbit, .hn-ad-slide');
    if (motion) {
      var duration = getComputedStyle(motion).animationDuration;
      if (duration && duration !== '0s') message.style.animationDuration = duration;
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', addWelcomeMarquee);
  else addWelcomeMarquee();
  setTimeout(addWelcomeMarquee, 250);
})();


/* ===== hn-scroll-performance-v14 ===== */


(function(){
  var r=document.getElementById('hn-root'); if(!r)return;
  var timer=0, raf=0;
  var on=function(){
    if(!r.classList.contains('hn-is-scrolling')) r.classList.add('hn-is-scrolling');
    clearTimeout(timer); timer=setTimeout(function(){r.classList.remove('hn-is-scrolling');},120);
    if(!raf && window.requestAnimationFrame) raf=requestAnimationFrame(function(){raf=0;});
  };
  r.addEventListener('scroll',on,{passive:true});
  window.addEventListener('scroll',on,{passive:true});
  var bind=function(){document.querySelectorAll('#hn-admin-panel .hn-admin-dialog').forEach(function(el){el.addEventListener('scroll',on,{passive:true});});};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind,{once:true});else bind();
})();


/* ===== hn-services-preload-reveal ===== */


(function(){
  function reveal(){
    try { document.documentElement.classList.remove('hn-services-preload'); } catch(e) {}
  }
  reveal();
})();


/* ===== hn-unified-canvas-lock-v2-script ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root'); if(!root) return;
  function fit(){
    var w=Math.max(1,document.documentElement.clientWidth||window.innerWidth||390);
    var scale=Math.min(1,w/390);
    root.style.setProperty('--hn-canvas-scale',String(scale));
    root.classList.add('hn-canvas-locked');
    document.body.style.setProperty('--hn-canvas-scale',String(scale));
  }
  fit(); window.addEventListener('resize',fit,{passive:true});
  if(window.visualViewport) window.visualViewport.addEventListener('resize',fit,{passive:true});
})();


/* ===== hn-theme-controls-bottom-bg-v1-script ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  if(!root) return;
  function syncPageBottom(){
    var cs=getComputedStyle(root);
    var start=(cs.getPropertyValue('--hn-start')||'').trim()||'#0b3d2e';
    var end=(cs.getPropertyValue('--hn-end')||'').trim()||start;
    // The page itself keeps its theme; this only paints the area below its canvas.
    document.documentElement.style.setProperty('--hn-page-bottom-bg',end);
    document.documentElement.style.background=end;
    document.body.style.background=start;
  }
  if(window.__HN_STARTUP_READY) syncPageBottom();
  root.addEventListener('hn:theme-color-changed',function(){if(window.__HN_STARTUP_READY)syncPageBottom();},{passive:true});
  window.addEventListener('storage',function(e){if(e.key) setTimeout(syncPageBottom,0)},{passive:true});
})();


/* ===== hn-canvas-edge-background-fix-script ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  if(!root)return;
  function syncPageBackground(){
    try{
      var atmosphere=root.querySelector(':scope > .hn-atmosphere');
      if(!atmosphere)return;
      var cs=getComputedStyle(atmosphere);
      var bg=cs.background;
      if(bg && bg!=='none') document.body.style.setProperty('background',bg,'important');
    }catch(e){}
  }
  if(window.__HN_STARTUP_READY) syncPageBackground();
  root.addEventListener('hn:theme-color-changed',function(){if(window.__HN_STARTUP_READY)syncPageBackground();},{passive:true});
  window.addEventListener('load',function(){if(window.__HN_STARTUP_READY)syncPageBackground();},{once:true});
})();


/* ===== hn-customer-contained-frame-final-v1-script ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  if(!root || (document.body && document.body.classList.contains('hn-admin-preview-page'))) return;
  var DESIGN_W=390, FRAME_GAP=8;
  function syncCustomerBackgroundHeight(){
    try{
      var h=Math.max(root.scrollHeight||0,root.clientHeight||0,1);
      var heightValue=h+'px';
      if(root.style.getPropertyValue('--hn-bg-height')!==heightValue){
        root.style.setProperty('--hn-bg-height',heightValue);
      }
    }catch(_){ }
  }
  function fitCustomerCanvas(){
    try{
      var viewport=Math.max(1,document.documentElement.clientWidth||window.innerWidth||DESIGN_W);
      var available=Math.max(1,viewport-FRAME_GAP);
      var scale=Math.min(1,available/DESIGN_W);
      var scaleValue=String(scale);
      if(root.style.getPropertyValue('--hn-canvas-scale')!==scaleValue){
        root.style.setProperty('--hn-canvas-scale',scaleValue);
      }
      root.classList.add('hn-canvas-locked');
      var cs=getComputedStyle(root);
      var start=(cs.getPropertyValue('--hn-start')||'').trim()||'#0b3d2e';
      var end=(cs.getPropertyValue('--hn-end')||'').trim()||'#1fae70';
      var brand=(cs.getPropertyValue('--hn-brand')||'').trim()||'#34d399';
      document.documentElement.style.setProperty('--hn-frame-start',start);
      document.documentElement.style.setProperty('--hn-frame-end',end);
      document.documentElement.style.setProperty('--hn-frame-brand',brand);
      document.body.style.setProperty('--hn-frame-start',start);
      document.body.style.setProperty('--hn-frame-end',end);
      document.body.style.setProperty('--hn-frame-brand',brand);
      document.body.style.setProperty('background',
        'linear-gradient(140deg,'+start+','+end+')',
        'important'
      );
      syncCustomerBackgroundHeight();
    }catch(_){ }
  }
  fitCustomerCanvas();
  window.addEventListener('resize',fitCustomerCanvas,{passive:true});
  if(window.visualViewport) window.visualViewport.addEventListener('resize',fitCustomerCanvas,{passive:true});
  root.addEventListener('hn:theme-color-changed',function(){ fitCustomerCanvas(); syncCustomerBackgroundHeight(); },{passive:true});
  window.addEventListener('load',syncCustomerBackgroundHeight,{once:true,passive:true});
  setTimeout(syncCustomerBackgroundHeight,120);
  setTimeout(syncCustomerBackgroundHeight,500);
  setTimeout(syncCustomerBackgroundHeight,1200);
  if(window.MutationObserver){
    var mo=new MutationObserver(function(list){
      for(var i=0;i<list.length;i++){
        if(list[i].type==='attributes' && list[i].attributeName==='style'){ fitCustomerCanvas(); break; }
      }
    });
    mo.observe(root,{attributes:true,attributeFilter:['style']});
  }
})();


/* ===== hn-net-accent-final-sync ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  if(!root) return;
  function isPreview(){
    return document.documentElement.classList.contains('hn-admin-preview-page') ||
      document.body.classList.contains('hn-admin-preview-page');
  }
  function getAccent(){
    try{
      var cs=getComputedStyle(root);
      var accent=(cs.getPropertyValue('--hn-filter-accent')||'').trim();
      if(!accent) accent=(root.style.getPropertyValue('--hn-filter-accent')||'').trim();
      if(!accent) accent=(root.style.getPropertyValue('--hn-net-accent')||'').trim();
      return accent || '#34d399';
    }catch(e){ return '#34d399'; }
  }
  function sync(){
    if(isPreview()) return;
    try{
      var accent=getAccent();
      root.style.setProperty('--hn-net-accent',accent);
      var net=root.querySelector('.hn-curtain-brand-text b');
      if(net){
        net.style.setProperty('color',accent,'important');
        net.style.setProperty('-webkit-text-fill-color',accent,'important');
        net.style.setProperty('background','none','important');
        net.style.setProperty('background-image','none','important');
        net.style.setProperty('background-clip','border-box','important');
        net.style.setProperty('-webkit-background-clip','border-box','important');
        net.style.setProperty('-webkit-text-stroke','0 transparent','important');
      }
    }catch(e){}
  }
  root.addEventListener('hn:theme-color-changed',function(){
    sync();
    setTimeout(sync,0);
    setTimeout(sync,60);
    if(window.requestAnimationFrame) requestAnimationFrame(sync);
  },{passive:true});
  if(window.MutationObserver){
    var queued=false;
    var mo=new MutationObserver(function(){
      if(queued) return;
      queued=true;
      var run=function(){ queued=false; sync(); };
      if(window.requestAnimationFrame) requestAnimationFrame(run); else setTimeout(run,0);
    });
    mo.observe(root,{attributes:true,attributeFilter:['style']});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',sync,{once:true});
  window.addEventListener('load',sync,{once:true});
  sync();
})();


/* ===== hn-animated-logo-cross-browser-sync ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  if(!root) return;
  function sync(){
    var value=(getComputedStyle(root).getPropertyValue('--hn-animated-logo-filter')||'').trim();
    if(!value) value='hue-rotate(0deg) saturate(1)';
    root.querySelectorAll('.hn-custom-logo-animated,[data-hn-logo-animated="1"]').forEach(function(el){
      try{ el.style.setProperty('filter',value+' drop-shadow(0 7px 16px rgba(0,0,0,.18))','important'); }catch(_e){}
    });
  }
  root.addEventListener('hn:theme-color-changed',function(){
    sync();
    setTimeout(sync,0);
    setTimeout(sync,80);
  },{passive:true});
  if(window.MutationObserver){
    var queued=false;
    var mo=new MutationObserver(function(){
      if(queued) return;
      queued=true;
      var run=function(){queued=false;sync();};
      if(window.requestAnimationFrame) requestAnimationFrame(run); else setTimeout(run,0);
    });
    mo.observe(root,{attributes:true,attributeFilter:['class','style']});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',sync,{once:true});
  else sync();
  window.addEventListener('load',sync,{once:true,passive:true});
})();


/* ===== hn-animated-logo-net-exact-final-v1-script ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  if(!root) return;

  function parseColor(value){
    value=String(value||'').trim().toLowerCase();
    var m=value.match(/^rgba?\(\s*([0-9.]+)\s*[, ]\s*([0-9.]+)\s*[, ]\s*([0-9.]+)/);
    if(m) return [Number(m[1]),Number(m[2]),Number(m[3])];
    var h=value.replace('#','');
    if(/^[0-9a-f]{6}$/.test(h)) return [parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)];
    return null;
  }
  function hsv(rgb){
    var r=rgb[0]/255,g=rgb[1]/255,b=rgb[2]/255;
    var max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min,h=0;
    if(d){
      if(max===r) h=((g-b)/d)%6;
      else if(max===g) h=(b-r)/d+2;
      else h=(r-g)/d+4;
      h*=60; if(h<0) h+=360;
    }
    return {h:h,s:max?d/max:0,v:max};
  }
  var source=hsv([65,147,239]);
  function sync(){
    try{
      var net=root.querySelector('.hn-curtain-brand-text b');
      if(!net) return;
      var rendered=getComputedStyle(net).color || root.style.getPropertyValue('--hn-filter-accent') || '#34d399';
      var rgb=parseColor(rendered) || [52,211,153];
      var target=hsv(rgb);
      var hueDelta=target.h-source.h;
      while(hueDelta>180) hueDelta-=360;
      while(hueDelta<-180) hueDelta+=360;
      var satFactor=Math.max(.12,Math.min(1.35,target.s/Math.max(.001,source.s)));
      var filter='hue-rotate('+hueDelta.toFixed(2)+'deg) saturate('+satFactor.toFixed(4)+')';
      root.style.setProperty('--hn-animated-logo-filter',filter);
      root.querySelectorAll('.hn-custom-logo-animated,[data-hn-logo-animated="1"]').forEach(function(el){
        try{ el.style.setProperty('filter',filter+' drop-shadow(0 7px 16px rgba(0,0,0,.18))','important'); }catch(_e){}
      });
    }catch(_e){}
  }
  function queue(){
    sync();
    if(window.requestAnimationFrame) requestAnimationFrame(sync); else setTimeout(sync,0);
    setTimeout(sync,80);
  }
  root.addEventListener('hn:theme-color-changed',queue,{passive:true});
  if(window.MutationObserver){
    var queued=false;
    var mo=new MutationObserver(function(){
      if(queued) return;
      queued=true;
      var run=function(){queued=false;queue();};
      if(window.requestAnimationFrame) requestAnimationFrame(run); else setTimeout(run,0);
    });
    mo.observe(root,{attributes:true,attributeFilter:['style']});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',queue,{once:true});
  window.addEventListener('load',queue,{once:true});
  queue();
})();


/* ===== hn-frame-follow-page-v1-script ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  if(!root) return;
  if(document.documentElement.classList.contains('hn-admin-preview-page') ||
     (document.body && document.body.classList.contains('hn-admin-preview-page'))) return;
  function syncHeight(){
    try{
      var h=Math.max(root.scrollHeight||0,root.offsetHeight||0,root.clientHeight||0,1);
      root.style.setProperty('--hn-bg-height',h+'px');
    }catch(e){}
  }
  syncHeight();
  window.addEventListener('load',syncHeight,{once:true,passive:true});
  window.addEventListener('resize',syncHeight,{passive:true});
  setTimeout(syncHeight,120);
  setTimeout(syncHeight,500);
  setTimeout(syncHeight,1200);
  // Mutation/resize/load syncs are sufficient here; do not observe the root
  // with ResizeObserver because updating the background-height variable can
  // otherwise produce a browser ResizeObserver feedback warning.
  if(window.MutationObserver){
    var queued=false;
    try{
      new MutationObserver(function(){
        if(queued) return;
        queued=true;
        var run=function(){queued=false;syncHeight();};
        if(window.requestAnimationFrame) requestAnimationFrame(run); else setTimeout(run,0);
      }).observe(root,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
    }catch(e){}
  }
})();


/* ===== hn-theme-backdrop-overscroll-lock-v1-script ===== */


(function(){
  'use strict';
  var root=document.getElementById('hn-root');
  var html=document.documentElement;
  var body=document.body;
  if(!root||!html||!body||html.classList.contains('hn-admin-preview-page')||body.classList.contains('hn-admin-preview-page')) return;
  var queued=false;
  function sync(){
    queued=false;
    try{
      var cs=getComputedStyle(root);
      var image=cs.backgroundImage||'none';
      var color=(cs.backgroundColor||'').trim();
      if(!color||color==='rgba(0, 0, 0, 0)') color=(getComputedStyle(root).getPropertyValue('--hn-start')||'#05030d').trim();
      [html,body].forEach(function(el){
        el.style.setProperty('background-color',color,'important');
        el.style.setProperty('background-image',image,'important');
        el.style.setProperty('background-repeat','no-repeat','important');
        el.style.setProperty('background-position','center top','important');
        el.style.setProperty('background-size','100% 100%','important');
      });
    }catch(_e){}
  }
  function queue(){
    if(queued) return;
    queued=true;
    if(window.requestAnimationFrame) requestAnimationFrame(sync); else setTimeout(sync,0);
  }
  sync();
  root.addEventListener('hn:theme-color-changed',queue,{passive:true});
  window.addEventListener('resize',queue,{passive:true});
  if(window.MutationObserver){
    try{new MutationObserver(queue).observe(root,{attributes:true,attributeFilter:['class','style']});}catch(_e){}
  }
})();


/* ===== hn-modal-scroll-lock-final-js ===== */


(()=>{
 const root=document.getElementById('hn-root'); if(!root)return;
 let savedY=0,locked=false;
 const lock=()=>{if(locked)return;locked=true;savedY=window.scrollY||document.documentElement.scrollTop||0;document.documentElement.classList.add('hn-modal-locked');document.body.classList.add('hn-modal-locked');document.body.style.top=`-${savedY}px`;};
 const unlock=()=>{if(!locked)return;locked=false;document.documentElement.classList.remove('hn-modal-locked');document.body.classList.remove('hn-modal-locked');document.body.style.top='';window.scrollTo(0,savedY);};
 const sync=()=>{const open=root.querySelector('.hn-ent-overlay.hn-ent-open,.hn-ent-overlay.open');open?lock():unlock();};
 new MutationObserver(sync).observe(root,{subtree:true,attributes:true,attributeFilter:['class']});
 sync();
})();
